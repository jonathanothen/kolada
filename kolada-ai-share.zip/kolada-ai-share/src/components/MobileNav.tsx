"use client";

import { motion, AnimatePresence } from "framer-motion";
import {
  MessageSquare,
  Search,
  BarChart3,
  MapPin,
  BookOpen,
  Plus,
  ScrollText,
  X,
} from "lucide-react";

interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onNewChat?: () => void;
}

const MENU_ITEMS = [
  { id: "chat", icon: MessageSquare, label: "AI Chatt" },
  { id: "search", icon: Search, label: "Sök KPIs" },
  { id: "municipalities", icon: MapPin, label: "Kommuner" },
  { id: "data", icon: BarChart3, label: "Utforska Data" },
  { id: "logs", icon: ScrollText, label: "Loggar" },
  { id: "docs", icon: BookOpen, label: "Dokumentation" },
];

export default function MobileNav({
  isOpen,
  onClose,
  activeTab,
  setActiveTab,
  onNewChat,
}: MobileNavProps) {
  const handleTabClick = (tabId: string) => {
    setActiveTab(tabId);
    onClose();
  };

  const handleNewChat = () => {
    if (onNewChat) {
      onNewChat();
    }
    setActiveTab("chat");
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          />

          {/* Slide-in menu */}
          <motion.div
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed left-0 top-0 h-full w-72 bg-slate-900 border-r border-slate-800 z-50 lg:hidden"
          >
            <div className="flex flex-col h-full">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-slate-800">
                <h2 className="text-lg font-bold text-white">Meny</h2>
                <button
                  onClick={onClose}
                  className="p-2 rounded-lg hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              {/* New Chat Button */}
              <div className="p-4">
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={handleNewChat}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 text-white font-medium"
                >
                  <Plus className="w-5 h-5" />
                  <span>Ny konversation</span>
                </motion.button>
              </div>

              {/* Navigation */}
              <nav className="flex-1 px-4 overflow-y-auto">
                <div className="space-y-1">
                  {MENU_ITEMS.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => handleTabClick(item.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                        activeTab === item.id
                          ? "bg-blue-500/10 text-blue-400"
                          : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                      }`}
                    >
                      <item.icon className="w-5 h-5 flex-shrink-0" />
                      <span className="font-medium">{item.label}</span>
                    </button>
                  ))}
                </div>
              </nav>

              {/* Footer */}
              <div className="p-4 border-t border-slate-800">
                <p className="text-xs text-slate-500 text-center">
                  Utvecklad av Jonas Millard
                </p>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
