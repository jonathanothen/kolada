"use client";

import { motion } from "framer-motion";
import { Settings, Database, Sparkles, Menu } from "lucide-react";

interface HeaderProps {
  onSettingsClick: () => void;
  hasApiKey: boolean;
  onMenuClick?: () => void;
}

export default function Header({ onSettingsClick, hasApiKey, onMenuClick }: HeaderProps) {
  return (
    <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Mobile menu button + Logo */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Hamburger menu - mobile only */}
            {onMenuClick && (
              <button
                onClick={onMenuClick}
                className="p-2 rounded-lg hover:bg-slate-800 transition-colors lg:hidden"
              >
                <Menu className="w-5 h-5 text-slate-300" />
              </button>
            )}
            
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2 sm:gap-3"
            >
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 flex items-center justify-center">
                <Database className="w-5 h-5 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center">
                <Sparkles className="w-2.5 h-2.5 text-white" />
              </div>
            </div>
              <div>
                <h1 className="text-lg sm:text-xl font-bold text-white">Kolada AI</h1>
                <p className="text-xs text-slate-400 hidden sm:block">Svensk Offentlig Data</p>
              </div>
            </motion.div>
          </div>

          {/* Right side */}
          <div className="flex items-center gap-3">
            {/* Status indicator */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800/50 border border-slate-700/50">
              <div
                className={`w-2 h-2 rounded-full ${
                  hasApiKey ? "bg-green-400 animate-pulse" : "bg-amber-400"
                }`}
              />
              <span className="text-xs text-slate-400">
                {hasApiKey ? "Ansluten" : "API-nyckel saknas"}
              </span>
            </div>

            {/* GitHub Link */}
            <a
              href="https://kolada.se"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <Database className="w-5 h-5 text-slate-400 hover:text-white transition-colors" />
            </a>

            {/* Settings Button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onSettingsClick}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 transition-all"
            >
              <Settings className="w-5 h-5 text-slate-300" />
            </motion.button>
          </div>
        </div>
      </div>
    </header>
  );
}
