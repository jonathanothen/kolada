"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send,
  Bot,
  User,
  Loader2,
  Sparkles,
  TrendingUp,
  MapPin,
  Calendar,
  Trash2,
  BarChart3,
} from "lucide-react";
import dynamic from 'next/dynamic';
import { extractVisualizationData, VisualizationData } from './DataVisualization';

// Dynamisk import av Chart för att undvika SSR-problem
const DataVisualization = dynamic(() => import('./DataVisualization'), { ssr: false });

// Loggningsfunktion - skickar till server och konsol
async function logToServer(level: string, category: string, message: string, data?: unknown) {
  const logEntry = { level, category, message, data, timestamp: new Date().toISOString() };
  console.log(`[${level}] [${category}]`, message, data || '');
  try {
    await fetch('/api/log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(logEntry),
    });
  } catch (e) {
    // Ignorera loggningsfel
  }
}

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  isLoading?: boolean;
}

interface ChatInterfaceProps {
  apiKey: string;
  model: string;
}

// Rensa kommunnamn - behåll "region" och "län" för att kunna identifiera regioner
function cleanMunicipalityName(name: string): string {
  return name
    .replace(/\s*(kommun|stad)\s*/gi, '')
    .trim();
}

// Kolla om ett namn indikerar en region
function isRegionName(name: string): boolean {
  const lower = name.toLowerCase();
  return lower.includes('region') || lower.includes('län');
}

// Extrahera basnamnet för sökning (t.ex. "Örebro" från "Region Örebro län")
function extractBaseName(name: string): string {
  return name
    .replace(/\s*(kommun|region|stad|län)\s*/gi, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

const EXAMPLE_QUESTIONS = [
  {
    icon: TrendingUp,
    text: "Hur har befolkningen i Örebro utvecklats 2015-2023?",
  },
  {
    icon: MapPin,
    text: "Jämför skolresultaten i Stockholm och Göteborg 2023",
  },
  {
    icon: Calendar,
    text: "Visa kommunalskatt i Malmö de senaste 5 åren",
  },
  {
    icon: Sparkles,
    text: "Vilka kommuner har högst lärartäthet i förskolan?",
  },
];

// Enhetstyper (OU) för sökning - behövs för att identifiera rätt OU-kod
const OU_TYPES: { [key: string]: string } = {
  förskola: "V11",
  grundskola: "V15",
  gymnasium: "V17",
  gymnasieskola: "V17",
  hemtjänst: "V21",
  äldreboende: "V23",
  "särskilt boende": "V23",
  lss: "V25",
  gruppbostad: "V29",
  servicebostad: "V30",
};

// Funktion för att identifiera om frågan handlar om enheter
function detectOUType(query: string): string | null {
  const lowerQuery = query.toLowerCase();
  for (const [keyword, ouCode] of Object.entries(OU_TYPES)) {
    if (lowerQuery.includes(keyword)) {
      return ouCode;
    }
  }
  if (lowerQuery.includes("skolan") || lowerQuery.includes("skolans")) {
    return "V15";
  }
  return null;
}

const STORAGE_KEY = 'kolada-ai-chat-history';

// Formatera text med markdown-stöd
function formatText(text: string): React.ReactNode {
  // Ta bort överflödiga asterisker och formatera
  let formatted = text;
  
  // Konvertera markdown till JSX
  const parts: React.ReactNode[] = [];
  let lastIndex = 0;
  
  // Regex för **bold**, *italic*, och `code`
  const regex = /(\*\*\*(.+?)\*\*\*|\*\*(.+?)\*\*|\*(.+?)\*|`(.+?)`)/g;
  let match;
  
  while ((match = regex.exec(formatted)) !== null) {
    // Lägg till text före match
    if (match.index > lastIndex) {
      parts.push(formatted.slice(lastIndex, match.index));
    }
    
    if (match[2]) {
      // ***bold italic***
      parts.push(<strong key={match.index} className="font-bold italic text-white">{match[2]}</strong>);
    } else if (match[3]) {
      // **bold**
      parts.push(<strong key={match.index} className="font-semibold text-white">{match[3]}</strong>);
    } else if (match[4]) {
      // *italic*
      parts.push(<em key={match.index} className="italic text-slate-200">{match[4]}</em>);
    } else if (match[5]) {
      // `code`
      parts.push(<code key={match.index} className="bg-slate-700 px-1.5 py-0.5 rounded text-blue-300 text-sm">{match[5]}</code>);
    }
    
    lastIndex = match.index + match[0].length;
  }
  
  // Lägg till resterande text
  if (lastIndex < formatted.length) {
    parts.push(formatted.slice(lastIndex));
  }
  
  return parts.length > 0 ? parts : text;
}

// Formatera tabellcell med färgkodning
function formatCell(cell: string): React.ReactNode {
  const cleanCell = cell.replace(/\*\*/g, '').replace(/\*/g, '');
  const numMatch = cleanCell.match(/^([+-]?\d+[,.]?\d*)/);
  
  if (numMatch) {
    const num = parseFloat(numMatch[1].replace(',', '.'));
    if (num > 0 && cleanCell.includes('+')) {
      return <span className="text-green-400 font-medium">{cleanCell}</span>;
    } else if (num < 0) {
      return <span className="text-red-400 font-medium">{cleanCell}</span>;
    }
  }
  
  return formatText(cleanCell);
}

// Komponent för att rendera meddelanden med snygga tabeller och diagram
function MessageContent({ content }: { content: string }) {
  const [showChart, setShowChart] = useState(true); // Visa diagram som standard
  
  // Ta bort chart-blocket från content innan rendering (så användaren inte ser rå JSON)
  const cleanContent = content.replace(/```chart\s*\n?[\s\S]*?\n?```/g, '').trim();
  
  // Extrahera diagramdata (använder original content för att hitta chart-block)
  const vizData = extractVisualizationData(content);
  
  // Konvertera markdown till snyggt formaterad HTML
  const renderContent = () => {
    const lines = cleanContent.split('\n');
    const elements: React.ReactNode[] = [];
    let inTable = false;
    let tableRows: string[][] = [];
    let inList = false;
    let listItems: string[] = [];
    
    const flushTable = (key: string) => {
      if (tableRows.length > 0) {
        elements.push(
          <div key={key} className="overflow-x-auto my-4 rounded-lg border border-slate-700">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-800">
                <tr>
                  {tableRows[0]?.map((cell, j) => (
                    <th key={j} className="px-4 py-2.5 text-left text-slate-200 font-semibold border-b border-slate-600">
                      {formatText(cell.replace(/\*\*/g, ''))}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {tableRows.slice(1).map((row, rowIdx) => (
                  <tr key={rowIdx} className="hover:bg-slate-700/30 transition-colors">
                    {row.map((cell, cellIdx) => (
                      <td key={cellIdx} className="px-4 py-2">
                        {formatCell(cell)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
        tableRows = [];
      }
    };
    
    const flushList = (key: string) => {
      if (listItems.length > 0) {
        elements.push(
          <ul key={key} className="my-2 space-y-1">
            {listItems.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2 text-slate-200">
                <span className="text-blue-400 mt-1">•</span>
                <span>{formatText(item)}</span>
              </li>
            ))}
          </ul>
        );
        listItems = [];
      }
    };
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmedLine = line.trim();
      
      // Detektera tabellrad
      if (trimmedLine.includes('|') && (trimmedLine.startsWith('|') || trimmedLine.includes(' | '))) {
        if (inList) { flushList(`list-${i}`); inList = false; }
        if (!inTable) {
          inTable = true;
          tableRows = [];
        }
        // Hoppa över separator-rad (|---|---|)
        if (!trimmedLine.match(/^[\s|:-]+$/)) {
          const cells = trimmedLine.split('|').filter(c => c.trim()).map(c => c.trim());
          if (cells.length > 0) {
            tableRows.push(cells);
          }
        }
        continue;
      }
      
      // Avsluta tabell
      if (inTable) {
        flushTable(`table-${i}`);
        inTable = false;
      }
      
      // Detektera listrad (-, *, eller nummer.)
      const listMatch = trimmedLine.match(/^[-*•]\s+(.+)$/) || trimmedLine.match(/^\d+\.\s+(.+)$/);
      if (listMatch) {
        if (!inList) inList = true;
        listItems.push(listMatch[1]);
        continue;
      }
      
      // Avsluta lista
      if (inList) {
        flushList(`list-${i}`);
        inList = false;
      }
      
      // Rubriker
      if (trimmedLine.startsWith('### ')) {
        elements.push(
          <h3 key={`h3-${i}`} className="text-lg font-semibold text-white mt-4 mb-2">
            {formatText(trimmedLine.slice(4))}
          </h3>
        );
        continue;
      }
      if (trimmedLine.startsWith('## ')) {
        elements.push(
          <h2 key={`h2-${i}`} className="text-xl font-bold text-white mt-4 mb-2">
            {formatText(trimmedLine.slice(3))}
          </h2>
        );
        continue;
      }
      if (trimmedLine.startsWith('# ')) {
        elements.push(
          <h1 key={`h1-${i}`} className="text-2xl font-bold text-white mt-4 mb-3">
            {formatText(trimmedLine.slice(2))}
          </h1>
        );
        continue;
      }
      
      // Vanlig text eller tom rad
      if (trimmedLine) {
        elements.push(
          <p key={`p-${i}`} className="my-1.5 text-slate-200 leading-relaxed">
            {formatText(trimmedLine)}
          </p>
        );
      } else if (elements.length > 0) {
        // Lägg till lite spacing för tomma rader
        elements.push(<div key={`space-${i}`} className="h-2" />);
      }
    }
    
    // Avsluta eventuella öppna strukturer
    if (inTable) flushTable('table-final');
    if (inList) flushList('list-final');
    
    return elements;
  };
  
  return (
    <div className="space-y-2">
      <div className="prose prose-invert prose-sm max-w-none">
        {renderContent()}
      </div>
      
      {/* Avancerad visualisering om det finns data */}
      {vizData && vizData.points.length >= 2 && (
        <div className="mt-4">
          <button
            onClick={() => setShowChart(!showChart)}
            className="flex items-center gap-2 text-sm text-blue-400 hover:text-blue-300 transition-colors mb-3"
          >
            <BarChart3 className="w-4 h-4" />
            {showChart ? 'Dölj visualisering' : 'Visa visualisering'}
          </button>
          
          {showChart && (
            <DataVisualization data={vizData} />
          )}
        </div>
      )}
    </div>
  );
}

export default function ChatInterface({ apiKey, model }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState<string>("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Ladda chathistorik från localStorage vid start
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          // Konvertera timestamp tillbaka till Date-objekt
          const restored = parsed.map((m: Message & { timestamp: string }) => ({
            ...m,
            timestamp: new Date(m.timestamp)
          }));
          setMessages(restored);
        } catch (e) {
          console.error('Kunde inte ladda chathistorik:', e);
        }
      }
    }
  }, []);

  // Spara chathistorik till localStorage vid ändringar
  useEffect(() => {
    if (typeof window !== 'undefined' && messages.length > 0) {
      // Filtrera bort loading-meddelanden
      const toSave = messages.filter(m => !m.isLoading);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
    }
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const clearChat = () => {
    setMessages([]);
    if (typeof window !== 'undefined') {
      localStorage.removeItem(STORAGE_KEY);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    };

    // Include the new message in the history we'll send
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInput("");
    setIsLoading(true);
    
    // Bestäm vilken modell som används (för visning)
    const activeModel = model || "gemini-2.5-flash";
    const modelShortName = activeModel
      .replace("gemini-", "")
      .replace("-flash-lite", " Flash Lite")
      .replace("-flash", " Flash")
      .replace("-pro", " Pro");
    setProgress(`Startar... (${modelShortName})`);

    // Skapa AbortController för att kunna avbryta
    abortControllerRef.current = new AbortController();

    // Add loading message
    const loadingId = (Date.now() + 1).toString();
    setMessages((prev) => [
      ...prev,
      {
        id: loadingId,
        role: "assistant",
        content: "",
        timestamp: new Date(),
        isLoading: true,
      },
    ]);

    // Helper för att uppdatera progress
    const updateProgress = (step: string) => {
      setProgress(step);
      console.log(`[PROGRESS] ${step}`);
    };

    try {
      // Logga användarfrågan och modell
      console.log(`[CHAT] Using model: ${activeModel}, API key provided: ${!!apiKey}`);
      updateProgress("📝 Analyserar frågan...");
      await logToServer('INFO', 'QUERY', `Ny fråga: "${userMessage.content}"`, {
        question: userMessage.content,
        model: activeModel
      });

      // Skapa konversationshistorik för kontext (senaste 4 meddelanden)
      const recentHistory = messages
        .filter(m => !m.isLoading)
        .slice(-4)
        .map(m => ({ role: m.role, content: m.content }));

      // First, analyze the query to understand intent
      const analyzeResponse = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: userMessage.content,
          conversationHistory: recentHistory,
          apiKey,
          model,
        }),
      });

      // Starta kontext med snabbreferens och beräkningstips för AI:n
      let context = `=== SNABBREFERENS: Vanliga KPIs ===
• Befolkning: N01951 (folkmängd), N01963 (förändring %)
• Utrikes födda: N02926 (andel %)
• Sjukfrånvaro: N00090 (totalt %), N00092-94 (åldersgrupper)
• Arbetslöshet: N00925 (totalt %)
• Egenföretagare: N02251 (andel bostad), N02252 (andel arbetsställe)
• Nystartade företag: N00999 (per 1000 inv), N01003 (antal)
• Skolmat: N15013 (grundskola kr/elev)
• Lärartäthet: N15033 (elever/lärare)
• REGIONER - Admin: N60063 (årsarbetare ledning/stöd), N63012 (nettokostnad)
• REGIONER - Befolkning: N01951 fungerar även för regioner
• Skolresultat: N15428 (meritvärde), N15403 (gymnasiebehörighet)
• Skatt: N00900 (total), N00901 (kommun)
• Äldreomsorg: N28013 (kostnad/äldre)

=== BERÄKNINGSTIPS ===
• ANTAL = andel% × totalantal / 100
• FÖRÄNDRING = värde_år2 - värde_år1

`;

      let foundKpis: { id: string; title: string; hasOuData?: boolean }[] = [];
      let foundMunicipalities: { id: string; title: string }[] = [];
      let yearsToFetch: number[] = [];
      const kpiDescriptions: { [id: string]: string } = {};

      if (!analyzeResponse.ok) {
        let errorData;
        try {
          const text = await analyzeResponse.text();
          errorData = text ? JSON.parse(text) : { error: 'Tomt svar från server' };
        } catch {
          errorData = { error: 'Kunde inte tolka serversvaret' };
        }
        await logToServer('ERROR', 'ANALYZE', 'Analysfel', { 
          status: analyzeResponse.status,
          error: errorData.error || 'Okänt fel'
        });
        
        if (analyzeResponse.status === 401) {
          throw new Error('Ogiltig API-nyckel. Kontrollera att du har angett en giltig Gemini API-nyckel i inställningarna.');
        }
        throw new Error(errorData.error || 'Ett fel uppstod vid analys av frågan');
      }

      if (analyzeResponse.ok) {
        updateProgress("🔍 Söker relevanta KPIs...");
        let analysis;
        try {
          const text = await analyzeResponse.text();
          const parsed = JSON.parse(text);
          analysis = parsed.analysis;
          if (!analysis) {
            throw new Error('Inget analysis-objekt i svaret');
          }
        } catch (e) {
          await logToServer('ERROR', 'ANALYZE', 'JSON-parse fel', { error: String(e) });
          throw new Error('Kunde inte tolka AI-svaret. Försök igen.');
        }
        
        // ALLTID extrahera år från frågan med regex som backup
        const yearMatches = userMessage.content.match(/\b(19|20)\d{2}\b/g);
        const yearRangeMatch = userMessage.content.match(/(\d{4})\s*[-–]\s*(\d{4})/);
        
        let regexYears: number[] = [];
        if (yearRangeMatch) {
          const startYear = parseInt(yearRangeMatch[1]);
          const endYear = parseInt(yearRangeMatch[2]);
          for (let y = startYear; y <= endYear; y++) {
            regexYears.push(y);
          }
        } else if (yearMatches) {
          regexYears = yearMatches.map(y => parseInt(y));
        }
        
        // Fallback: Detektera skolnivåfrågor om AI:n missar ouLevel
        const lowerQuestion = userMessage.content.toLowerCase();
        const isSchoolQuery = lowerQuestion.includes('skola') || 
                              lowerQuestion.includes('skolor') ||
                              lowerQuestion.includes('gymnasium') ||
                              lowerQuestion.includes('förskola');
        
        // Sätt ouLevel automatiskt om det ser ut som en skolfråga
        if (isSchoolQuery && !analysis.ouLevel) {
          analysis.ouLevel = true;
          analysis.ouType = lowerQuestion.includes('gymnasium') ? 'gymnasium' :
                            lowerQuestion.includes('förskola') ? 'förskola' : 'grundskola';
        }
        
        // Logga analysresultatet inklusive ouLevel
        await logToServer('INFO', 'ANALYZE', 'AI-analys klar', {
          municipalities: analysis.municipalityNames,
          aiYears: analysis.years,
          regexYears: regexYears,
          ouLevel: analysis.ouLevel,
          ouType: analysis.ouType,
          explanation: analysis.explanation
        });
        
        // Prioritera regex-extraherade år om de finns, annars AI:ns år
        if (regexYears.length > 0) {
          yearsToFetch = regexYears;
          await logToServer('INFO', 'ANALYZE', 'Använder regex-extraherade år', { years: yearsToFetch });
        } else if (analysis.years?.length > 0) {
          yearsToFetch = analysis.years;
        } else {
          const currentYear = new Date().getFullYear();
          yearsToFetch = [currentYear - 1, currentYear - 2];
          await logToServer('WARN', 'ANALYZE', 'Inga år hittade, använder standard', { years: yearsToFetch });
        }

        await logToServer('INFO', 'FLOW', 'Går vidare efter år-analys', { 
          kpiCount: analysis.kpiIds?.length || 0,
          municipalityCount: analysis.municipalityNames?.length || 0,
          intent: analysis.intent
        });

        // ========== NYA METODEN: AI:n returnerar EXAKTA KPI-IDs ==========
        // AI:n har tillgång till hela KPI-indexet och väljer själv rätt KPIs
        if (analysis.kpiIds?.length > 0) {
          await logToServer('INFO', 'KPI_SELECT', 'AI valde KPI-IDs direkt', { 
            kpiIds: analysis.kpiIds,
            explanation: analysis.explanation
          });
          
          context += `\n\n=== AI-VALDA KPIs ===\n`;
          context += `${analysis.explanation || 'AI valde dessa KPIs baserat på frågan'}\n\n`;
          
          // Hämta KPI-detaljer för de valda ID:na
          for (const kpiId of analysis.kpiIds) {
            // Hämta KPI-metadata från API
            try {
              const kpiResponse = await fetch(`/api/kpis?id=${encodeURIComponent(kpiId)}`);
              if (kpiResponse.ok) {
                const kpiData = await kpiResponse.json();
                if (kpiData.kpi) {
                  foundKpis.push({ 
                    id: kpiData.kpi.id, 
                    title: kpiData.kpi.title, 
                    hasOuData: kpiData.kpi.has_ou_data 
                  });
                  if (kpiData.kpi.description) {
                    kpiDescriptions[kpiId] = kpiData.kpi.description;
                  }
                  context += `✓ ${kpiId}: ${kpiData.kpi.title}\n`;
                } else {
                  // KPI inte hittad i lokal databas, lägg till ändå
                  foundKpis.push({ id: kpiId, title: `KPI ${kpiId}`, hasOuData: false });
                  context += `? ${kpiId}: (detaljer saknas)\n`;
                }
              }
            } catch (e) {
              foundKpis.push({ id: kpiId, title: `KPI ${kpiId}`, hasOuData: false });
              context += `? ${kpiId}: (kunde inte hämta detaljer)\n`;
            }
          }
          
          await logToServer('INFO', 'KPI_SELECT', `Använder ${foundKpis.length} AI-valda KPIs`, {
            kpiIds: foundKpis.map(k => k.id)
          });
        }

        // Sammanfattning av KPIs
        if (foundKpis.length > 0) {
          context += `\n\n=== VALDA KPIs FÖR DATAHÄMTNING ===\n`;
          foundKpis.forEach((kpi, i) => {
            context += `${i + 1}. ${kpi.id}: ${kpi.title}\n`;
          });
        }

        // Fetch municipalities - använd LOKAL databas för snabbhet
        if (analysis.municipalityNames?.length > 0) {
          // Hämta kommun-lookup från API (cachas på server)
          const munLookupResponse = await fetch('/api/municipalities');
          let localMunLookup: { [name: string]: { id: string; name: string; type?: string } } = {};
          let allMunicipalities: { id: string; name: string; type: string }[] = [];
          
          if (munLookupResponse.ok) {
            const munLookupData = await munLookupResponse.json();
            localMunLookup = munLookupData.lookup || {};
            allMunicipalities = munLookupData.municipalities || [];
          }
          
          // Specialfall: ALLA_REGIONER - hämta alla regioner (type L)
          if (analysis.municipalityNames.includes('ALLA_REGIONER')) {
            updateProgress(`🏛️ Hämtar alla regioner...`);
            const regions = allMunicipalities.filter(m => m.type === 'L' && m.id !== '0000'); // Exkludera Riket
            for (const region of regions) {
              if (!foundMunicipalities.some(fm => fm.id === region.id)) {
                foundMunicipalities.push({ id: region.id, title: region.name });
              }
            }
            context += `\n=== ALLA REGIONER (${foundMunicipalities.length} st) ===\n`;
            await logToServer('INFO', 'MUNICIPALITY', `Hämtade alla ${foundMunicipalities.length} regioner`);
          } 
          // Specialfall: ALLA_KOMMUNER - hämta alla kommuner (type K)
          else if (analysis.municipalityNames.includes('ALLA_KOMMUNER')) {
            updateProgress(`🏘️ Hämtar alla kommuner...`);
            const kommuner = allMunicipalities.filter(m => m.type === 'K');
            for (const kommun of kommuner) {
              if (!foundMunicipalities.some(fm => fm.id === kommun.id)) {
                foundMunicipalities.push({ id: kommun.id, title: kommun.name });
              }
            }
            context += `\n=== ALLA KOMMUNER (${foundMunicipalities.length} st) ===\n`;
            await logToServer('INFO', 'MUNICIPALITY', `Hämtade alla ${foundMunicipalities.length} kommuner`);
          } else {
            updateProgress(`🏘️ Söker ${analysis.municipalityNames.length} kommuner/regioner...`);
            await logToServer('INFO', 'MUNICIPALITY', 'Söker kommuner/regioner (lokal databas)', { 
              originalNames: analysis.municipalityNames
            });
            
            for (const originalName of analysis.municipalityNames) {
              if (!originalName) continue;
              
              const cleanedName = cleanMunicipalityName(originalName);
              const lowerName = cleanedName.toLowerCase();
              const isRegion = isRegionName(originalName);
              const baseName = extractBaseName(originalName).toLowerCase();
              
              let found = false;
              
              // Om det är en region, sök först efter region-varianter
              if (isRegion) {
                // Försök med olika region-namnformat
                const regionVariants = [
                  `region ${baseName}`,           // "region örebro"
                  `region ${baseName} län`,       // "region örebro län"
                  `${baseName} län`,              // "örebro län" (äldre format)
                  lowerName                       // originalnamnet rensat
                ];
                
                for (const variant of regionVariants) {
                  const mun = localMunLookup[variant];
                  if (mun && mun.type === 'L' && !foundMunicipalities.some(fm => fm.id === mun.id)) {
                    foundMunicipalities.push({ id: mun.id, title: mun.name });
                    context += `\nRegion: ${mun.name} (${mun.id})\n`;
                    await logToServer('INFO', 'MUNICIPALITY', `Hittade region: ${mun.name}`, { id: mun.id, variant });
                    found = true;
                    break;
                  }
                }
                
                // Fallback: sök bland alla regioner efter basnamnet
                if (!found) {
                  const matchingRegion = allMunicipalities.find(m => 
                    m.type === 'L' && m.name.toLowerCase().includes(baseName)
                  );
                  if (matchingRegion && !foundMunicipalities.some(fm => fm.id === matchingRegion.id)) {
                    foundMunicipalities.push({ id: matchingRegion.id, title: matchingRegion.name });
                    context += `\nRegion: ${matchingRegion.name} (${matchingRegion.id})\n`;
                    await logToServer('INFO', 'MUNICIPALITY', `Hittade region (fallback): ${matchingRegion.name}`, { id: matchingRegion.id });
                    found = true;
                  }
                }
              }
              
              // Om det inte är en region eller om region-sökningen misslyckades, sök kommun
              if (!found) {
                const mun = localMunLookup[lowerName] || localMunLookup[baseName];
                
                if (mun && !foundMunicipalities.some(fm => fm.id === mun.id)) {
                  foundMunicipalities.push({ id: mun.id, title: mun.name });
                  const type = mun.type === 'L' ? 'Region' : 'Kommun';
                  context += `\n${type}: ${mun.name} (${mun.id})\n`;
                  await logToServer('INFO', 'MUNICIPALITY', `Hittade: ${mun.name}`, { id: mun.id, type: mun.type });
                  found = true;
                }
              }
              
              // Fallback: Sök via API om lokal lookup misslyckas
              if (!found) {
                const munResponse = await fetch(
                  `/api/kolada?endpoint=municipality&title=${encodeURIComponent(baseName)}`
                );
                if (munResponse.ok) {
                  const munData = await munResponse.json();
                  const preferredType = isRegion ? 'L' : 'K';
                  const exactMatch = munData.values?.find((m: { title: string; type: string }) => 
                    m.title.toLowerCase().includes(baseName) && m.type === preferredType
                  ) || munData.values?.find((m: { title: string; type: string }) => 
                    m.title.toLowerCase().includes(baseName)
                  );
                  if (exactMatch && !foundMunicipalities.some(fm => fm.id === exactMatch.id)) {
                    foundMunicipalities.push({ id: exactMatch.id, title: exactMatch.title });
                    context += `\n${exactMatch.type === 'L' ? 'Region' : 'Kommun'}: ${exactMatch.title} (${exactMatch.id})\n`;
                    await logToServer('INFO', 'MUNICIPALITY', `Hittade via API: ${exactMatch.title}`, { id: exactMatch.id });
                  }
                }
              }
            }
          }
          
          await logToServer('INFO', 'MUNICIPALITY', `Totalt ${foundMunicipalities.length} kommuner`, {
            municipalities: foundMunicipalities.map(m => ({ id: m.id, name: m.title }))
          });
        }

        // ========== DYNAMISK ENHETSSÖKNING (OU) ==========
        // Samma approach som dina Python-scripts:
        // 1. Sök enheter med namn via /ou?title=<namn>
        // 2. Hämta data via /oudata med OU-ID
        
        let foundUnits: { id: string; title: string; municipality: string }[] = [];
        const lowerQuery = userMessage.content.toLowerCase();
        
        // Determine if we're dealing with unit queries
        // NYA: stöd för ouLevel från analyze
        const isUnitQuery = 
          analysis.ouLevel === true ||
          analysis.intent === "get_unit_data" || 
          analysis.intent === "list_units" ||
          analysis.unitSearchTerms?.length > 0 ||
          analysis.unitType;
        
        // Get OU type code for filtering
        const ouTypeCode = analysis.unitType ? OU_TYPES[analysis.unitType as keyof typeof OU_TYPES] : 
          lowerQuery.includes("grundskol") || lowerQuery.includes("skola") ? "V15" :
          lowerQuery.includes("förskol") ? "V11" :
          lowerQuery.includes("gymnasium") ? "V17" :
          lowerQuery.includes("äldreboende") ? "V23" :
          lowerQuery.includes("hemtjänst") ? "V21" : null;
        
        if (isUnitQuery) {
          // STRATEGY -1: LISTA ENHETER (ingen KPI-data behövs)
          // För frågor som "Hur många skolor finns i X?" eller "Vilka förskolor finns?"
          if (analysis.intent === "list_units" && foundMunicipalities.length > 0) {
            const ouType = analysis.ouType || 'all';
            const munIds = foundMunicipalities.map(m => m.id).join(',');
            
            // Skapa en lookup från kommun-ID till namn
            const munIdToName: { [id: string]: string } = {};
            foundMunicipalities.forEach(m => { munIdToName[m.id] = m.title; });
            
            updateProgress(`🏫 Listar enheter i ${foundMunicipalities.length} kommuner...`);
            await logToServer('INFO', 'LIST_UNITS', `Hämtar enhetslista för ${foundMunicipalities.length} kommuner`, { ouType });
            
            // Hämta ALLA enhetstyper om ouType är "all"
            const typesToFetch = ouType === 'all' 
              ? ['grundskola', 'gymnasium', 'förskola'] 
              : [ouType];
            
            const allUnits: { id: string; name: string; type: string; municipalityId: string; municipalityName: string }[] = [];
            
            for (const type of typesToFetch) {
              try {
                const schoolsResponse = await fetch(
                  `/api/schools?municipalities=${munIds}&type=${type}`,
                  { signal: AbortSignal.timeout(30000) }
                );
                
                if (schoolsResponse.ok) {
                  const schoolsData = await schoolsResponse.json();
                  const schools = schoolsData.schools || [];
                  
                  for (const school of schools) {
                    allUnits.push({
                      id: school.id,
                      name: school.name,
                      type: school.type || type,
                      municipalityId: school.municipalityId,
                      municipalityName: munIdToName[school.municipalityId] || school.municipalityId
                    });
                    
                    // Lägg till i foundUnits för kompatibilitet
                    foundUnits.push({
                      id: school.id,
                      title: school.name,
                      municipality: school.municipalityId
                    });
                  }
                  
                  await logToServer('INFO', 'LIST_UNITS', `✓ Hittade ${schools.length} ${type}`);
                }
              } catch (e) {
                await logToServer('ERROR', 'LIST_UNITS', `Fel vid hämtning av ${type}`, { error: String(e) });
              }
            }
            
            // Gruppera per typ och kommun
            const byType: { [type: string]: typeof allUnits } = {};
            allUnits.forEach(u => {
              if (!byType[u.type]) byType[u.type] = [];
              byType[u.type].push(u);
            });
            
            // Bygg context för AI:n
            context += `\n\n=== ENHETER I ${foundMunicipalities.map(m => m.title).join(', ').toUpperCase()} ===\n`;
            context += `Totalt: ${allUnits.length} enheter\n\n`;
            
            // Typnamn på svenska
            const typeNames: { [key: string]: string } = {
              'grundskola': 'Grundskolor',
              'gymnasium': 'Gymnasieskolor', 
              'förskola': 'Förskolor',
              'äldreboende': 'Äldreboenden',
              'hemtjänst': 'Hemtjänstenheter'
            };
            
            for (const [type, units] of Object.entries(byType)) {
              const typeName = typeNames[type] || type;
              context += `📚 ${typeName} (${units.length} st):\n`;
              
              // Gruppera per kommun om flera kommuner
              if (foundMunicipalities.length > 1) {
                const byMun: { [munName: string]: typeof units } = {};
                units.forEach(u => {
                  if (!byMun[u.municipalityName]) byMun[u.municipalityName] = [];
                  byMun[u.municipalityName].push(u);
                });
                
                for (const [munName, munUnits] of Object.entries(byMun)) {
                  context += `\n  ${munName} (${munUnits.length}):\n`;
                  munUnits.forEach(u => {
                    context += `    - ${u.name}\n`;
                  });
                }
              } else {
                units.forEach(u => {
                  context += `  - ${u.name}\n`;
                });
              }
              context += '\n';
            }
            
            // Sammanfattning
            context += `\n=== SAMMANFATTNING ===\n`;
            for (const [type, units] of Object.entries(byType)) {
              const typeName = typeNames[type] || type;
              context += `${typeName}: ${units.length} st\n`;
            }
            context += `TOTALT: ${allUnits.length} enheter\n`;
            
            await logToServer('INFO', 'LIST_UNITS', `Totalt ${allUnits.length} enheter listade`);
            
            // Sätt flagga att vi redan har hanterat detta - hoppa över datahämtning
            // Vi behöver inte hämta KPI-data för listningsfrågor
          }
          // STRATEGY 0: DIREKT OUDATA - Hämta data+skolnamn i ett steg (mest effektiv)
          // Använder /api/oudata-by-municipality som kombinerar oudata + ou-lookup
          else if (analysis.ouLevel === true && foundMunicipalities.length > 0 && foundKpis.length > 0) {
            const ouType = analysis.ouType || 'grundskola';
            const ouTypePlural = ouType === 'grundskola' ? 'grundskolor' : 
                                 ouType === 'gymnasium' ? 'gymnasier' : 
                                 ouType === 'förskola' ? 'förskolor' : `${ouType}r`;
            
            const dataYears = yearsToFetch.length > 0 ? yearsToFetch.slice(0, 2) : [new Date().getFullYear() - 1];
            const munIds = foundMunicipalities.map(m => m.id).join(',');
            
            // Skapa en lookup från kommun-ID till namn
            const munIdToName: { [id: string]: string } = {};
            foundMunicipalities.forEach(m => { munIdToName[m.id] = m.title; });
            
            updateProgress(`📊 Hämtar ${ouTypePlural}-data för ${foundMunicipalities.length} kommuner...`);
            
            // Använd den nya direkta endpointen för varje KPI+år
            const ouDataResults: { 
              ouId: string; 
              ouName: string; 
              municipalityId: string;
              municipalityName: string;
              ouType: string;
              kpiId: string; 
              year: number; 
              value: number 
            }[] = [];
            
            for (const kpi of foundKpis.slice(0, 3)) {
              for (const year of dataYears) {
                try {
                  // SMART STRATEGI: Använd /api/oudata-smart som automatiskt hanterar cache + API
                  const ouDataUrl = `/api/oudata-smart?kpi=${kpi.id}&municipalities=${munIds}&year=${year}&type=${ouType}`;
                  
                  // Visa feedback om vad vi gör
                  updateProgress(`🔍 Söker enhetsdata för ${kpi.id} (${kpi.title?.substring(0, 30) || ''}) år ${year}...`);
                  await logToServer('INFO', 'OUDATA_SMART', `Söker ${kpi.id} år ${year}`, { url: ouDataUrl });
                  
                  const response = await fetch(ouDataUrl, { signal: AbortSignal.timeout(45000) });
                  
                  if (response && response.ok) {
                    const data = await response.json();
                    
                    // Visa feedback baserat på källa
                    if (data.source === 'local-cache') {
                      updateProgress(`✓ Hittade ${data.count} ${ouTypePlural} i lokal cache för ${kpi.id}`);
                    } else if (data.source === 'api') {
                      updateProgress(`✓ Hämtade ${data.count} ${ouTypePlural} från Kolada API för ${kpi.id}`);
                    } else if (data.source === 'not-found') {
                      updateProgress(`⚠️ Ingen data hittades för ${kpi.id} år ${year}`);
                      await logToServer('WARN', 'OUDATA_SMART', data.message);
                      continue;
                    }
                    
                    await logToServer('INFO', 'OUDATA_SMART', data.message, { 
                      source: data.source, 
                      count: data.count,
                      totalBeforeFilter: data.totalBeforeFilter 
                    });
                    
                    const results = data.data || [];
                    
                    for (const item of results) {
                      if (item.value !== null) {
                        ouDataResults.push({
                          ouId: item.ouId,
                          ouName: item.ouName || item.ouId,
                          municipalityId: item.municipalityId,
                          municipalityName: munIdToName[item.municipalityId] || item.municipalityId,
                          ouType: item.ouType || ouType,
                          kpiId: kpi.id,
                          year: year,
                          value: item.value
                        });
                        
                        // Lägg till i foundUnits för kompatibilitet
                        if (!foundUnits.some(u => u.id === item.ouId)) {
                          foundUnits.push({
                            id: item.ouId,
                            title: item.ouName || item.ouId,
                            municipality: item.municipalityId
                          });
                        }
                      }
                    }
                    
                    await logToServer('INFO', 'OUDATA_SMART', `✓ ${kpi.id} år ${year}: ${results.length} ${ouTypePlural} med data`);
                  } else {
                    updateProgress(`⚠️ Kunde inte hämta data för ${kpi.id} - försöker nästa KPI...`);
                    await logToServer('WARN', 'OUDATA_SMART', `Fel vid hämtning av ${kpi.id}`, { status: response?.status });
                  }
                } catch (e) {
                  const errMsg = e instanceof Error ? e.message : String(e);
                  if (errMsg.includes('timeout') || errMsg.includes('abort')) {
                    updateProgress(`⏱️ Timeout för ${kpi.id} - Kolada API svarar långsamt`);
                  } else {
                    updateProgress(`⚠️ Fel vid hämtning av ${kpi.id}: ${errMsg.substring(0, 50)}`);
                  }
                  await logToServer('ERROR', 'OUDATA_SMART', `Fel: ${errMsg}`, { kpi: kpi.id, year });
                }
              }
            }
            
            // Presentera datan direkt istället för att göra fler API-anrop
            if (ouDataResults.length > 0) {
              const kpiTitle = foundKpis[0]?.title || foundKpis[0]?.id;
              
              context += `\n\n=== SKOLNIVÅ DATA (${ouType}) ===\n`;
              context += `KPI: ${foundKpis[0]?.id}: ${kpiTitle}\n`;
              context += `Antal ${ouTypePlural} med data: ${foundUnits.length}\n\n`;
              
              // Gruppera per år och sortera på värde
              const yearGroups: { [year: number]: typeof ouDataResults } = {};
              ouDataResults.forEach(r => {
                if (!yearGroups[r.year]) yearGroups[r.year] = [];
                yearGroups[r.year].push(r);
              });
              
              for (const [year, yearData] of Object.entries(yearGroups)) {
                const sorted = yearData.sort((a, b) => b.value - a.value);
                context += `\n📊 År ${year} (${sorted.length} ${ouTypePlural}):\n`;
                
                // Visa topp 15 och botten 5 med skoltyp
                context += `\n  TOPP 15:\n`;
                sorted.slice(0, 15).forEach((r, i) => {
                  const typeLabel = r.ouType === 'grundskola' ? '[GS]' : 
                                   r.ouType === 'gymnasium' ? '[GY]' : 
                                   r.ouType === 'forskola' ? '[FS]' : `[${r.ouType}]`;
                  context += `    ${i + 1}. ${typeLabel} ${r.ouName} (${r.municipalityName}): ${r.value.toLocaleString('sv-SE')}\n`;
                });
                
                if (sorted.length > 20) {
                  context += `\n  BOTTEN 5:\n`;
                  sorted.slice(-5).forEach((r, i) => {
                    const rank = sorted.length - 4 + i;
                    const typeLabel = r.ouType === 'grundskola' ? '[GS]' : 
                                     r.ouType === 'gymnasium' ? '[GY]' : 
                                     r.ouType === 'forskola' ? '[FS]' : `[${r.ouType}]`;
                    context += `    ${rank}. ${typeLabel} ${r.ouName} (${r.municipalityName}): ${r.value.toLocaleString('sv-SE')}\n`;
                  });
                }
                
                // Statistik
                const values = sorted.map(r => r.value);
                const avg = values.reduce((a, b) => a + b, 0) / values.length;
                const highest = sorted[0];
                const lowest = sorted[sorted.length - 1];
                
                context += `\n  SAMMANFATTNING:\n`;
                const highTypeLabel = highest.ouType === 'grundskola' ? 'grundskola' : 
                                     highest.ouType === 'gymnasium' ? 'gymnasieskola' : highest.ouType;
                const lowTypeLabel = lowest.ouType === 'grundskola' ? 'grundskola' : 
                                    lowest.ouType === 'gymnasium' ? 'gymnasieskola' : lowest.ouType;
                context += `    → Högst: ${highest.ouName} (${highTypeLabel}, ${highest.municipalityName}): ${highest.value.toLocaleString('sv-SE')}\n`;
                context += `    → Lägst: ${lowest.ouName} (${lowTypeLabel}, ${lowest.municipalityName}): ${lowest.value.toLocaleString('sv-SE')}\n`;
                context += `    → Genomsnitt: ${avg.toLocaleString('sv-SE', { maximumFractionDigits: 1 })}\n`;
                context += `    → Antal ${ouTypePlural}: ${sorted.length}\n`;
                context += `\n  FÖRKLARING: [GS]=grundskola, [GY]=gymnasium, [FS]=förskola\n`;
              }
              
              await logToServer('INFO', 'OUDATA_DIRECT', `Totalt ${ouDataResults.length} datapunkter för ${foundUnits.length} ${ouTypePlural}`);
              
              // Hoppa över den gamla oudata-hämtningen nedan
              // genom att sätta flagga att data redan är hämtad
            }
          }
          // FALLBACK: Hämta skollista först om direkt-metoden inte användes
          else if (analysis.ouLevel === true && foundMunicipalities.length > 0) {
            const ouType = analysis.ouType || 'grundskola';
            const ouTypePlural = ouType === 'grundskola' ? 'grundskolor' : 
                                 ouType === 'gymnasium' ? 'gymnasier' : 
                                 ouType === 'förskola' ? 'förskolor' : `${ouType}r`;
            
            // BATCH: Hämta alla skolor i ETT anrop istället för ett per kommun!
            updateProgress(`🏫 Hämtar ${ouTypePlural} i ${foundMunicipalities.length} kommuner...`);
            
            try {
              const munIds = foundMunicipalities.map(m => m.id).join(',');
              const schoolsResponse = await fetch(
                `/api/schools?municipalities=${munIds}&type=${ouType}`,
                { signal: AbortSignal.timeout(60000) } // 60 sek för batch
              );
              
              if (schoolsResponse.ok) {
                const schoolsData = await schoolsResponse.json();
                const schools = schoolsData.schools || [];
                
                for (const school of schools) {
                  foundUnits.push({
                    id: school.id,
                    title: school.name,
                    municipality: school.municipalityId
                  });
                }
                
                await logToServer('INFO', 'SCHOOLS', `✓ Hämtade ${schools.length} ${ouTypePlural} i ${foundMunicipalities.length} kommuner (batch)`, {
                  exampleSchools: schools.slice(0, 5).map((s: {name: string}) => s.name)
                });
              } else {
                const errorText = await schoolsResponse.text();
                await logToServer('ERROR', 'SCHOOLS', 'Batch-hämtning misslyckades', { error: errorText });
              }
            } catch (e) {
              await logToServer('ERROR', 'SCHOOLS', 'Fel vid batch-hämtning', { error: String(e) });
            }
            
            if (foundUnits.length > 0) {
              context += `\n\n=== SKOLOR HITTADE (${foundUnits.length} st) ===\n`;
              foundUnits.slice(0, 20).forEach(u => {
                context += `- ${u.title}\n`;
              });
              if (foundUnits.length > 20) {
                context += `... och ${foundUnits.length - 20} till\n`;
              }
            }
          }
          // STRATEGY 1: Search by specific unit name (like "Kumlaby")
          else if (analysis.unitSearchTerms?.length > 0) {
            context += `\n\n=== SÖK ENHETER ===\n`;
            for (const searchTerm of analysis.unitSearchTerms) {
              context += `Söker efter "${searchTerm}"...\n`;
              
              const ouResponse = await fetch(
                `/api/kolada?endpoint=ou&title=${encodeURIComponent(searchTerm)}&per_page=50`
              );
              
              if (ouResponse.ok) {
                const ouData = await ouResponse.json();
                let units = ouData.values || [];
                
                // Filter by type if specified
                if (ouTypeCode) {
                  units = units.filter((ou: { id: string }) => ou.id.startsWith(ouTypeCode));
                }
                
                // Filter by municipality if specified
                if (foundMunicipalities.length > 0) {
                  const munIds = foundMunicipalities.map(m => m.id);
                  units = units.filter((ou: { municipality: string }) => munIds.includes(ou.municipality));
                }
                
                if (units.length > 0) {
                  context += `\nHittade ${units.length} enheter:\n`;
                  units.slice(0, 15).forEach((ou: { id: string; title: string; municipality: string }) => {
                    context += `- ${ou.title} (ID: ${ou.id}, Kommun: ${ou.municipality})\n`;
                    foundUnits.push(ou);
                  });
                } else {
                  context += `Inga enheter hittades för "${searchTerm}"\n`;
                }
              }
            }
          }
          // STRATEGY 2: List units in a municipality (like "skolor i Stockholm")
          else if (foundMunicipalities.length > 0 && (analysis.intent === "list_units" || ouTypeCode)) {
            for (const mun of foundMunicipalities.slice(0, 2)) {
              // Search with municipality name as part of title
              const ouResponse = await fetch(
                `/api/kolada?endpoint=ou&title=${encodeURIComponent(mun.title)}&per_page=200`
              );
              
              if (ouResponse.ok) {
                const ouData = await ouResponse.json();
                let units = (ouData.values || []).filter((ou: { municipality: string }) => 
                  ou.municipality === mun.id
                );
                
                // Filter by type if specified
                if (ouTypeCode) {
                  units = units.filter((ou: { id: string }) => ou.id.startsWith(ouTypeCode));
                }
                
                if (units.length > 0) {
                  const typeName = ouTypeCode ? 
                    (Object.entries(OU_TYPES).find(([_, v]) => v === ouTypeCode)?.[0] || "enheter") : 
                    "enheter";
                  context += `\n\n=== ${typeName.toUpperCase()} I ${mun.title.toUpperCase()} ===\n`;
                  context += `Totalt ${units.length} enheter med data i Kolada:\n\n`;
                  units.slice(0, 25).forEach((ou: { id: string; title: string }) => {
                    context += `- ${ou.title} (ID: ${ou.id})\n`;
                    foundUnits.push({ ...ou, municipality: mun.id });
                  });
                  if (units.length > 25) {
                    context += `\n... och ${units.length - 25} till\n`;
                  }
                } else {
                  const emptyTypeName = ouTypeCode ? 
                    (Object.entries(OU_TYPES).find(([_, v]) => v === ouTypeCode)?.[0] || "enheter") : 
                    "enheter";
                  context += `\nIngen enhetsdata hittades för ${emptyTypeName} i ${mun.title}.\n`;
                }
              }
            }
          }
        }
        
        // FETCH ACTUAL UNIT DATA (oudata) if we found units
        // SKIP this for list_units intent - we only want to list units, not fetch KPI data
        if (foundUnits.length > 0 && analysis.intent !== "list_units" && (analysis.ouLevel === true || analysis.intent === "get_unit_data" || analysis.unitSearchTerms?.length > 0)) {
          // Determine years to fetch
          const dataYears = yearsToFetch.length > 0 ? yearsToFetch.slice(0, 3) : [new Date().getFullYear() - 1, new Date().getFullYear() - 2];
          
          // NYA: Om AI:n har valt specifika KPIs, använd dem
          const kpisToFetchForUnits = foundKpis.length > 0 ? foundKpis.slice(0, 3) : [];
          
          const allKpiIds = new Set<string>();
          const unitDataResults: { unit: string; year: number; kpiId: string; value: number }[] = [];
          
          // NYA: Använd /api/oudata för effektivare hämtning med valda KPIs
          if (kpisToFetchForUnits.length > 0 && analysis.ouLevel === true) {
            updateProgress(`📊 Hämtar skoldata för ${foundUnits.length} skolor...`);
            
            for (const kpi of kpisToFetchForUnits) {
              for (const year of dataYears) {
                const ouIds = foundUnits.slice(0, 30).map(u => u.id).join(',');
                const ouDataUrl = `/api/oudata?kpi=${kpi.id}&ous=${ouIds}&year=${year}`;
                
                try {
                  const ouDataResponse = await fetch(ouDataUrl);
                  if (ouDataResponse.ok) {
                    const ouData = await ouDataResponse.json();
                    const results = ouData.data || [];
                    
                    results.forEach((item: { ouId: string; value: number | null; year: number }) => {
                      if (item.value !== null) {
                        allKpiIds.add(kpi.id);
                        const unit = foundUnits.find(u => u.id === item.ouId);
                        unitDataResults.push({
                          unit: unit?.title || item.ouId,
                          year: item.year,
                          kpiId: kpi.id,
                          value: item.value
                        });
                      }
                    });
                  }
                } catch (e) {
                  console.error('OU data fetch error:', e);
                }
              }
            }
            
            await logToServer('INFO', 'OUDATA', `Hämtade ${unitDataResults.length} datapunkter för ${foundUnits.length} skolor`);
          } else {
            // GAMMAL: Hämta all data för varje enhet
            for (const ou of foundUnits.slice(0, 5)) {
              for (const year of dataYears) {
                const ouDataUrl = `/api/kolada?endpoint=oudata&ou_id=${ou.id}&year=${year}&per_page=100`;
                
                try {
                  const ouDataResponse = await fetch(ouDataUrl);
                  if (ouDataResponse.ok) {
                    const ouData = await ouDataResponse.json();
                    const values = ouData.values || [];
                    
                    values.forEach((item: { kpi: string; values: Array<{ value: number | null; gender: string | null }> }) => {
                      const val = item.values?.find((v: { gender: string | null }) => v.gender === 'T' || v.gender === null);
                      if (val?.value !== null && val?.value !== undefined) {
                        allKpiIds.add(item.kpi);
                        unitDataResults.push({
                          unit: ou.title,
                          year,
                          kpiId: item.kpi,
                          value: val.value
                        });
                      }
                    });
                  }
                } catch (e) {
                  console.error('OU data fetch error:', e);
                }
              }
            }
          }
          
          // FETCH KPI DEFINITIONS for all KPIs we found
          const kpiDefinitions: { [id: string]: { title: string; description: string } } = {};
          for (const kpiId of Array.from(allKpiIds).slice(0, 30)) {
            try {
              const kpiResponse = await fetch(`/api/kolada?endpoint=kpi/${kpiId}`);
              if (kpiResponse.ok) {
                const kpiData = await kpiResponse.json();
                if (kpiData.values?.[0]) {
                  kpiDefinitions[kpiId] = {
                    title: kpiData.values[0].title,
                    description: kpiData.values[0].description || ''
                  };
                }
              }
            } catch (e) {
              console.error('KPI definition fetch error:', e);
            }
          }
          
          // Now present the data WITH definitions
          context += `\n\n=== KPI-DEFINITIONER ===\n`;
          for (const [kpiId, def] of Object.entries(kpiDefinitions)) {
            context += `\n${kpiId}: ${def.title}\n`;
            if (def.description) {
              context += `   Beskrivning: ${def.description.substring(0, 200)}${def.description.length > 200 ? '...' : ''}\n`;
            }
          }
          
          context += `\n\n=== ENHETSDATA FRÅN KOLADA ===\n`;
          // Group by unit
          const unitGroups: { [unit: string]: { year: number; kpiId: string; value: number }[] } = {};
          unitDataResults.forEach(r => {
            if (!unitGroups[r.unit]) unitGroups[r.unit] = [];
            unitGroups[r.unit].push({ year: r.year, kpiId: r.kpiId, value: r.value });
          });
          
          for (const [unitName, data] of Object.entries(unitGroups)) {
            context += `\n📊 ${unitName}:\n`;
            // Group by year
            const yearGroups: { [year: number]: { kpiId: string; value: number }[] } = {};
            data.forEach(d => {
              if (!yearGroups[d.year]) yearGroups[d.year] = [];
              yearGroups[d.year].push({ kpiId: d.kpiId, value: d.value });
            });
            
            for (const [year, kpis] of Object.entries(yearGroups)) {
              context += `\n  År ${year}:\n`;
              kpis.slice(0, 15).forEach(({ kpiId, value }) => {
                const def = kpiDefinitions[kpiId];
                const title = def?.title || kpiId;
                context += `    - ${title}: ${value.toLocaleString('sv-SE')}\n`;
              });
              if (kpis.length > 15) {
                context += `    ... och ${kpis.length - 15} fler\n`;
              }
            }
          }
        }

        // FETCH ACTUAL DATA if we have KPIs and municipalities
        // SKIP this for list_units intent - we already have what we need
        if (foundKpis.length > 0 && foundMunicipalities.length > 0 && analysis.intent !== "list_units") {
          updateProgress(`📊 Hämtar data för ${foundMunicipalities.length} kommuner...`);
          
          const queryLowerForYears = userMessage.content.toLowerCase();
          
          // DETEKTERA OM ANVÄNDAREN VILL HA ALLA ÅR
          const wantsAllYears = queryLowerForYears.includes('varje år') || 
                               queryLowerForYears.includes('alla år') ||
                               queryLowerForYears.includes('per år') ||
                               queryLowerForYears.includes('år för år') ||
                               (yearsToFetch.length <= 10 && foundMunicipalities.length <= 5); // Små frågor = alla år
          
          let effectiveYears = yearsToFetch;
          
          if (wantsAllYears) {
            // Användaren vill ha alla år - ge dem alla!
            effectiveYears = [...yearsToFetch].sort((a, b) => a - b);
            await logToServer('INFO', 'DATA_FETCH', `Hämtar ALLA ${effectiveYears.length} år: ${effectiveYears.join(', ')}`);
          } else if (yearsToFetch.length > 5 && foundMunicipalities.length > 10) {
            // Stor fråga - optimera för snabbhet
            const sortedYears = [...yearsToFetch].sort((a, b) => a - b);
            const firstYear = sortedYears[0];
            const lastYear = sortedYears[sortedYears.length - 1];
            
            // Fallback-år om startår saknar data
            const fallbackYears: number[] = [];
            if (firstYear < 2019) {
              fallbackYears.push(2019, 2020);
            }
            
            effectiveYears = [firstYear, ...fallbackYears.filter(y => y !== firstYear && y !== lastYear), lastYear];
            await logToServer('INFO', 'DATA_FETCH', `Stor fråga - optimerar till ${effectiveYears.length} år: ${effectiveYears.join(', ')}`);
          }
          // Annars: använd alla år (default)
          
          await logToServer('INFO', 'DATA_FETCH', `Hämtar data för ${foundKpis.length} KPIs och ${foundMunicipalities.length} kommuner`, {
            kpis: foundKpis.map(k => k.id),
            municipalities: foundMunicipalities.map(m => m.id),
            years: effectiveYears
          });
          
          // Fokusera på de mest relevanta KPIs (topp 2) för snabbare svar
          // Med batch-anrop tar varje KPI ~2-3 sekunder
          let kpisToFetch = foundKpis.slice(0, 2);
          
          // AUTOMATISK BEFOLKNINGSDATA för beräkningar
          // Lägg till N01951 om:
          // 1. Analysen säger att beräkning behövs (needsCalculation)
          // 2. Vi har procentbaserade KPIs och frågan innehåller "antal"
          // 3. Vi har procentbaserade KPIs generellt (för att möjliggöra följdfrågor)
          const queryLower = userMessage.content.toLowerCase();
          const wantsAbsolute = queryLower.includes('antal') || queryLower.includes('hur många') || analysis.needsCalculation;
          const hasPercentageKpi = kpisToFetch.some(k => 
            k.title.toLowerCase().includes('andel') || 
            k.title.includes('%') ||
            k.title.toLowerCase().includes('procent')
          );
          const hasPopulationKpi = kpisToFetch.some(k => k.id === 'N01951');
          
          if ((hasPercentageKpi || wantsAbsolute) && !hasPopulationKpi) {
            // Lägg till befolknings-KPI för beräkningar
            kpisToFetch = [{ id: 'N01951', title: 'Invånare totalt, antal' }, ...kpisToFetch];
            await logToServer('INFO', 'DATA_FETCH', 'Lade till N01951 (Folkmängd) för beräkningar');
          }
          
          // Om analysen indikerar att beräkning behövs, logga det
          if (analysis.needsCalculation) {
            await logToServer('INFO', 'DATA_FETCH', `Beräkning krävs: ${analysis.calculationType || 'okänd typ'}`);
          }
          
          await logToServer('INFO', 'DATA_FETCH', `Hämtar data för ${kpisToFetch.length} KPIs`, {
            kpiIds: kpisToFetch.map(k => k.id)
          });
          
          // Organisera data per KPI för tydligare presentation
          const dataByKpi: { [kpiId: string]: { kpiTitle: string; data: { mun: string; year: number; value: number }[] } } = {};
          
          // Skapa lookup för kommun-ID till namn
          const munIdToName: { [id: string]: string } = {};
          foundMunicipalities.forEach(m => { munIdToName[m.id] = m.title; });
          
          // BATCH API-ANROP: Dela upp i batcher om 25 kommuner (Kolada API-gräns)
          const BATCH_SIZE = 25;
          const municipalityBatches: string[][] = [];
          for (let i = 0; i < foundMunicipalities.length; i += BATCH_SIZE) {
            municipalityBatches.push(foundMunicipalities.slice(i, i + BATCH_SIZE).map(m => m.id));
          }
          
          let dataFoundCount = 0;
          let kpiIndex = 0;
          const yearsWithData: { [kpiId: string]: number[] } = {};
          const yearsWithoutData: { [kpiId: string]: number[] } = {};
          
          for (const kpi of kpisToFetch) {
            kpiIndex++;
            updateProgress(`📊 Hämtar ${kpi.id} (${kpiIndex}/${kpisToFetch.length})...`);
            await logToServer('INFO', 'DATA_FETCH', `Hämtar KPI ${kpi.id}: ${kpi.title}`);
            
            for (const year of effectiveYears) {
              let yearDataCount = 0;
              
              // Hämta data i batcher för att undvika för långa URL:er
              for (let batchIdx = 0; batchIdx < municipalityBatches.length; batchIdx++) {
                const batchMunIds = municipalityBatches[batchIdx].join(',');
                const dataUrl = `/api/kolada?endpoint=data/kpi/${kpi.id}/municipality/${batchMunIds}/year/${year}`;
              
                try {
                  // Timeout efter 60 sekunder (Kolada API är långsamt)
                  const controller = new AbortController();
                  const timeoutId = setTimeout(() => controller.abort(), 60000);
                  
                  if (municipalityBatches.length > 1) {
                    updateProgress(`📊 ${kpi.id} år ${year} (batch ${batchIdx + 1}/${municipalityBatches.length})...`);
                  } else {
                    updateProgress(`📊 ${kpi.id} år ${year}...`);
                  }
                  const dataResponse = await fetch(dataUrl, { signal: controller.signal });
                  clearTimeout(timeoutId);
                  
                  if (dataResponse.ok) {
                    const data = await dataResponse.json();
                    
                    // KOLLA OM API ÄR BLOCKERAT
                    if (data.blocked) {
                      const waitMsg = data.waitSeconds 
                        ? `Vänta ${data.waitSeconds} sekunder eller byt IP-adress.`
                        : 'Prova igen om en stund eller byt IP-adress.';
                      
                      context += `\n\n⚠️ **KOLADA API ÖVERBELASTAT**\n`;
                      context += `${data.blockMessage || 'För många anrop till API:t.'}\n`;
                      context += `${waitMsg}\n`;
                      
                      await logToServer('WARN', 'API_BLOCKED', data.blockMessage, { waitSeconds: data.waitSeconds });
                      break; // Avbryt vidare hämtning för denna batch
                    }
                    
                    if (data.values?.length > 0) {
                      for (const item of data.values) {
                        const totalValue = item.values?.find((v: { gender: string | null }) => v.gender === 'T' || v.gender === null);
                        if (totalValue?.value !== null && totalValue?.value !== undefined) {
                          if (!dataByKpi[kpi.id]) {
                            dataByKpi[kpi.id] = { kpiTitle: kpi.title, data: [] };
                          }
                          const munName = munIdToName[item.municipality] || item.municipality;
                          dataByKpi[kpi.id].data.push({
                            mun: munName,
                            year: item.period,
                            value: totalValue.value
                          });
                          dataFoundCount++;
                          yearDataCount++;
                        }
                      }
                    }
                  }
                } catch (e) {
                  const errorMsg = e instanceof Error && e.name === 'AbortError' ? 'Timeout (60s) - Kolada API långsamt' : String(e);
                  await logToServer('ERROR', 'DATA_FETCH', `Fel vid hämtning batch ${batchIdx + 1}: ${kpi.id} år ${year}`, { error: errorMsg });
                }
              } // Slut på batch-loop
              
              // Logga resultat för året (efter alla batcher)
              if (yearDataCount === 0) {
                await logToServer('WARN', 'DATA_FETCH', `⚠ ${kpi.id} år ${year}: INGEN DATA TILLGÄNGLIG för detta år`);
                if (!yearsWithoutData[kpi.id]) yearsWithoutData[kpi.id] = [];
                yearsWithoutData[kpi.id].push(year);
              } else {
                await logToServer('INFO', 'DATA_FETCH', `✓ ${kpi.id} år ${year}: ${yearDataCount} värden`);
                if (!yearsWithData[kpi.id]) yearsWithData[kpi.id] = [];
                yearsWithData[kpi.id].push(year);
              }
            }
          }
          
          // Sammanfatta datatillgänglighet för AI:n
          context += `\n\n=== DATATILLGÄNGLIGHET ===\n`;
          for (const kpiId of Object.keys(yearsWithData)) {
            const hasYears = yearsWithData[kpiId] || [];
            const missingYears = yearsWithoutData[kpiId] || [];
            if (missingYears.length > 0) {
              context += `⚠ ${kpiId}: Data finns för ${hasYears.join(', ')} men SAKNAS för ${missingYears.join(', ')}\n`;
              context += `   → Använd tidigaste tillgängliga år (${Math.min(...hasYears)}) istället för ${Math.min(...missingYears)}\n`;
            } else {
              context += `✓ ${kpiId}: Data finns för alla år (${hasYears.join(', ')})\n`;
            }
          }
          
          // Presentera data organiserat per KPI
          context += `\n\n=== FAKTISK DATA FRÅN KOLADA ===\n`;
          context += `OBS: Använd denna data för att svara på frågan! Beräkna förändring med tillgängliga år.\n\n`;
          
          for (const [kpiId, kpiData] of Object.entries(dataByKpi)) {
            context += `📊 ${kpiId}: ${kpiData.kpiTitle}\n`;
            
            // Gruppera per år och sortera för jämförelser
            const years = Array.from(new Set(kpiData.data.map(d => d.year))).sort((a, b) => b - a);
            
            for (const year of years) {
              const yearData = kpiData.data.filter(d => d.year === year).sort((a, b) => b.value - a.value);
              context += `\n  År ${year}:\n`;
              yearData.forEach((d, i) => {
                context += `    ${i + 1}. ${d.mun}: ${d.value.toLocaleString('sv-SE')}\n`;
              });
              
              // Lägg till sammanfattning
              if (yearData.length > 1) {
                const highest = yearData[0];
                const lowest = yearData[yearData.length - 1];
                const avg = yearData.reduce((sum, d) => sum + d.value, 0) / yearData.length;
                context += `    → Högst: ${highest.mun} (${highest.value.toLocaleString('sv-SE')})\n`;
                context += `    → Lägst: ${lowest.mun} (${lowest.value.toLocaleString('sv-SE')})\n`;
                context += `    → Genomsnitt: ${avg.toLocaleString('sv-SE', { maximumFractionDigits: 0 })}\n`;
              }
            }
            context += '\n';
          }
          
          await logToServer('INFO', 'DATA_FETCH', `Totalt ${dataFoundCount} datapunkter hämtade`);
        } else if (foundKpis.length > 0 && (foundMunicipalities.length === 0 || analysis.municipalityNames?.includes('ALLA_KOMMUNER'))) {
          // RIKSDATA: No specific municipality OR explicit ALLA_KOMMUNER - compare ALL municipalities
          await logToServer('INFO', 'RIKSDATA', 'Hämtar data för alla kommuner', { years: yearsToFetch });
          
          // First, fetch municipality names for lookup
          const munNameLookup: { [id: string]: string } = {};
          try {
            const munResponse = await fetch(`/api/kolada?endpoint=municipality&per_page=500`);
            if (munResponse.ok) {
              const munData = await munResponse.json();
              (munData.values || []).forEach((m: { id: string; title: string; type: string }) => {
                if (m.type === 'K') {
                  munNameLookup[m.id] = m.title;
                }
              });
            }
          } catch (e) {
            console.error('Municipality lookup error:', e);
          }
          
          // Show top KPIs with DESCRIPTIONS so AI understands what they measure
          context += `\n\n=== RELEVANTA KPIs (${foundKpis.length} hittade) ===\n`;
          for (const kpi of foundKpis.slice(0, 10)) {
            const desc = kpiDescriptions[kpi.id];
            context += `\n${kpi.id}: ${kpi.title}\n`;
            if (desc) {
              context += `  Beskrivning: ${desc.substring(0, 200)}${desc.length > 200 ? '...' : ''}\n`;
            }
          }
          
          // Determine query type
          const queryLower = userMessage.content.toLowerCase();
          const firstYear = Math.min(...yearsToFetch);
          const lastYear = Math.max(...yearsToFetch);
          
          // Kolla om användaren frågar om FÖRÄNDRING (ökade/minskade) eller RANKING (högst/lägst)
          const wantsChange = queryLower.includes('ökade') || queryLower.includes('ökat') || 
                              queryLower.includes('minskade') || queryLower.includes('minskat') ||
                              queryLower.includes('förändring') || queryLower.includes('utveckling') ||
                              (queryLower.includes('mellan') && /\d{4}.*\d{4}/.test(queryLower));
          
          const wantsRanking = queryLower.includes('högst') || queryLower.includes('lägst') ||
                               queryLower.includes('mest') || queryLower.includes('minst') ||
                               queryLower.includes('bäst') || queryLower.includes('sämst') ||
                               queryLower.includes('vilken kommun');
          
          // Om användaren vill ha ranking (inte förändring), visa absoluta värden
          const isChangeQuery = yearsToFetch.length >= 2 && wantsChange && !wantsRanking;
          
          // KOMBINERAD BERÄKNING: Om vi har flera KPIs och behöver beräkna
          const needsCombinedCalc = analysis.needsCalculation && foundKpis.length >= 2;
          
          await logToServer('INFO', 'RIKSDATA', `Frågetyp: ${needsCombinedCalc ? 'kombinerad beräkning' : isChangeQuery ? 'förändring' : 'ranking'}`, {
            wantsChange, wantsRanking, needsCombinedCalc, years: yearsToFetch.length
          });
          
          // KOMBINERAD BERÄKNING: Hämta data för ALLA KPIs och kombinera
          if (needsCombinedCalc && foundKpis.length >= 2) {
            const year = lastYear || yearsToFetch[0] || new Date().getFullYear() - 1;
            updateProgress(`📊 Hämtar data för ${foundKpis.length} KPIs och beräknar...`);
            
            context += `\n\n=== KOMBINERAD BERÄKNING (${year}) ===\n`;
            context += `\nKPIs som används:\n`;
            foundKpis.forEach(kpi => {
              context += `  - ${kpi.id}: ${kpi.title}\n`;
            });
            context += `\nBeräkningsmetod: ${analysis.explanation || 'Kombinerad data'}\n`;
            
            // Hämta data för alla KPIs
            const kpiData: { [kpiId: string]: { [munId: string]: number } } = {};
            
            for (const kpi of foundKpis) {
              updateProgress(`📥 Hämtar ${kpi.id}...`);
              kpiData[kpi.id] = {};
              
              const dataUrl = `/api/kolada?endpoint=data/kpi/${kpi.id}/year/${year}&per_page=500`;
              try {
                const dataResponse = await fetch(dataUrl);
                if (dataResponse.ok) {
                  const data = await dataResponse.json();
                  for (const item of (data.values || [])) {
                    const val = item.values?.find((v: { gender: string | null }) => v.gender === 'T' || v.gender === null);
                    if (val?.value !== null && val?.value !== undefined && munNameLookup[item.municipality]) {
                      kpiData[kpi.id][item.municipality] = val.value;
                    }
                  }
                }
              } catch (e) {
                console.error(`Error fetching ${kpi.id}:`, e);
              }
            }
            
            // Kombinera data och beräkna
            updateProgress(`🧮 Utför beräkning för alla kommuner...`);
            
            const results: { munId: string; name: string; calculatedValue: number; rawValues: { [kpiId: string]: number } }[] = [];
            
            for (const [munId, munName] of Object.entries(munNameLookup)) {
              const rawValues: { [kpiId: string]: number } = {};
              let hasAllData = true;
              
              for (const kpi of foundKpis) {
                if (kpiData[kpi.id][munId] !== undefined) {
                  rawValues[kpi.id] = kpiData[kpi.id][munId];
                } else {
                  hasAllData = false;
                  break;
                }
              }
              
              if (hasAllData) {
                // Utför beräkning baserat på vilka KPIs vi har
                let calculatedValue = 0;
                const kpiIds = foundKpis.map(k => k.id);
                
                // Lediga bostäder: (N07913/1000 × N01951) - N02938 / N01951
                if (kpiIds.includes('N07913') && kpiIds.includes('N01951') && kpiIds.includes('N02938')) {
                  const bostaderPer1000 = rawValues['N07913'];
                  const befolkning = rawValues['N01951'];
                  const hushall = rawValues['N02938'];
                  const totalaBostader = (bostaderPer1000 / 1000) * befolkning;
                  const ledigaBostader = totalaBostader - hushall;
                  calculatedValue = (ledigaBostader / befolkning) * 1000; // Per 1000 inv
                }
                // Absolut antal från andel: andel% × befolkning / 100
                else if (kpiIds.includes('N01951') && foundKpis.some(k => k.title.toLowerCase().includes('andel'))) {
                  const andelKpi = foundKpis.find(k => k.title.toLowerCase().includes('andel'));
                  if (andelKpi && rawValues[andelKpi.id] !== undefined) {
                    calculatedValue = (rawValues[andelKpi.id] / 100) * rawValues['N01951'];
                  }
                }
                // Fallback: Division av första med andra KPI
                else if (foundKpis.length === 2) {
                  calculatedValue = rawValues[foundKpis[0].id] / rawValues[foundKpis[1].id];
                }
                // Bara visa första KPI om inget annat fungerar
                else {
                  calculatedValue = rawValues[foundKpis[0].id];
                }
                
                results.push({ munId, name: munName, calculatedValue, rawValues });
              }
            }
            
            // Sortera efter beräknat värde (högst först)
            results.sort((a, b) => b.calculatedValue - a.calculatedValue);
            
            await logToServer('INFO', 'RIKSDATA', `Beräkning klar för ${results.length} kommuner`);
            
            if (results.length > 0) {
              context += `\n📈 HÖGST BERÄKNAT VÄRDE (topp 20 av ${results.length} kommuner):\n`;
              results.slice(0, 20).forEach((r, i) => {
                const rawStr = Object.entries(r.rawValues)
                  .map(([id, val]) => `${id}=${val.toLocaleString('sv-SE', { maximumFractionDigits: 1 })}`)
                  .join(', ');
                context += `  ${i + 1}. ${r.name}: ${r.calculatedValue.toLocaleString('sv-SE', { maximumFractionDigits: 2 })} (${rawStr})\n`;
              });
              
              context += `\n📉 LÄGST BERÄKNAT VÄRDE (botten 10):\n`;
              results.slice(-10).reverse().forEach((r, i) => {
                const rank = results.length - 9 + i;
                context += `  ${rank}. ${r.name}: ${r.calculatedValue.toLocaleString('sv-SE', { maximumFractionDigits: 2 })}\n`;
              });
              
              const avg = results.reduce((sum, r) => sum + r.calculatedValue, 0) / results.length;
              context += `\n📊 SAMMANFATTNING:\n`;
              context += `  Kommuner med data: ${results.length}\n`;
              context += `  Högst: ${results[0].name} (${results[0].calculatedValue.toLocaleString('sv-SE', { maximumFractionDigits: 2 })})\n`;
              context += `  Lägst: ${results[results.length - 1].name} (${results[results.length - 1].calculatedValue.toLocaleString('sv-SE', { maximumFractionDigits: 2 })})\n`;
              context += `  Genomsnitt: ${avg.toLocaleString('sv-SE', { maximumFractionDigits: 2 })}\n`;
            } else {
              context += `\n⚠️ Kunde inte beräkna - saknar data för någon av KPI:erna.\n`;
            }
          }
          else if (isChangeQuery) {
            // JÄMFÖRELSE ÖVER TID: Hämta data för första och sista året, beräkna förändring
            await logToServer('INFO', 'RIKSDATA', `Jämförelse över tid: ${firstYear} → ${lastYear}`);
            
            const mainKpi = foundKpis[0];
            
            // Kolla om användaren frågar om ANTAL (absoluta tal) och vi har en andels-KPI
            const wantsAbsoluteNumbers = queryLower.includes('antal') || queryLower.includes('hur många');
            const isPercentageKpi = mainKpi.title.toLowerCase().includes('andel') || mainKpi.title.includes('%');
            const needsPopulationData = wantsAbsoluteNumbers && isPercentageKpi;
            
            // Hämta data för båda åren - andel
            const dataByMun: { [munId: string]: { 
              name: string; 
              percentFirst?: number; 
              percentLast?: number;
              popFirst?: number;
              popLast?: number;
            } } = {};
            
            // Hämta andelsdata
            for (const year of [firstYear, lastYear]) {
              const dataUrl = `/api/kolada?endpoint=data/kpi/${mainKpi.id}/year/${year}&per_page=500`;
              try {
                const dataResponse = await fetch(dataUrl);
                if (dataResponse.ok) {
                  const data = await dataResponse.json();
                  for (const item of data.values || []) {
                    const val = item.values?.find((v: { gender: string | null }) => v.gender === 'T' || v.gender === null);
                    if (val?.value !== null && val?.value !== undefined && munNameLookup[item.municipality]) {
                      if (!dataByMun[item.municipality]) {
                        dataByMun[item.municipality] = { name: munNameLookup[item.municipality] };
                      }
                      if (year === firstYear) {
                        dataByMun[item.municipality].percentFirst = val.value;
                      } else {
                        dataByMun[item.municipality].percentLast = val.value;
                      }
                    }
                  }
                }
              } catch (e) {
                await logToServer('ERROR', 'RIKSDATA', `Fel vid hämtning ${mainKpi.id} år ${year}`, { error: String(e) });
              }
            }
            
            // Om vi behöver befolkningsdata för att beräkna absoluta tal
            if (needsPopulationData) {
              await logToServer('INFO', 'RIKSDATA', 'Hämtar även befolkningsdata (N01951) för beräkning av absoluta tal');
              
              for (const year of [firstYear, lastYear]) {
                const dataUrl = `/api/kolada?endpoint=data/kpi/N01951/year/${year}&per_page=500`;
                try {
                  const dataResponse = await fetch(dataUrl);
                  if (dataResponse.ok) {
                    const data = await dataResponse.json();
                    for (const item of data.values || []) {
                      const val = item.values?.find((v: { gender: string | null }) => v.gender === 'T' || v.gender === null);
                      if (val?.value !== null && val?.value !== undefined && dataByMun[item.municipality]) {
                        if (year === firstYear) {
                          dataByMun[item.municipality].popFirst = val.value;
                        } else {
                          dataByMun[item.municipality].popLast = val.value;
                        }
                      }
                    }
                  }
                } catch (e) {
                  await logToServer('ERROR', 'RIKSDATA', `Fel vid hämtning N01951 år ${year}`, { error: String(e) });
                }
              }
            }
            
            // Beräkna förändring
            if (needsPopulationData) {
              // BERÄKNA ABSOLUTA TAL
              context += `\n\n=== FÖRÄNDRING I ANTAL ${firstYear} → ${lastYear} ===\n`;
              context += `\nBeräkning: (andel utrikes födda / 100) × folkmängd\n`;
              context += `KPIs: ${mainKpi.id} (andel) + N01951 (folkmängd)\n`;
              
              const absoluteChanges = Object.entries(dataByMun)
                .filter(([, d]) => d.percentFirst !== undefined && d.percentLast !== undefined && 
                                   d.popFirst !== undefined && d.popLast !== undefined)
                .map(([munId, d]) => {
                  const countFirst = Math.round((d.percentFirst! / 100) * d.popFirst!);
                  const countLast = Math.round((d.percentLast! / 100) * d.popLast!);
                  return {
                    munId,
                    name: d.name,
                    countFirst,
                    countLast,
                    change: countLast - countFirst,
                    percentFirst: d.percentFirst!,
                    percentLast: d.percentLast!,
                    popFirst: d.popFirst!,
                    popLast: d.popLast!
                  };
                })
                .sort((a, b) => b.change - a.change);
              
              await logToServer('INFO', 'RIKSDATA', `${absoluteChanges.length} kommuner med komplett data för beräkning`);
              
              if (absoluteChanges.length > 0) {
                context += `\n📈 STÖRST ÖKNING I ANTAL (${absoluteChanges.length} kommuner):\n`;
                absoluteChanges.slice(0, 20).forEach((c, i) => {
                  context += `  ${i + 1}. ${c.name}: ${c.countFirst.toLocaleString('sv-SE')} → ${c.countLast.toLocaleString('sv-SE')} (${c.change >= 0 ? '+' : ''}${c.change.toLocaleString('sv-SE')} personer)\n`;
                });
                
                context += `\n📉 STÖRST MINSKNING I ANTAL:\n`;
                absoluteChanges.slice(-10).reverse().forEach((c, i) => {
                  context += `  ${i + 1}. ${c.name}: ${c.countFirst.toLocaleString('sv-SE')} → ${c.countLast.toLocaleString('sv-SE')} (${c.change >= 0 ? '+' : ''}${c.change.toLocaleString('sv-SE')} personer)\n`;
                });
                
                const totalChange = absoluteChanges.reduce((sum, c) => sum + c.change, 0);
                context += `\n📊 SAMMANFATTNING:\n`;
                context += `  Total förändring i riket: ${totalChange >= 0 ? '+' : ''}${totalChange.toLocaleString('sv-SE')} personer\n`;
                context += `  Kommuner som ökade: ${absoluteChanges.filter(c => c.change > 0).length}\n`;
                context += `  Kommuner som minskade: ${absoluteChanges.filter(c => c.change < 0).length}\n`;
              }
            } else {
              // VISA ANDELSFÖRÄNDRING
              context += `\n\n=== FÖRÄNDRING I ANDEL ${firstYear} → ${lastYear} ===\n`;
              context += `\nKPI: ${mainKpi.id}: ${mainKpi.title}\n`;
              
              const changes = Object.entries(dataByMun)
                .filter(([, d]) => d.percentFirst !== undefined && d.percentLast !== undefined)
                .map(([munId, d]) => ({
                  munId,
                  name: d.name,
                  first: d.percentFirst!,
                  last: d.percentLast!,
                  change: d.percentLast! - d.percentFirst!
                }))
                .sort((a, b) => b.change - a.change);
              
              await logToServer('INFO', 'RIKSDATA', `${changes.length} kommuner med data för båda åren`);
              
              if (changes.length > 0) {
                context += `\n📈 STÖRST ÖKNING (${changes.length} kommuner med data):\n`;
                changes.slice(0, 15).forEach((c, i) => {
                  context += `  ${i + 1}. ${c.name}: ${c.first.toLocaleString('sv-SE', { maximumFractionDigits: 1 })}% → ${c.last.toLocaleString('sv-SE', { maximumFractionDigits: 1 })}% (${c.change >= 0 ? '+' : ''}${c.change.toLocaleString('sv-SE', { maximumFractionDigits: 1 })} procentenheter)\n`;
                });
                
                context += `\n📉 STÖRST MINSKNING:\n`;
                changes.slice(-10).reverse().forEach((c, i) => {
                  context += `  ${i + 1}. ${c.name}: ${c.first.toLocaleString('sv-SE', { maximumFractionDigits: 1 })}% → ${c.last.toLocaleString('sv-SE', { maximumFractionDigits: 1 })}% (${c.change >= 0 ? '+' : ''}${c.change.toLocaleString('sv-SE', { maximumFractionDigits: 1 })} procentenheter)\n`;
                });
                
                const avgChange = changes.reduce((sum, c) => sum + c.change, 0) / changes.length;
                context += `\n📊 SAMMANFATTNING:\n`;
                context += `  Genomsnittlig förändring: ${avgChange >= 0 ? '+' : ''}${avgChange.toLocaleString('sv-SE', { maximumFractionDigits: 2 })} procentenheter\n`;
                context += `  Antal kommuner som ökade: ${changes.filter(c => c.change > 0).length}\n`;
                context += `  Antal kommuner som minskade: ${changes.filter(c => c.change < 0).length}\n`;
              } else {
                context += `\n⚠️ Ingen data hittades för båda åren (${firstYear} och ${lastYear}).\n`;
              }
            }
          } else {
            // RANKING: Visa högst och lägst värden för senaste året
            const year = lastYear || yearsToFetch[0] || new Date().getFullYear() - 1;
            
            // Fokusera på den mest relevanta KPI:n för tydligare svar
            const mainKpi = foundKpis[0];
            context += `\n\n=== RANKING ${year} ===\n`;
            context += `\nKPI: ${mainKpi.id}: ${mainKpi.title}\n`;
            
            const dataUrl = `/api/kolada?endpoint=data/kpi/${mainKpi.id}/year/${year}&per_page=500`;
            try {
              const dataResponse = await fetch(dataUrl);
              if (dataResponse.ok) {
                const data = await dataResponse.json();
                if (data.values?.length > 0) {
                  const validValues = data.values
                    .filter((item: { municipality: string; values: Array<{ value: number | null; gender: string | null }> }) => {
                      const val = item.values?.find((v: { gender: string | null }) => v.gender === 'T' || v.gender === null);
                      return val?.value !== null && val?.value !== undefined && munNameLookup[item.municipality];
                    })
                    .map((item: { municipality: string; values: Array<{ value: number | null; gender: string | null }> }) => {
                      const val = item.values?.find((v: { gender: string | null }) => v.gender === 'T' || v.gender === null);
                      return {
                        name: munNameLookup[item.municipality] || item.municipality,
                        value: val?.value || 0
                      };
                    })
                    .sort((a: { value: number }, b: { value: number }) => b.value - a.value);
                  
                  if (validValues.length === 0) {
                    context += `\n⚠️ Ingen data hittades för ${mainKpi.id} år ${year}.\n`;
                  } else {
                    // VIKTIG INFORMATION FÖR AI:n - alla kommuner rankade
                    await logToServer('INFO', 'RIKSDATA', `${validValues.length} kommuner sorterade för ${mainKpi.id}`);
                    
                    context += `\n📈 HÖGST VÄRDE (topp 15 av ${validValues.length} kommuner):\n`;
                    validValues.slice(0, 15).forEach((item: { name: string; value: number }, i: number) => {
                      context += `  ${i + 1}. ${item.name}: ${item.value.toLocaleString('sv-SE', { maximumFractionDigits: 1 })}\n`;
                    });
                    
                    context += `\n📉 LÄGST VÄRDE (botten 15):\n`;
                    const bottomValues = validValues.slice(-15).reverse();
                    bottomValues.forEach((item: { name: string; value: number }, i: number) => {
                      const rank = validValues.length - 14 + i;
                      context += `  ${rank}. ${item.name}: ${item.value.toLocaleString('sv-SE', { maximumFractionDigits: 1 })}\n`;
                    });
                    
                    // Sammanfattning
                    const avg = validValues.reduce((sum: number, v: { value: number }) => sum + v.value, 0) / validValues.length;
                    const highest = validValues[0];
                    const lowest = validValues[validValues.length - 1];
                    
                    context += `\n📊 SAMMANFATTNING (${validValues.length} kommuner):\n`;
                    context += `  HÖGST: ${highest.name} (${highest.value.toLocaleString('sv-SE', { maximumFractionDigits: 1 })})\n`;
                    context += `  LÄGST: ${lowest.name} (${lowest.value.toLocaleString('sv-SE', { maximumFractionDigits: 1 })})\n`;
                    context += `  Genomsnitt: ${avg.toLocaleString('sv-SE', { maximumFractionDigits: 1 })}\n`;
                  }
                }
              }
            } catch (e) {
              console.error('Data fetch error:', e);
              context += `\n⚠️ Fel vid hämtning av data.\n`;
            }
          }
        }
        
        // FALLBACK: If we have search terms but no KPIs were mapped, search dynamically
        if (foundKpis.length === 0 && analysis.kpiSearchTerms?.length > 0 && !isUnitQuery) {
          context += `\n\n=== DYNAMISK KPI-SÖKNING ===\n`;
          const year = yearsToFetch[0] || new Date().getFullYear() - 1;
          
          for (const term of analysis.kpiSearchTerms.slice(0, 2)) {
            const kpiSearchResponse = await fetch(`/api/kolada?endpoint=kpi&title=${encodeURIComponent(term)}&per_page=5`);
            if (kpiSearchResponse.ok) {
              const kpiData = await kpiSearchResponse.json();
              if (kpiData.values?.length > 0) {
                context += `\nHittade KPIs för "${term}":\n`;
                for (const kpi of kpiData.values.slice(0, 3)) {
                  context += `\n${kpi.id}: ${kpi.title}\n`;
                  context += `  Beskrivning: ${(kpi.description || '').substring(0, 150)}...\n`;
                  
                  // Fetch sample data for this KPI
                  if (foundMunicipalities.length > 0) {
                    for (const mun of foundMunicipalities.slice(0, 2)) {
                      const dataUrl = `/api/kolada?endpoint=data/kpi/${kpi.id}/municipality/${mun.id}/year/${year}`;
                      try {
                        const dataResponse = await fetch(dataUrl);
                        if (dataResponse.ok) {
                          const data = await dataResponse.json();
                          if (data.values?.[0]) {
                            const val = data.values[0].values?.find((v: { gender: string | null }) => v.gender === 'T' || v.gender === null);
                            if (val?.value !== null) {
                              context += `  ${mun.title} (${year}): ${val.value.toLocaleString('sv-SE')}\n`;
                            }
                          }
                        }
                      } catch (e) {
                        // Skip
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Prepare conversation history for the AI
      updateProgress("🤖 Genererar svar...");
      await logToServer('INFO', 'CHAT', 'Förbereder chat-anrop');
      
      const conversationHistory = updatedMessages
        .filter(m => !m.isLoading)
        .slice(-10) // Last 10 messages for context
        .map(m => ({ role: m.role, content: m.content }));

      // Get AI response with conversation history - med timeout för mobiler
      const chatController = new AbortController();
      const chatTimeoutId = setTimeout(() => {
        chatController.abort();
        logToServer('ERROR', 'CHAT', 'Chat-anrop timeout efter 90s');
      }, 90000); // 90 sekunder timeout
      
      await logToServer('INFO', 'CHAT', 'Skickar chat-anrop...', { contextLength: context.length });
      
      let chatResponse: Response;
      try {
        chatResponse = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: userMessage.content,
            apiKey,
            model,
            context,
            conversationHistory,
          }),
          signal: chatController.signal,
        });
      } catch (fetchError) {
        clearTimeout(chatTimeoutId);
        if (fetchError instanceof Error && fetchError.name === 'AbortError') {
          await logToServer('ERROR', 'CHAT', 'Chat-anrop avbrutet (timeout)');
          throw new Error('Svarstiden gick ut. Försök igen med en kortare fråga.');
        }
        await logToServer('ERROR', 'CHAT', 'Nätverksfel vid chat-anrop', { error: String(fetchError) });
        throw fetchError;
      }
      
      clearTimeout(chatTimeoutId);
      await logToServer('INFO', 'CHAT', `Chat-svar mottaget: ${chatResponse.status}`);

      const chatData = await chatResponse.json();

      if (!chatResponse.ok) {
        await logToServer('ERROR', 'CHAT', 'Chat-fel', { error: chatData.error });
        throw new Error(chatData.error || "Ett fel uppstod");
      }
      
      await logToServer('INFO', 'CHAT', 'Chat-svar OK', { responseLength: chatData.response?.length || 0 });

      // Update loading message with response
      setMessages((prev) =>
        prev.map((m) =>
          m.id === loadingId
            ? { ...m, content: chatData.response, isLoading: false }
            : m
        )
      );
    } catch (error) {
      console.error("Chat error:", error);
      setMessages((prev) =>
        prev.map((m) =>
          m.id === loadingId
            ? {
                ...m,
                content:
                  error instanceof Error
                    ? error.message
                    : "Ett fel uppstod. Försök igen.",
                isLoading: false,
              }
            : m
        )
      );
    } finally {
      setIsLoading(false);
      setProgress("");
      abortControllerRef.current = null;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleExampleClick = (question: string) => {
    setInput(question);
    inputRef.current?.focus();
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header with clear button */}
      {messages.length > 0 && (
        <div className="flex justify-end p-2 border-b border-slate-800">
          <button
            onClick={clearChat}
            className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            Rensa chatt
          </button>
        </div>
      )}

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mb-8"
            >
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 flex items-center justify-center mb-4 mx-auto glow">
                <Sparkles className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white mb-2">
                Välkommen till Kolada AI
              </h2>
              <p className="text-slate-400 max-w-md text-sm sm:text-base">
                Ställ frågor om svensk kommunal statistik på naturligt språk.
                Jag hjälper dig hitta och analysera data från Kolada.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 w-full max-w-2xl px-2 sm:px-0">
              {EXAMPLE_QUESTIONS.map((example, index) => (
                <motion.button
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={() => handleExampleClick(example.text)}
                  className="flex items-center gap-2 sm:gap-3 p-3 sm:p-4 rounded-xl bg-slate-800/50 hover:bg-slate-700/50 border border-slate-700/50 hover:border-blue-500/50 transition-all text-left group"
                >
                  <div className="p-1.5 sm:p-2 rounded-lg bg-blue-500/10 text-blue-400 group-hover:bg-blue-500/20 transition-colors flex-shrink-0">
                    <example.icon className="w-4 h-4 sm:w-5 sm:h-5" />
                  </div>
                  <span className="text-slate-300 text-xs sm:text-sm">{example.text}</span>
                </motion.button>
              ))}
            </div>
          </div>
        ) : (
          <AnimatePresence>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-3 ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                {message.role === "assistant" && (
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center flex-shrink-0 hidden sm:flex">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                )}
                <div
                  className={`max-w-[95%] sm:max-w-[80%] rounded-2xl px-3 py-2 sm:px-4 sm:py-3 ${
                    message.role === "user"
                      ? "bg-blue-600 text-white"
                      : "bg-slate-800 text-slate-100"
                  }`}
                >
                  {message.isLoading ? (
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
                        <span className="text-slate-300">{progress || "Startar..."}</span>
                      </div>
                      <div className="text-xs text-slate-500">
                        Byt inte vy under pågående analys
                      </div>
                    </div>
                  ) : (
                    <MessageContent content={message.content} />
                  )}
                </div>
                {message.role === "user" && (
                  <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0 hidden sm:flex">
                    <User className="w-4 h-4 text-slate-300" />
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="border-t border-slate-800 p-2 sm:p-4 bg-slate-900/50 backdrop-blur-sm">
        <div className="flex gap-2 sm:gap-3 max-w-4xl mx-auto">
          <div className="flex-1 relative">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ställ en fråga..."
              rows={1}
              className="w-full px-3 py-2 sm:px-4 sm:py-3 rounded-xl bg-slate-800 border border-slate-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-white placeholder-slate-500 resize-none text-base"
              style={{ minHeight: "44px", maxHeight: "120px" }}
            />
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="px-3 py-2 sm:px-4 sm:py-3 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium flex items-center gap-2 transition-all"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </motion.button>
        </div>
      </div>
    </div>
  );
}
