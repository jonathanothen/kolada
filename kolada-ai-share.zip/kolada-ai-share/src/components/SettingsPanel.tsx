"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Settings,
  Key,
  Eye,
  EyeOff,
  Check,
  ExternalLink,
  Cpu,
  X,
} from "lucide-react";

interface SettingsPanelProps {
  apiKey: string;
  setApiKey: (key: string) => void;
  model: string;
  setModel: (model: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const MODELS = [
  {
    id: "gemini-2.5-flash",
    name: "Gemini 2.5 Flash",
    description: "Snabb och kraftfull - bästa valet för de flesta",
    badge: "REKOMMENDERAD",
  },
  {
    id: "gemini-2.5-pro",
    name: "Gemini 2.5 Pro",
    description: "Mest kraftfull för komplex analys",
    badge: "KRAFTFULL",
  },
  {
    id: "gemini-2.5-flash-lite",
    name: "Gemini 2.5 Flash Lite",
    description: "Snabbast och billigast",
    badge: null,
  },
  {
    id: "gemini-2.0-flash",
    name: "Gemini 2.0 Flash",
    description: "Äldre version, fortfarande stabil",
    badge: null,
  },
];

export default function SettingsPanel({
  apiKey,
  setApiKey,
  model,
  setModel,
  isOpen,
  onClose,
}: SettingsPanelProps) {
  const [showApiKey, setShowApiKey] = useState(false);
  const [tempApiKey, setTempApiKey] = useState(apiKey);

  const handleSave = () => {
    setApiKey(tempApiKey);
    // Save to localStorage
    if (typeof window !== "undefined") {
      localStorage.setItem("kolada-ai-api-key", tempApiKey);
      localStorage.setItem("kolada-ai-model", model);
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
      />

      {/* Panel */}
      <motion.div
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 200 }}
        className="fixed right-0 top-0 h-full w-full max-w-md bg-slate-900 border-l border-slate-800 z-50 overflow-y-auto"
      >
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Settings className="w-5 h-5 text-blue-400" />
              </div>
              <h2 className="text-xl font-bold text-white">Inställningar</h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5 text-slate-400" />
            </button>
          </div>

          {/* API Key Section */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <Key className="w-4 h-4 text-blue-400" />
              <label className="text-sm font-medium text-slate-300">
                Egen API-nyckel (valfritt)
              </label>
            </div>
            <p className="text-xs text-slate-500 mb-3">
              Appen fungerar utan egen nyckel. Ange din egen för högre gränser.
            </p>
            <div className="relative">
              <input
                type={showApiKey ? "text" : "password"}
                value={tempApiKey}
                onChange={(e) => setTempApiKey(e.target.value)}
                placeholder="AIza..."
                className="w-full px-4 py-3 pr-12 rounded-xl bg-slate-800 border border-slate-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-white placeholder-slate-500"
              />
              <button
                onClick={() => setShowApiKey(!showApiKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-lg hover:bg-slate-700 transition-colors"
              >
                {showApiKey ? (
                  <EyeOff className="w-4 h-4 text-slate-400" />
                ) : (
                  <Eye className="w-4 h-4 text-slate-400" />
                )}
              </button>
            </div>
            <a
              href="https://aistudio.google.com/apikey"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-400 mt-2 transition-colors"
            >
              Skaffa en egen API-nyckel (valfritt)
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          {/* Model Selection */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <Cpu className="w-4 h-4 text-purple-400" />
              <label className="text-sm font-medium text-slate-300">
                AI-modell
              </label>
            </div>
            <div className="space-y-2">
              {MODELS.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setModel(m.id)}
                  className={`w-full p-4 rounded-xl border transition-all text-left ${
                    model === m.id
                      ? "bg-blue-500/10 border-blue-500/50"
                      : "bg-slate-800/50 border-slate-700/50 hover:border-slate-600"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-white">{m.name}</span>
                      {m.badge && (
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                            m.badge === "NYASTE"
                              ? "bg-purple-500/20 text-purple-300"
                              : "bg-green-500/20 text-green-300"
                          }`}
                        >
                          {m.badge}
                        </span>
                      )}
                    </div>
                    {model === m.id && (
                      <Check className="w-4 h-4 text-blue-400" />
                    )}
                  </div>
                  <p className="text-sm text-slate-400 mt-1">{m.description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Info Section */}
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50 mb-8">
            <h3 className="text-sm font-medium text-white mb-2">
              Om Kolada AI
            </h3>
            <p className="text-sm text-slate-400 mb-3">
              Denna app använder Google Gemini AI för att hjälpa dig utforska
              svensk kommunal statistik från{" "}
              <a
                href="https://kolada.se"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-400 hover:underline"
              >
                Kolada
              </a>
              . All data kommer från RKA:s öppna API.
            </p>
            <p className="text-xs text-slate-500">
              Utvecklad av Jonas Millard
            </p>
          </div>

          {/* Save Button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleSave}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-medium transition-all"
          >
            Spara inställningar
          </motion.button>
        </div>
      </motion.div>
    </>
  );
}
