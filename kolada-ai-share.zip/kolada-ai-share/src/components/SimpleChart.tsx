"use client";

import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// Registrera Chart.js-komponenter
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface ChartData {
  labels: string[];
  values: number[];
  label?: string;
}

interface SimpleChartProps {
  data: ChartData;
  title?: string;
  showChange?: boolean; // Visa positiva/negativa färger
}

export default function SimpleChart({ data, title, showChange = false }: SimpleChartProps) {
  const colors = showChange 
    ? data.values.map(v => v >= 0 ? 'rgba(34, 197, 94, 0.7)' : 'rgba(239, 68, 68, 0.7)')
    : 'rgba(59, 130, 246, 0.7)';
  
  const borderColors = showChange
    ? data.values.map(v => v >= 0 ? 'rgb(34, 197, 94)' : 'rgb(239, 68, 68)')
    : 'rgb(59, 130, 246)';

  const chartData = {
    labels: data.labels,
    datasets: [
      {
        label: data.label || 'Värde',
        data: data.values,
        backgroundColor: colors,
        borderColor: borderColors,
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: !!title,
        text: title,
        color: '#e2e8f0',
      },
    },
    scales: {
      x: {
        ticks: { color: '#94a3b8' },
        grid: { color: 'rgba(148, 163, 184, 0.1)' },
      },
      y: {
        ticks: { color: '#94a3b8' },
        grid: { color: 'rgba(148, 163, 184, 0.1)' },
      },
    },
  };

  return (
    <div className="w-full h-64 bg-slate-800/50 rounded-lg p-4">
      <Bar data={chartData} options={options} />
    </div>
  );
}

/**
 * Extrahera diagramdata från AI-svar
 * Letar efter tabeller med siffror och konverterar till ChartData
 */
export function extractChartData(text: string): ChartData | null {
  // Försök hitta en tabell med | separatorer
  const tableMatch = text.match(/\|[^|]+\|[^|]+\|[^|]+\|/g);
  if (!tableMatch || tableMatch.length < 3) return null;
  
  // Hoppa över header och separator
  const dataRows = tableMatch.slice(2);
  
  const labels: string[] = [];
  const values: number[] = [];
  
  for (const row of dataRows) {
    const cells = row.split('|').filter(c => c.trim());
    if (cells.length >= 2) {
      const label = cells[0].trim();
      // Hitta den sista numeriska cellen (ofta förändring)
      for (let i = cells.length - 1; i >= 1; i--) {
        const numMatch = cells[i].match(/-?[\d,]+\.?\d*/);
        if (numMatch) {
          const value = parseFloat(numMatch[0].replace(',', '.'));
          if (!isNaN(value)) {
            labels.push(label);
            values.push(value);
            break;
          }
        }
      }
    }
  }
  
  if (labels.length === 0) return null;
  
  return { labels, values };
}
