"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  MessageSquare,
  Search,
  BarChart3,
  MapPin,
  BookOpen,
  ChevronRight,
  Plus,
  ScrollText,
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onNewChat?: () => void;
}

const MENU_ITEMS = [
  { id: "chat", icon: MessageSquare, label: "AI Chatt", badge: null },
  { id: "search", icon: Search, label: "Sök KPIs", badge: null },
  { id: "municipalities", icon: MapPin, label: "Kommuner", badge: "290" },
  { id: "data", icon: BarChart3, label: "Utforska Data", badge: null },
  { id: "logs", icon: ScrollText, label: "Loggar", badge: null },
  { id: "docs", icon: BookOpen, label: "Dokumentation", badge: null },
];

export default function Sidebar({ activeTab, setActiveTab, onNewChat }: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const handleNewChat = () => {
    if (onNewChat) {
      onNewChat();
    }
    setActiveTab("chat");
  };

  return (
    <aside
      className={`${
        isCollapsed ? "w-16" : "w-64"
      } border-r border-slate-800 bg-slate-900/50 flex flex-col transition-all duration-300 hidden lg:flex`}
    >
      {/* New Chat Button */}
      <div className="p-3">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleNewChat}
          className={`w-full flex items-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-medium transition-all ${
            isCollapsed ? "justify-center" : ""
          }`}
        >
          <Plus className="w-5 h-5" />
          {!isCollapsed && <span>Ny konversation</span>}
        </motion.button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-2">
        <div className="space-y-1">
          {MENU_ITEMS.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${
                activeTab === item.id
                  ? "bg-blue-500/10 text-blue-400"
                  : "text-slate-400 hover:text-white hover:bg-slate-800/50"
              } ${isCollapsed ? "justify-center" : ""}`}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {!isCollapsed && (
                <>
                  <span className="flex-1 text-left">{item.label}</span>
                  {item.badge && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-700 text-slate-300">
                      {item.badge}
                    </span>
                  )}
                </>
              )}
            </button>
          ))}
        </div>
      </nav>

      {/* Collapse Toggle */}
      <div className="p-3 border-t border-slate-800">
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/50 transition-all"
        >
          <ChevronRight
            className={`w-4 h-4 transition-transform ${
              isCollapsed ? "" : "rotate-180"
            }`}
          />
          {!isCollapsed && <span className="text-sm">Minimera</span>}
        </button>
      </div>
    </aside>
  );
}
