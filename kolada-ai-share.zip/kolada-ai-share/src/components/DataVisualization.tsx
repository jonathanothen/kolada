"use client";

import { useMemo, useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  TooltipItem,
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';
import { TrendingUp, TrendingDown, BarChart3, PieChart, Maximize2, Minimize2 } from 'lucide-react';

// Registrera Chart.js-komponenter
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export interface DataPoint {
  label: string;
  value: number;
  category?: 'top' | 'bottom' | 'middle' | 'highlight';
  rank?: number;
}

export interface VisualizationData {
  points: DataPoint[];
  title?: string;
  unit?: string;
  kpiId?: string;
  year?: number;
  showType?: 'ranking' | 'comparison' | 'change' | 'distribution';
  highlightTop?: number;
  highlightBottom?: number;
}

type ChartType = 'bar' | 'horizontalBar' | 'doughnut' | 'line';

// Moderna färgpaletter
const COLORS = {
  top: {
    gradient: ['rgba(34, 197, 94, 0.9)', 'rgba(22, 163, 74, 0.7)'],
    border: 'rgb(34, 197, 94)',
    glow: 'rgba(34, 197, 94, 0.3)',
  },
  bottom: {
    gradient: ['rgba(239, 68, 68, 0.9)', 'rgba(185, 28, 28, 0.7)'],
    border: 'rgb(239, 68, 68)',
    glow: 'rgba(239, 68, 68, 0.3)',
  },
  highlight: {
    gradient: ['rgba(251, 191, 36, 0.9)', 'rgba(245, 158, 11, 0.7)'],
    border: 'rgb(251, 191, 36)',
    glow: 'rgba(251, 191, 36, 0.3)',
  },
  default: {
    gradient: ['rgba(59, 130, 246, 0.8)', 'rgba(37, 99, 235, 0.6)'],
    border: 'rgb(59, 130, 246)',
    glow: 'rgba(59, 130, 246, 0.2)',
  },
  palette: [
    'rgba(59, 130, 246, 0.8)',   // Blue
    'rgba(34, 197, 94, 0.8)',    // Green
    'rgba(251, 191, 36, 0.8)',   // Yellow
    'rgba(239, 68, 68, 0.8)',    // Red
    'rgba(168, 85, 247, 0.8)',   // Purple
    'rgba(236, 72, 153, 0.8)',   // Pink
    'rgba(20, 184, 166, 0.8)',   // Teal
    'rgba(249, 115, 22, 0.8)',   // Orange
  ],
};

function getColorForPoint(point: DataPoint, index: number): { bg: string; border: string } {
  if (point.category === 'top') {
    return { bg: COLORS.top.gradient[0], border: COLORS.top.border };
  }
  if (point.category === 'bottom') {
    return { bg: COLORS.bottom.gradient[0], border: COLORS.bottom.border };
  }
  if (point.category === 'highlight') {
    return { bg: COLORS.highlight.gradient[0], border: COLORS.highlight.border };
  }
  return { bg: COLORS.default.gradient[0], border: COLORS.default.border };
}

interface Props {
  data: VisualizationData;
  className?: string;
}

export default function DataVisualization({ data, className = '' }: Props) {
  const [chartType, setChartType] = useState<ChartType>('horizontalBar');
  const [isExpanded, setIsExpanded] = useState(false);

  // Bearbeta data - behåll AI:ns kategorier om de finns, annars sortera
  const processedData = useMemo(() => {
    const points = [...data.points];
    const n = points.length;
    
    // Om AI:n redan har satt kategorier (från chart-block), använd data som den är
    const hasAICategories = points.some(p => p.category === 'top' || p.category === 'bottom');
    
    if (hasAICategories) {
      // AI har redan bestämt ordning och färger - returnera direkt
      return points.map((p, idx) => ({ ...p, rank: idx + 1 }));
    }
    
    // Fallback: Auto-kategorisera om AI inte gjorde det
    const topCount = data.highlightTop || Math.min(3, Math.ceil(n * 0.15));
    const bottomCount = data.highlightBottom || Math.min(3, Math.ceil(n * 0.15));
    
    // Sortera för ranking
    const sorted = [...points].sort((a, b) => b.value - a.value);
    
    sorted.forEach((point, idx) => {
      point.rank = idx + 1;
      if (idx < topCount) {
        point.category = 'top';
      } else if (idx >= n - bottomCount) {
        point.category = 'bottom';
      } else {
        point.category = 'middle';
      }
    });
    
    return sorted;
  }, [data.points, data.highlightTop, data.highlightBottom]);

  // Välj vilka punkter som ska visas i diagrammet
  const displayPoints = useMemo(() => {
    if (processedData.length <= 15) {
      return processedData;
    }
    
    // Visa topp 5 + botten 5 + några i mitten
    const top = processedData.slice(0, 5);
    const bottom = processedData.slice(-5);
    
    // Lägg till några från mitten om vi har många datapunkter
    const middleCount = Math.min(5, processedData.length - 10);
    const middleStart = Math.floor((processedData.length - middleCount) / 2);
    const middle = processedData.slice(middleStart, middleStart + middleCount);
    
    // Kombinera och markera vilka som är "mellanliggande"
    const display = [
      ...top,
      { label: '...', value: 0, category: 'middle' as const, rank: undefined },
      ...bottom,
    ];
    
    return display.filter(p => p.label !== '...' || display.length > 12);
  }, [processedData]);

  // Beräkna statistik
  const stats = useMemo(() => {
    const values = processedData.map(p => p.value);
    const sum = values.reduce((a, b) => a + b, 0);
    const avg = sum / values.length;
    const max = Math.max(...values);
    const min = Math.min(...values);
    const range = max - min;
    
    return { sum, avg, max, min, range, count: values.length };
  }, [processedData]);

  // Skapa Chart.js data
  const chartData = useMemo(() => {
    const pointsToShow = displayPoints.filter(p => p.label !== '...');
    
    return {
      labels: pointsToShow.map(p => p.label),
      datasets: [{
        label: data.unit || 'Värde',
        data: pointsToShow.map(p => p.value),
        backgroundColor: pointsToShow.map((p, i) => getColorForPoint(p, i).bg),
        borderColor: pointsToShow.map((p, i) => getColorForPoint(p, i).border),
        borderWidth: 2,
        borderRadius: 6,
        borderSkipped: false,
      }],
    };
  }, [displayPoints, data.unit]);

  // Doughnut data för distribution
  const doughnutData = useMemo(() => {
    const topPoints = processedData.slice(0, 5);
    const othersSum = processedData.slice(5).reduce((sum, p) => sum + p.value, 0);
    
    return {
      labels: [...topPoints.map(p => p.label), 'Övriga'],
      datasets: [{
        data: [...topPoints.map(p => p.value), othersSum],
        backgroundColor: [...COLORS.palette.slice(0, 5), 'rgba(148, 163, 184, 0.5)'],
        borderColor: 'rgba(30, 41, 59, 1)',
        borderWidth: 2,
        hoverOffset: 8,
      }],
    };
  }, [processedData]);

  // Chart.js options
  const barOptions = useMemo(() => ({
    indexAxis: chartType === 'horizontalBar' ? 'y' as const : 'x' as const,
    responsive: true,
    maintainAspectRatio: false,
    animation: {
      duration: 800,
      easing: 'easeOutQuart' as const,
    },
    plugins: {
      legend: { display: false },
      title: {
        display: !!data.title,
        text: data.title,
        color: '#f1f5f9',
        font: { size: 14, weight: 'bold' as const },
        padding: { bottom: 16 },
      },
      tooltip: {
        backgroundColor: 'rgba(15, 23, 42, 0.95)',
        titleColor: '#f1f5f9',
        bodyColor: '#cbd5e1',
        borderColor: 'rgba(59, 130, 246, 0.5)',
        borderWidth: 1,
        cornerRadius: 8,
        padding: 12,
        displayColors: true,
        callbacks: {
          label: (ctx: TooltipItem<'bar'>) => {
            const value = chartType === 'horizontalBar' ? ctx.parsed.x : ctx.parsed.y;
            const formatted = (value ?? 0).toLocaleString('sv-SE', { maximumFractionDigits: 1 });
            return `${ctx.dataset.label || 'Värde'}: ${formatted}${data.unit ? ` ${data.unit}` : ''}`;
          },
          afterLabel: (ctx: TooltipItem<'bar'>) => {
            const point = displayPoints.filter(p => p.label !== '...')[ctx.dataIndex];
            if (point?.rank) {
              return `Ranking: #${point.rank} av ${stats.count}`;
            }
            return '';
          },
        },
      },
    },
    scales: {
      x: {
        ticks: { 
          color: '#94a3b8',
          font: { size: chartType === 'horizontalBar' ? 11 : 10 },
          maxRotation: chartType === 'horizontalBar' ? 0 : 45,
        },
        grid: { 
          color: 'rgba(148, 163, 184, 0.08)',
          drawTicks: false,
        },
        border: { display: false },
        // Smart min för horisontella staplar - visa inte från 0 om det döljer skillnader
        ...(chartType === 'horizontalBar' && stats.range > 0 && stats.min > stats.range * 0.3 ? {
          min: Math.floor(stats.min * 0.9),
        } : {}),
      },
      y: {
        ticks: { 
          color: '#94a3b8',
          font: { size: 11 },
          padding: 8,
        },
        grid: { 
          color: 'rgba(148, 163, 184, 0.08)',
          drawTicks: false,
        },
        border: { display: false },
        // Smart min för vertikala staplar
        ...(chartType === 'bar' && stats.range > 0 && stats.min > stats.range * 0.3 ? {
          min: Math.floor(stats.min * 0.9),
        } : {}),
      },
    },
  }), [chartType, data.title, data.unit, stats, displayPoints]);

  const doughnutOptions = useMemo(() => ({
    responsive: true,
    maintainAspectRatio: false,
    cutout: '60%',
    animation: {
      animateRotate: true,
      animateScale: true,
    },
    plugins: {
      legend: {
        position: 'right' as const,
        labels: {
          color: '#94a3b8',
          padding: 12,
          usePointStyle: true,
          font: { size: 11 },
        },
      },
      tooltip: {
        backgroundColor: 'rgba(15, 23, 42, 0.95)',
        titleColor: '#f1f5f9',
        bodyColor: '#cbd5e1',
        borderColor: 'rgba(59, 130, 246, 0.5)',
        borderWidth: 1,
        cornerRadius: 8,
        padding: 12,
      },
    },
  }), []);

  const containerHeight = isExpanded ? 'h-[500px]' : 'h-80';

  return (
    <div className={`rounded-xl bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur-sm border border-slate-700/50 overflow-hidden ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700/50 bg-slate-800/50">
        <div className="flex items-center gap-3">
          {data.title && (
            <h3 className="text-sm font-semibold text-slate-200">
              {data.title}
            </h3>
          )}
          {data.year && (
            <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
              {data.year}
            </span>
          )}
          {data.kpiId && (
            <span className="px-2 py-0.5 text-xs font-mono rounded bg-slate-700/50 text-slate-400">
              {data.kpiId}
            </span>
          )}
        </div>
        
        {/* Diagram-typ väljare */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setChartType('horizontalBar')}
            className={`p-1.5 rounded-md transition-all ${chartType === 'horizontalBar' ? 'bg-blue-500/30 text-blue-300' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-700/50'}`}
            title="Horisontella staplar"
          >
            <BarChart3 className="w-4 h-4 rotate-90" />
          </button>
          <button
            onClick={() => setChartType('bar')}
            className={`p-1.5 rounded-md transition-all ${chartType === 'bar' ? 'bg-blue-500/30 text-blue-300' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-700/50'}`}
            title="Vertikala staplar"
          >
            <BarChart3 className="w-4 h-4" />
          </button>
          <button
            onClick={() => setChartType('doughnut')}
            className={`p-1.5 rounded-md transition-all ${chartType === 'doughnut' ? 'bg-blue-500/30 text-blue-300' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-700/50'}`}
            title="Cirkeldiagram"
          >
            <PieChart className="w-4 h-4" />
          </button>
          <div className="w-px h-4 bg-slate-700 mx-1" />
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-md text-slate-500 hover:text-slate-300 hover:bg-slate-700/50 transition-all"
            title={isExpanded ? 'Förminska' : 'Förstora'}
          >
            {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-slate-700/30">
        <div className="bg-slate-800/50 px-3 py-2 text-center">
          <div className="flex items-center justify-center gap-1 text-green-400">
            <TrendingUp className="w-3 h-3" />
            <span className="text-xs font-medium">Högst</span>
          </div>
          <div className="text-sm font-bold text-slate-200 mt-0.5">
            {stats.max.toLocaleString('sv-SE', { maximumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-slate-500 truncate">
            {processedData[0]?.label}
          </div>
        </div>
        <div className="bg-slate-800/50 px-3 py-2 text-center">
          <div className="flex items-center justify-center gap-1 text-red-400">
            <TrendingDown className="w-3 h-3" />
            <span className="text-xs font-medium">Lägst</span>
          </div>
          <div className="text-sm font-bold text-slate-200 mt-0.5">
            {stats.min.toLocaleString('sv-SE', { maximumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-slate-500 truncate">
            {processedData[processedData.length - 1]?.label}
          </div>
        </div>
        <div className="bg-slate-800/50 px-3 py-2 text-center">
          <div className="text-xs font-medium text-blue-400">Genomsnitt</div>
          <div className="text-sm font-bold text-slate-200 mt-0.5">
            {stats.avg.toLocaleString('sv-SE', { maximumFractionDigits: 0 })}
          </div>
        </div>
        <div className="bg-slate-800/50 px-3 py-2 text-center">
          <div className="text-xs font-medium text-slate-400">Antal</div>
          <div className="text-sm font-bold text-slate-200 mt-0.5">
            {stats.count}
          </div>
          <div className="text-xs text-slate-500">kommuner</div>
        </div>
      </div>

      {/* Chart */}
      <div className={`p-4 ${containerHeight} transition-all duration-300`}>
        {chartType === 'doughnut' ? (
          <Doughnut data={doughnutData} options={doughnutOptions} />
        ) : (
          <Bar data={chartData} options={barOptions} />
        )}
      </div>

      {/* Legend för kategorier */}
      <div className="flex items-center justify-center gap-3 sm:gap-6 px-4 py-2 border-t border-slate-700/30 bg-slate-800/30 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-green-500" />
          <span className="text-xs text-slate-400">Topp {Math.min(5, Math.ceil(stats.count * 0.15))}</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-blue-500" />
          <span className="text-xs text-slate-400">Övriga</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500" />
          <span className="text-xs text-slate-400">Botten {Math.min(5, Math.ceil(stats.count * 0.15))}</span>
        </div>
      </div>
    </div>
  );
}

/**
 * AI-genererat diagramformat
 */
export interface AIChartData {
  title: string;
  unit?: string;
  data: Array<{
    label: string;
    value: number;
    color?: 'green' | 'red' | 'blue' | 'yellow' | 'purple';
  }>;
}

/**
 * Extrahera AI-genererad diagramdata från ```chart JSON-block
 * Detta är den primära metoden - AI:n bestämmer 100% vad som visas
 */
export function extractAIChartData(text: string): AIChartData | null {
  // Leta efter ```chart JSON-block
  const chartMatch = text.match(/```chart\s*\n?([\s\S]*?)\n?```/);
  if (!chartMatch) return null;
  
  try {
    const jsonStr = chartMatch[1].trim();
    const parsed = JSON.parse(jsonStr);
    
    // Validera strukturen
    if (!parsed.data || !Array.isArray(parsed.data) || parsed.data.length === 0) {
      return null;
    }
    
    // Validera varje datapunkt
    const validData = parsed.data.filter((d: { label?: string; value?: number }) => 
      d.label && typeof d.value === 'number' && !isNaN(d.value)
    );
    
    if (validData.length === 0) return null;
    
    return {
      title: parsed.title || 'Data',
      unit: parsed.unit,
      data: validData,
    };
  } catch (e) {
    console.error('Failed to parse chart JSON:', e);
    return null;
  }
}

/**
 * Fallback: Extrahera visualiseringsdata från AI-svar om inget chart-block finns
 */
export function extractVisualizationData(text: string): VisualizationData | null {
  // Försök först med AI-genererat chart-block
  const aiChart = extractAIChartData(text);
  if (aiChart) {
    // Konvertera AIChartData till VisualizationData
    const colorToCategory = (color?: string): 'top' | 'bottom' | 'middle' => {
      if (color === 'green') return 'top';
      if (color === 'red') return 'bottom';
      return 'middle';
    };
    
    return {
      points: aiChart.data.map((d, i) => ({
        label: d.label,
        value: d.value,
        category: colorToCategory(d.color),
        rank: i + 1,
      })),
      title: aiChart.title,
      unit: aiChart.unit,
      showType: 'ranking',
    };
  }
  
  // Fallback till tabellparsning
  const points: DataPoint[] = [];
  let title = '';
  let unit = '';

  // Försök extrahera från markdown-tabeller
  const tableLines = text.split('\n').filter(line => line.includes('|') && !line.match(/^[\s|:-]+$/));
  if (tableLines.length >= 2) {
    const dataStartIdx = tableLines[1]?.match(/^[\s|:-]+$/) ? 2 : 1;
    
    for (let i = dataStartIdx; i < tableLines.length; i++) {
      const line = tableLines[i];
      if (line.match(/^[\s|:-]+$/)) continue;
      
      const cells = line.split('|').map(c => c.trim()).filter(c => c);
      if (cells.length >= 2) {
        const label = cells[0].replace(/^\d+\.\s*/, '').replace(/\*\*/g, '');
        
        for (let j = 1; j < cells.length; j++) {
          const cleanedCell = cells[j].replace(/\s+/g, '').replace(',', '.');
          const numMatch = cleanedCell.match(/^-?([\d.]+)/);
          if (numMatch) {
            const value = parseFloat(numMatch[0]);
            if (!isNaN(value) && Math.abs(value) > 0) {
              points.push({ label, value: Math.abs(value) });
              break;
            }
          }
        }
      }
    }
  }

  // Ta bort dubletter
  const uniquePoints: DataPoint[] = [];
  const seenLabels = new Set<string>();
  for (const point of points) {
    const normalizedLabel = point.label.toLowerCase();
    if (!seenLabels.has(normalizedLabel)) {
      seenLabels.add(normalizedLabel);
      uniquePoints.push(point);
    }
  }

  if (uniquePoints.length < 2) return null;

  // Bestäm enhet
  if (text.includes('kr')) unit = 'kr';
  else if (text.includes('%')) unit = '%';

  // Titel
  if (text.includes('mediannettoinkomst')) title = 'Mediannettoinkomst';
  else if (text.includes('skattesats')) title = 'Kommunalskattesats';

  return {
    points: uniquePoints,
    title: title || undefined,
    unit: unit || undefined,
    showType: 'ranking',
  };
}
