"use client";

import { useState, useEffect } from "react";
import { RefreshCw, Trash2, AlertCircle, Info, AlertTriangle, Bug, Copy, Check, ChevronDown, ChevronRight } from "lucide-react";

interface LogEntry {
  timestamp: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';
  category: string;
  message: string;
  data?: unknown;
}

export default function LogViewer() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [filter, setFilter] = useState<string>('ALL');
  const [copied, setCopied] = useState(false);
  const [expandedItems, setExpandedItems] = useState<Set<number>>(new Set());
  const [compactView, setCompactView] = useState(true);

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/log');
      if (response.ok) {
        const data = await response.json();
        setLogs(data.logs || []);
      }
    } catch (e) {
      console.error('Failed to fetch logs:', e);
    }
    setLoading(false);
  };

  const clearLogs = async () => {
    try {
      await fetch('/api/log', { method: 'DELETE' });
      setLogs([]);
    } catch (e) {
      console.error('Failed to clear logs:', e);
    }
  };

  const copyLogs = async () => {
    const logText = filteredLogs.map(log => {
      let text = `[${log.timestamp.substring(11, 19)}] [${log.level}] [${log.category}] ${log.message}`;
      if (log.data) {
        text += `\n${JSON.stringify(log.data, null, 2)}`;
      }
      return text;
    }).join('\n\n');
    
    await navigator.clipboard.writeText(logText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleExpand = (index: number) => {
    const newExpanded = new Set(expandedItems);
    if (newExpanded.has(index)) {
      newExpanded.delete(index);
    } else {
      newExpanded.add(index);
    }
    setExpandedItems(newExpanded);
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(fetchLogs, 2000);
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const filteredLogs = filter === 'ALL' 
    ? logs 
    : logs.filter(l => l.level === filter || l.category === filter);

  const getLevelIcon = (level: string) => {
    switch (level) {
      case 'ERROR': return <AlertCircle className="w-4 h-4 text-red-400" />;
      case 'WARN': return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'DEBUG': return <Bug className="w-4 h-4 text-purple-400" />;
      default: return <Info className="w-4 h-4 text-blue-400" />;
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'ERROR': return 'border-red-800 bg-red-950/20';
      case 'WARN': return 'border-yellow-800 bg-yellow-950/20';
      case 'DEBUG': return 'border-purple-800 bg-purple-950/20';
      default: return 'border-slate-700 bg-slate-800/50';
    }
  };

  // Formatera data för kompakt visning
  const formatCompactData = (data: unknown): string => {
    if (!data) return '';
    if (typeof data === 'object' && data !== null) {
      const obj = data as Record<string, unknown>;
      const parts: string[] = [];
      
      // Fråga
      if (obj.question) return `"${String(obj.question).substring(0, 60)}..."`;
      
      // Analys
      if (obj.intent) parts.push(`intent: ${obj.intent}`);
      if (obj.explanation) return String(obj.explanation).substring(0, 80);
      
      // Söktermer och år
      if (obj.searchTerms && Array.isArray(obj.searchTerms)) {
        parts.push(`sök: ${(obj.searchTerms as string[]).join(', ')}`);
      }
      if (obj.years && Array.isArray(obj.years)) {
        parts.push(`år: ${(obj.years as number[]).join(', ')}`);
      }
      if (obj.municipalities && Array.isArray(obj.municipalities)) {
        parts.push(`kommun: ${(obj.municipalities as string[]).join(', ')}`);
      }
      
      // KPIs
      if (obj.kpiIds) return `${(obj.kpiIds as string[]).length} KPIs`;
      if (obj.kpis) return `${(obj.kpis as string[]).length} KPIs`;
      if (obj.firstFive) return `Första: ${(obj.firstFive as string[]).join(', ')}`;
      if (obj.allKpiIds) return `${(obj.allKpiIds as string[]).length} KPIs totalt`;
      
      // Kommuner
      if (obj.names) return `Söker: ${(obj.names as string[]).join(', ')}`;
      if (obj.id) return `ID: ${obj.id}`;
      
      if (parts.length > 0) return parts.join(' | ');
    }
    return JSON.stringify(data).substring(0, 80);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-900">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3 p-4 border-b border-slate-700">
        <h2 className="text-lg font-semibold text-white">Loggar</h2>
        
        <div className="flex-1" />
        
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="bg-slate-800 text-white rounded px-3 py-1.5 text-sm border border-slate-600"
        >
          <option value="ALL">Alla</option>
          <option value="QUERY">Frågor</option>
          <option value="ANALYZE">Analys</option>
          <option value="KPI_SELECT">KPI-val</option>
          <option value="MUNICIPALITY">Kommuner</option>
          <option value="KPI_SEARCH">KPI-sökning</option>
          <option value="DATA_FETCH">Datahämtning</option>
          <option value="WARN">Varningar</option>
          <option value="ERROR">Fel</option>
        </select>

        <label className="flex items-center gap-2 text-sm text-slate-300">
          <input
            type="checkbox"
            checked={compactView}
            onChange={(e) => setCompactView(e.target.checked)}
            className="rounded"
          />
          Kompakt
        </label>

        <label className="flex items-center gap-2 text-sm text-slate-300">
          <input
            type="checkbox"
            checked={autoRefresh}
            onChange={(e) => setAutoRefresh(e.target.checked)}
            className="rounded"
          />
          Auto
        </label>

        <button
          onClick={copyLogs}
          className="p-2 rounded bg-slate-700 hover:bg-slate-600 text-white flex items-center gap-1"
          title="Kopiera alla loggar"
        >
          {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
        </button>

        <button
          onClick={fetchLogs}
          disabled={loading}
          className="p-2 rounded bg-slate-700 hover:bg-slate-600 text-white disabled:opacity-50"
          title="Uppdatera"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>

        <button
          onClick={clearLogs}
          className="p-2 rounded bg-red-900 hover:bg-red-800 text-white"
          title="Rensa loggar"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Logs */}
      <div className="flex-1 overflow-auto p-4 space-y-1.5 font-mono text-sm">
        {filteredLogs.length === 0 ? (
          <div className="text-slate-500 text-center py-8">
            <p>Inga loggar att visa.</p>
            <p className="text-xs mt-2">Ställ en fråga i chatten för att se loggar.</p>
          </div>
        ) : (
          filteredLogs.slice().reverse().map((log, i) => {
            const hasData = log.data !== undefined && log.data !== null;
            const isExpanded = expandedItems.has(i);
            
            return (
              <div 
                key={i} 
                className={`rounded border ${getLevelColor(log.level)} ${hasData ? 'cursor-pointer' : ''}`}
                onClick={() => hasData && toggleExpand(i)}
              >
                <div className="flex items-center gap-2 p-2">
                  {hasData && (
                    isExpanded ? 
                      <ChevronDown className="w-3 h-3 text-slate-500 flex-shrink-0" /> : 
                      <ChevronRight className="w-3 h-3 text-slate-500 flex-shrink-0" />
                  )}
                  {!hasData && <span className="w-3" />}
                  {getLevelIcon(log.level)}
                  <span className="text-slate-500 text-xs">
                    {log.timestamp.substring(11, 19)}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-slate-700/50 text-xs text-slate-400">
                    {log.category}
                  </span>
                  <span className="text-white flex-1">{log.message}</span>
                  {compactView && hasData && !isExpanded && (
                    <span className="text-slate-500 text-xs truncate max-w-xs">
                      {formatCompactData(log.data)}
                    </span>
                  )}
                </div>
                {hasData && (!compactView || isExpanded) && (
                  <pre className="mx-2 mb-2 p-2 bg-slate-900/50 rounded text-xs text-slate-300 overflow-x-auto max-h-60">
                    {JSON.stringify(log.data, null, 2)}
                  </pre>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Status bar */}
      <div className="p-2 border-t border-slate-700 text-xs text-slate-400 flex justify-between items-center">
        <span>{filteredLogs.length} loggar</span>
        <div className="flex gap-4">
          {autoRefresh && <span className="text-green-400">● Auto</span>}
          {copied && <span className="text-green-400">✓ Kopierat</span>}
        </div>
      </div>
    </div>
  );
}
