import { NextRequest, NextResponse } from "next/server";

/**
 * API-route för att hämta OU-data (skolnivå) från Kolada
 * GET /api/oudata?kpi=N15504&ou=V15E188016001&year=2023
 * GET /api/oudata?kpi=N15504&ous=V15E188016001,V15E188014402&year=2023
 */
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const kpi = searchParams.get('kpi');
  const ou = searchParams.get('ou');
  const ous = searchParams.get('ous'); // Kommaseparerad lista
  const year = searchParams.get('year');
  
  if (!kpi) {
    return NextResponse.json({ error: "kpi parameter krävs" }, { status: 400 });
  }
  
  if (!ou && !ous) {
    return NextResponse.json({ error: "ou eller ous parameter krävs" }, { status: 400 });
  }
  
  if (!year) {
    return NextResponse.json({ error: "year parameter krävs" }, { status: 400 });
  }
  
  try {
    const ouIds = ous ? ous.split(',') : [ou!];
    
    // Bygg URL - Kolada stödjer flera OUs i samma anrop
    const ouParam = ouIds.join(',');
    const url = `https://api.kolada.se/v3/oudata/kpi/${kpi}/ou/${ouParam}/year/${year}`;
    
    console.log(`[OUDATA API] Hämtar: ${url}`);
    
    const response = await fetch(url, {
      signal: AbortSignal.timeout(60000) // 60 sekunder timeout
    });
    
    if (!response.ok) {
      throw new Error(`Kolada API svarade med ${response.status}`);
    }
    
    const data = await response.json();
    
    // Formatera resultatet
    const results = (data.values || []).map((item: {
      kpi: string;
      period: number;
      ou: string;
      values: { gender: string; value: number | null; count: number }[];
    }) => {
      const totalValue = item.values?.find(v => v.gender === 'T');
      return {
        kpi: item.kpi,
        year: item.period,
        ouId: item.ou,
        value: totalValue?.value ?? null,
        values: item.values
      };
    });
    
    console.log(`[OUDATA API] Hämtade ${results.length} datapunkter för ${ouIds.length} OUs`);
    
    return NextResponse.json({
      count: results.length,
      data: results
    });
    
  } catch (error) {
    console.error('[OUDATA API] Fel:', error);
    return NextResponse.json(
      { error: "Kunde inte hämta OU-data", details: String(error) },
      { status: 500 }
    );
  }
}
