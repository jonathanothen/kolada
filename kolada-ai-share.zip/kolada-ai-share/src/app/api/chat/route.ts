import { NextRequest, NextResponse } from "next/server";
import { GoogleGenerativeAI } from "@google/generative-ai";

const SYSTEM_PROMPT = `Du är en expert på svensk kommunal statistik från Kolada-databasen.

═══════════════════════════════════════════════════════════════
VIKTIGT: DATA HÄMTAS AUTOMATISKT - FRÅGA ALDRIG OM BEKRÄFTELSE!
═══════════════════════════════════════════════════════════════

Systemet hämtar automatiskt data baserat på användarens fråga.
- Om data finns i kontexten → ANVÄND DEN och svara direkt
- Om data saknas → Förklara kort och be användaren omformulera frågan

ALDRIG:
✗ Fråga "Vill du att jag hämtar data?"
✗ Fråga "Ska jag göra det?"
✗ Säg "Jag kan hämta detta om du vill"
✗ Be om bekräftelse innan du svarar

ALLTID:
✓ Svara direkt med den data som finns
✓ Presentera resultatet tydligt
✓ Om något saknas, förklara vad som behövs för att svara

═══════════════════════════════════════════════════════════════
KOMBINERA OCH BERÄKNA DATA
═══════════════════════════════════════════════════════════════

1. KOMBINERA DATA FRÅN FLERA KPIs
   Många frågor kräver data från FLERA KPIs. Exempel:
   - "Antal utrikes födda" = N02926 (andel %) × N01951 (folkmängd)
   - "Lediga bostäder/inv" = (N07913/1000 × N01951 - N02938) / N01951
   - "Kostnad per portion" ≈ N15013 (kr/elev) / antal måltider per år
   
   LETA ALLTID igenom ALL data i kontexten - ofta finns flera KPIs.

2. BERÄKNA AUTOMATISKT NÄR DATA FINNS
   Om frågan inte kan besvaras direkt men du har data som KAN kombineras:
   
   ABSOLUTA TAL från andel:
   antal = (andel% / 100) × totalantal
   
   FÖRÄNDRING:
   förändring = värde_år2 - värde_år1
   procentuell förändring = ((år2 - år1) / år1) × 100
   
   GENOMSNITT:
   snitt = summa / antal
   
   Visa ALLTID din beräkning så användaren kan verifiera.

3. OM ÅR SAKNAR DATA
   Många nyare KPIs (t.ex. N02251, N02252) startade ~2019-2020.
   Om användaren frågar om 2010-2024 men data bara finns 2019-2024:
   
   ✓ BRA: "Data finns från 2019. Förändring 2019-2024: Örebro ökade från 6,8% till 7,5%"
   ✗ DÅLIGT: "Kan inte svara då data saknas för 2010"
   
   ANVÄND ALLTID den tidigaste/senaste tillgängliga datan!

4. OM DATA VERKAR SAKNAS I KONTEXTEN
   Innan du säger att data saknas:
   a) Finns data under ANNAT namn? (skolmat = måltider, invånare = folkmängd)
   b) Kan svaret BERÄKNAS från befintlig data?
   c) Finns data för ANNAT år som kan användas som approximation?
   d) ERBJUD att hämta den data som behövs!

5. SÖKSTRATEGIER (för systemet, inte dig)
   Om rätt KPI inte hittas, testa synonymer:
   - "skolmat" → måltider, kostnad, lunch
   - "invandrare" → utrikes födda, utländsk bakgrund
   - "lärartäthet" → elever per lärare, personal
   - "befolkning" → invånare, folkmängd
   - "skatt" → skattesats, kommunalskatt

═══════════════════════════════════════════════════════════════
FORMATERING - HÅLL DET SNYGGT OCH ENKELT
═══════════════════════════════════════════════════════════════

UNDVIK:
- Överdriven användning av **fetstil** och *kursiv*
- Upprepningar och redundans

ANVÄND:
- Rena tabeller för jämförelser
- Korta sammanfattningar först, detaljer sedan

SVARSSTRUKTUR:

1. SAMMANFATTNING FÖRST (1-2 meningar)
   "Lekeberg hade högst mediannettoinkomst (298 300 kr), Ljusnarsberg lägst (235 000 kr)."

2. TABELL FÖR DATA (inkludera ALLA relevanta rader)
   | Kommun | Värde |
   |--------|-------|
   | ... alla kommuner med data ... |

3. KÄLLA (kort)
   Källa: N00905

═══════════════════════════════════════════════════════════════
DYNAMISKT DIAGRAM - VIKTIGT!
═══════════════════════════════════════════════════════════════
Efter ditt svar, lägg till ett JSON-block för visualisering.
Du bestämmer HELT SJÄLV vilka datapunkter som ska visas och hur.

Format (lägg detta SIST i ditt svar):
\`\`\`chart
{
  "title": "Mediannettoinkomst 2023",
  "unit": "kr",
  "data": [
    {"label": "Lekeberg", "value": 298300, "color": "green"},
    {"label": "Kumla", "value": 289600, "color": "blue"},
    {"label": "Ljusnarsberg", "value": 235000, "color": "red"}
  ]
}
\`\`\`

REGLER FÖR DIAGRAM:
- Inkludera ALLA relevanta datapunkter från din tabell
- color: "green" = bäst/högst, "red" = sämst/lägst, "blue" = övriga
- Du bestämmer själv hur många staplar som behövs
- Om det finns 12 kommuner i tabellen, visa alla 12 i diagrammet
- Sortera data i rätt ordning (högst till lägst eller tvärtom beroende på frågan)

═══════════════════════════════════════════════════════════════
VIKTIGT
═══════════════════════════════════════════════════════════════
- Svara ALLTID på svenska
- Använd tusentalsavgränsare i text (7 689) men INTE i JSON (7689)
- Ange årtal för all data
- KPI-ID i slutet, inte mitt i texten
- Hitta ALDRIG på siffror
- Inkludera ALLTID chart-blocket om du har numerisk data`;



interface ConversationMessage {
  role: "user" | "assistant";
  content: string;
}

// Giltiga modeller (uppdaterat för 2025)
const VALID_MODELS = [
  "gemini-2.5-flash",      // Rekommenderad - snabb och kraftfull
  "gemini-2.5-pro",        // Mest kraftfull
  "gemini-2.5-flash-lite", // Snabbast och billigast
  "gemini-2.0-flash",      // Äldre men stabil
  "gemini-1.5-pro",
  "gemini-1.5-flash",
];
const DEFAULT_MODEL = "gemini-2.5-flash";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      message, 
      apiKey, 
      model: requestedModel = DEFAULT_MODEL, 
      context = "",
      conversationHistory = []
    } = body;

    // Validera modellen - fallback till default om ogiltig
    const model = VALID_MODELS.includes(requestedModel) ? requestedModel : DEFAULT_MODEL;
    
    // Använd server-side API-nyckel som fallback
    const effectiveApiKey = apiKey || process.env.GEMINI_API_KEY;
    const usingServerKey = !apiKey && !!process.env.GEMINI_API_KEY;
    
    console.log(`[CHAT] Request - Model: ${model} (requested: ${requestedModel}), Using server key: ${usingServerKey}`);
    
    if (!effectiveApiKey) {
      return NextResponse.json(
        { error: "API-nyckel saknas. Kontakta administratören." },
        { status: 400 }
      );
    }

    if (!message) {
      return NextResponse.json(
        { error: "Meddelande krävs" },
        { status: 400 }
      );
    }

    const genAI = new GoogleGenerativeAI(effectiveApiKey);
    const geminiModel = genAI.getGenerativeModel({ model });

    // Build conversation history string
    let historyText = "";
    if (conversationHistory.length > 0) {
      historyText = "\n\n=== TIDIGARE KONVERSATION ===\n";
      conversationHistory.forEach((msg: ConversationMessage) => {
        const role = msg.role === "user" ? "Användare" : "Assistent";
        historyText += `${role}: ${msg.content}\n\n`;
      });
    }

    // Build the full prompt - UTAN KPI-index (analysen har redan valt KPIs)
    let prompt = SYSTEM_PROMPT;
    
    if (historyText) {
      prompt += historyText;
    }
    
    if (context) {
      prompt += `\n\n=== DATA FRÅN KOLADA (använd denna data för att svara) ===\n${context}`;
    }
    
    prompt += `\n\n=== NUVARANDE FRÅGA ===\nAnvändare: ${message}\n\nAssistent:`;

    // Retry-logik för Gemini API (hanterar tillfälliga fel)
    let text = "";
    let lastError: Error | null = null;
    const MAX_RETRIES = 3;
    
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        const result = await geminiModel.generateContent(prompt);
        const response = await result.response;
        text = response.text() || "Kunde inte generera ett svar.";
        lastError = null;
        break; // Lyckades!
      } catch (retryError) {
        lastError = retryError instanceof Error ? retryError : new Error(String(retryError));
        console.error(`[CHAT] Gemini-fel (försök ${attempt}/${MAX_RETRIES}):`, lastError.message);
        
        // Vänta innan retry (exponentiell backoff)
        if (attempt < MAX_RETRIES) {
          const waitMs = 1000 * Math.pow(2, attempt - 1); // 1s, 2s, 4s
          console.log(`[CHAT] Väntar ${waitMs}ms innan retry...`);
          await new Promise(resolve => setTimeout(resolve, waitMs));
        }
      }
    }
    
    // Om alla retries misslyckades
    if (lastError) {
      throw lastError;
    }

    return NextResponse.json({ response: text });
  } catch (error: unknown) {
    console.error("Chat API error:", error);
    
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    
    if (errorMessage.includes("API_KEY") || errorMessage.includes("401")) {
      return NextResponse.json(
        { error: "Ogiltig API-nyckel. Kontrollera din Google Gemini API-nyckel." },
        { status: 401 }
      );
    }
    
    // Nätverks/timeout-fel
    if (errorMessage.includes("timeout") || errorMessage.includes("ETIMEDOUT") || 
        errorMessage.includes("fetch") || errorMessage.includes("network") ||
        errorMessage.includes("ECONNRESET") || errorMessage.includes("socket") ||
        errorMessage.includes("503") || errorMessage.includes("overloaded")) {
      return NextResponse.json(
        { error: "AI-tjänsten är tillfälligt överbelastad. Försök igen om några sekunder." },
        { status: 503 }
      );
    }

    return NextResponse.json(
      { error: "Ett fel uppstod. Försök igen." },
      { status: 500 }
    );
  }
}
