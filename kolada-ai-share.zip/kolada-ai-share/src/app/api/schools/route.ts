import { NextRequest, NextResponse } from "next/server";
import * as fs from 'fs';
import * as path from 'path';

/**
 * API-route för att hämta skolor (OU = Organizational Units) från Kolada
 * GET /api/schools?municipality=1880
 * GET /api/schools?municipalities=1880,1881,1882  (BATCH - flera kommuner!)
 * GET /api/schools?municipality=1880&type=grundskola
 * 
 * OPTIMERAD VERSION:
 * 1. Försöker först använda lokal OU-databas (om synkad)
 * 2. Fallback till in-memory cache + API med retry
 */

// Lokal OU-databas (laddas vid uppstart om filen finns)
let localOUData: {
  byMunicipality: { [munId: string]: Array<{ id: string; title: string; municipality: string; type: string }> };
  syncedAt: string;
} | null = null;

// Försök ladda lokal data vid modulstart
try {
  const localPath = path.join(process.cwd(), 'src', 'data', 'ous.json');
  if (fs.existsSync(localPath)) {
    const data = JSON.parse(fs.readFileSync(localPath, 'utf-8'));
    localOUData = data;
    console.log(`[SCHOOLS API] Lokal OU-databas laddad (${data.totalCount} enheter, synkad ${data.syncedAt})`);
  }
} catch (e) {
  console.log('[SCHOOLS API] Ingen lokal OU-databas tillgänglig, använder API');
}

// In-memory cache för OU-data per kommun (fallback)
const ouCache: Map<string, { data: Array<{ id: string; title: string; municipality: string }>; timestamp: number }> = new Map();
const CACHE_TTL = 60 * 60 * 1000; // 1 timme

// Hjälpfunktion för att hämta med retry
async function fetchWithRetry(url: string, retries = 2): Promise<Response> {
  for (let i = 0; i <= retries; i++) {
    try {
      const response = await fetch(url, {
        signal: AbortSignal.timeout(30000) // 30 sekunder timeout
      });
      if (response.ok) return response;
      
      // Om det är sista försöket, returnera response ändå
      if (i === retries) return response;
      
      // Vänta lite innan retry (exponentiell backoff)
      await new Promise(r => setTimeout(r, 1000 * (i + 1)));
    } catch (e) {
      if (i === retries) throw e;
      // Vänta innan retry
      await new Promise(r => setTimeout(r, 1000 * (i + 1)));
    }
  }
  throw new Error('Fetch failed after retries');
}

// Hämta OUs för en kommun (med cache)
async function getOUsForMunicipality(munId: string): Promise<Array<{ id: string; title: string; municipality: string }>> {
  // Kolla cache först
  const cached = ouCache.get(munId);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    console.log(`[SCHOOLS API] Cache HIT för kommun ${munId}`);
    return cached.data;
  }
  
  console.log(`[SCHOOLS API] Cache MISS - hämtar från Kolada för kommun ${munId}`);
  
  const url = `https://api.kolada.se/v3/ou?municipality=${munId}&per_page=1000`;
  const response = await fetchWithRetry(url);
  
  if (!response.ok) {
    console.error(`[SCHOOLS API] Kolada-fel för kommun ${munId}: ${response.status}`);
    return [];
  }
  
  const data = await response.json();
  const ous = (data.values || []).map((ou: { id: string; title: string; municipality: string }) => ({
    id: ou.id,
    title: ou.title,
    municipality: ou.municipality || munId
  }));
  
  // Spara i cache
  ouCache.set(munId, { data: ous, timestamp: Date.now() });
  console.log(`[SCHOOLS API] Cachade ${ous.length} OUs för kommun ${munId}`);
  
  return ous;
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const municipality = searchParams.get('municipality');
  const municipalities = searchParams.get('municipalities');
  const type = searchParams.get('type'); // grundskola, förskola, gymnasium, all
  
  const munIds = municipalities ? municipalities.split(',') : (municipality ? [municipality] : []);
  
  if (munIds.length === 0) {
    return NextResponse.json(
      { error: "municipality eller municipalities parameter krävs" },
      { status: 400 }
    );
  }
  
  try {
    // OU-typens ID-prefix
    const typePrefix: { [key: string]: string | null } = {
      'grundskola': 'V15',
      'gymnasium': 'V17',
      'förskola': 'V11',
      'all': null // Alla typer
    };
    
    const idPrefix = type ? typePrefix[type] : 'V15';
    const allSchools: { id: string; name: string; municipalityId: string; type: string }[] = [];
    
    // ========================================
    // STRATEGI 1: Använd lokal OU-databas (SNABBAST)
    // ========================================
    // Kolla vilka kommuner som finns i lokal databas
    const localMunIds = localOUData ? munIds.filter(id => localOUData.byMunicipality[id]?.length > 0) : [];
    const remoteMunIds = munIds.filter(id => !localMunIds.includes(id));
    
    // Hämta från lokal databas
    if (localMunIds.length > 0 && localOUData) {
      console.log(`[SCHOOLS API] LOKAL databas för ${localMunIds.length} kommuner`);
      
      for (const munId of localMunIds) {
        const ous = localOUData.byMunicipality[munId] || [];
        
        for (const ou of ous) {
          if (idPrefix !== null && !ou.id.startsWith(idPrefix)) continue;
          if (idPrefix === null && !['V11', 'V15', 'V17'].some(p => ou.id.startsWith(p))) continue;
          if (type === 'grundskola' && ou.title.toLowerCase().includes('anpassad')) continue;
          
          allSchools.push({
            id: ou.id,
            name: ou.title,
            municipalityId: munId,
            type: ou.type || (ou.id.startsWith('V15') ? 'grundskola' : 
                  ou.id.startsWith('V17') ? 'gymnasium' : 
                  ou.id.startsWith('V11') ? 'förskola' : 'okänd')
          });
        }
      }
    }
    
    // Om alla kommuner fanns lokalt, returnera direkt
    if (remoteMunIds.length === 0 && allSchools.length > 0) {
      console.log(`[SCHOOLS API] ✓ ${allSchools.length} enheter från LOKAL databas (0 API-anrop!)`);
      return NextResponse.json({
        count: allSchools.length,
        schools: allSchools,
        source: 'local',
        syncedAt: localOUData?.syncedAt
      });
    }
    
    // ========================================
    // STRATEGI 2: Fallback till API för kommuner som saknas i lokal databas
    // ========================================
    if (remoteMunIds.length === 0) {
      // Inget att hämta från API
      return NextResponse.json({
        count: allSchools.length,
        schools: allSchools,
        source: 'local',
        syncedAt: localOUData?.syncedAt
      });
    }
    
    console.log(`[SCHOOLS API] Hämtar OUs för ${remoteMunIds.length} kommuner via API (PARALLELLT)`);
    
    const results = await Promise.allSettled(
      remoteMunIds.map(munId => getOUsForMunicipality(munId))
    );
    
    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        const ous = result.value;
        const munId = remoteMunIds[index];
        
        // Filtrera på typ
        const filtered = ous.filter(ou => {
          if (idPrefix === null) {
            return ou.id.startsWith('V11') || ou.id.startsWith('V15') || ou.id.startsWith('V17');
          }
          if (!ou.id.startsWith(idPrefix)) return false;
          if (type === 'grundskola' && ou.title.toLowerCase().includes('anpassad')) return false;
          return true;
        });
        
        filtered.forEach(ou => {
          allSchools.push({
            id: ou.id,
            name: ou.title,
            municipalityId: munId,
            type: ou.id.startsWith('V15') ? 'grundskola' : 
                  ou.id.startsWith('V17') ? 'gymnasium' : 
                  ou.id.startsWith('V11') ? 'förskola' : 'okänd'
          });
        });
      } else {
        console.error(`[SCHOOLS API] Fel för kommun ${remoteMunIds[index]}:`, result.reason);
      }
    });
    
    const source = localMunIds.length > 0 ? 'mixed' : 'api';
    console.log(`[SCHOOLS API] Hittade ${allSchools.length} enheter (${localMunIds.length} lokalt, ${remoteMunIds.length} från API)`);
    
    return NextResponse.json({
      count: allSchools.length,
      schools: allSchools,
      source,
      localCount: localMunIds.length,
      apiCount: remoteMunIds.length,
      cached: results.filter((_, i) => ouCache.has(remoteMunIds[i])).length
    });
    
  } catch (error) {
    console.error('[SCHOOLS API] Fel:', error);
    return NextResponse.json(
      { error: "Kunde inte hämta skolor", details: String(error) },
      { status: 500 }
    );
  }
}
