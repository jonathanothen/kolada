import { NextResponse } from "next/server";
import * as fs from 'fs';
import * as path from 'path';

// Cache för kommun-data
let municipalityCache: {
  lookup: { [name: string]: { id: string; name: string; type?: string } };
  municipalities: { id: string; name: string; type: string }[];
  count: number;
} | null = null;

function loadMunicipalities() {
  if (!municipalityCache) {
    try {
      const dataPath = path.join(process.cwd(), 'src/data/municipalities.json');
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
      municipalityCache = {
        lookup: data.lookup || {},
        municipalities: data.municipalities || [],
        count: data.count || 0
      };
      console.log(`[MUNICIPALITIES API] Laddade ${municipalityCache.count} kommuner/regioner`);
    } catch (e) {
      console.error('[MUNICIPALITIES API] Kunde inte ladda municipalities.json:', e);
      municipalityCache = { lookup: {}, municipalities: [], count: 0 };
    }
  }
  return municipalityCache;
}

export async function GET() {
  const data = loadMunicipalities();
  return NextResponse.json(data);
}
