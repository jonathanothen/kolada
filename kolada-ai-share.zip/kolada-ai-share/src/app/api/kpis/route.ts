import { NextRequest, NextResponse } from "next/server";
import { searchKPIs, getKPIById, getDatabaseStatus, isDatabasePopulated, KPI } from "@/lib/kpi-database";

/**
 * API-route för att söka i den lokala KPI-databasen.
 * GET /api/kpis?search=sökterm1,sökterm2
 * GET /api/kpis?id=N00909
 * GET /api/kpis/status
 */
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  
  // Kontrollera databasstatus
  const statusParam = searchParams.get('status');
  if (statusParam === 'true') {
    const status = getDatabaseStatus();
    return NextResponse.json(status);
  }
  
  // Om databasen är tom, fallback till API
  if (!isDatabasePopulated()) {
    return NextResponse.json({
      error: "KPI-databas ej tillgänglig. Kör: npm run sync-kpis",
      fallbackToAPI: true,
    }, { status: 503 });
  }
  
  // Hämta specifik KPI med ID
  const id = searchParams.get('id');
  if (id) {
    const kpi = getKPIById(id);
    if (kpi) {
      return NextResponse.json({ kpi });
    }
    return NextResponse.json({ error: "KPI ej hittad" }, { status: 404 });
  }
  
  // Sök efter KPIs
  const searchParam = searchParams.get('search');
  if (searchParam) {
    const searchTerms = searchParam.split(',').map(t => t.trim()).filter(Boolean);
    
    if (searchTerms.length === 0) {
      return NextResponse.json({ error: "Söktermer krävs" }, { status: 400 });
    }
    
    const results = searchKPIs(searchTerms);
    
    return NextResponse.json({
      count: results.length,
      searchTerms,
      kpis: results.map((kpi: KPI) => ({
        id: kpi.id,
        title: kpi.title,
        description: kpi.description,
        has_ou_data: kpi.has_ou_data,
      })),
    });
  }
  
  return NextResponse.json({ 
    error: "Ange sökparameter: ?search=sökterm eller ?id=N00909" 
  }, { status: 400 });
}
