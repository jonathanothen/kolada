import { NextRequest, NextResponse } from "next/server";
import * as fs from 'fs';
import * as path from 'path';

/**
 * API-endpoint for att hamta oudata fran LOKAL CACHE
 * 
 * FORDELAR:
 * - Inga API-anrop till Kolada
 * - Snabbt (millisekunder istallet for sekunder)
 * - Inga timeouts eller rate limiting
 * 
 * ANVANDNING:
 * GET /api/oudata-local?kpi=N15504&year=2023&type=grundskola&municipalities=1880,1881
 * 
 * KRAV: Kor "python scripts/sync-oudata.py" for att ladda ner data forst
 */

interface OUDataCache {
  syncedAt: string;
  kpis: {
    [kpiId: string]: {
      years: {
        [year: string]: Array<{ ou: string; value: number }>;
      };
    };
  };
}

interface OUCache {
  byMunicipality: {
    [munId: string]: Array<{ id: string; title: string; type: string }>;
  };
}

// Ladda cacher vid modulstart
let oudataCache: OUDataCache | null = null;
let ouCache: OUCache | null = null;
let ouNameCache: { [ouId: string]: string } = {};

function loadCaches() {
  // Ladda oudata-cache
  try {
    const oudataPath = path.join(process.cwd(), 'src', 'data', 'oudata-cache.json');
    if (fs.existsSync(oudataPath)) {
      oudataCache = JSON.parse(fs.readFileSync(oudataPath, 'utf-8'));
      console.log(`[OUDATA-LOCAL] Laddade oudata-cache (synkad ${oudataCache?.syncedAt})`);
    }
  } catch (e) {
    console.log('[OUDATA-LOCAL] Ingen oudata-cache tillganglig');
  }

  // Ladda ou-cache (for namn)
  try {
    const ouPath = path.join(process.cwd(), 'src', 'data', 'ous.json');
    if (fs.existsSync(ouPath)) {
      ouCache = JSON.parse(fs.readFileSync(ouPath, 'utf-8'));
      console.log(`[OUDATA-LOCAL] Laddade ou-cache`);
    }
  } catch (e) {
    console.log('[OUDATA-LOCAL] Ingen ou-cache tillganglig');
  }
  
  // Ladda extra OU-namn (t.ex. Orebro lan)
  try {
    const ouNamesPath = path.join(process.cwd(), 'src', 'data', 'ou-names-orebro.json');
    if (fs.existsSync(ouNamesPath)) {
      ouNameCache = JSON.parse(fs.readFileSync(ouNamesPath, 'utf-8'));
      console.log(`[OUDATA-LOCAL] Laddade ${Object.keys(ouNameCache).length} extra OU-namn`);
    }
  } catch (e) {
    console.log('[OUDATA-LOCAL] Inga extra OU-namn tillgangliga');
  }
}

// Ladda vid import
loadCaches();

// OU-typ prefix
const OU_TYPE_PREFIX: { [type: string]: string } = {
  'grundskola': 'V15',
  'gymnasium': 'V17',
  'forskola': 'V11',
  'aldreboende': 'V23',
  'hemtjanst': 'V21',
};

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const kpi = searchParams.get('kpi');
  const year = searchParams.get('year');
  const type = searchParams.get('type');
  const municipalities = searchParams.get('municipalities');

  if (!kpi) {
    return NextResponse.json({ error: 'kpi parameter kravs' }, { status: 400 });
  }

  if (!year) {
    return NextResponse.json({ error: 'year parameter kravs' }, { status: 400 });
  }

  // Ladda om cacher om de inte finns
  if (!oudataCache) {
    loadCaches();
  }

  // Kolla om vi har data
  if (!oudataCache) {
    return NextResponse.json({
      error: 'Ingen lokal oudata-cache. Kor "python scripts/sync-oudata.py" forst.',
      hasCache: false,
    }, { status: 503 });
  }

  // Hamta data for KPI och ar
  const kpiData = oudataCache.kpis[kpi];
  if (!kpiData) {
    return NextResponse.json({
      error: `Ingen data for KPI ${kpi}. Kor sync-script for att ladda ner.`,
      availableKpis: Object.keys(oudataCache.kpis),
    }, { status: 404 });
  }

  const yearData = kpiData.years[year];
  if (!yearData) {
    return NextResponse.json({
      error: `Ingen data for ar ${year}. Tillgangliga ar: ${Object.keys(kpiData.years).join(', ')}`,
      availableYears: Object.keys(kpiData.years),
    }, { status: 404 });
  }

  // Filtrera pa typ (OU-ID prefix)
  const typePrefix = type ? OU_TYPE_PREFIX[type] : null;
  let filteredData = yearData;
  
  if (typePrefix) {
    filteredData = yearData.filter(item => item.ou.startsWith(typePrefix));
  }

  // Filtrera pa kommuner
  // OU-ID format: V15EXXXXYYYYY dar XXXX ar kommun-ID (4 siffror)
  // Exempel: V15E188000101 -> kommun 1880 (Orebro)
  const munIds = municipalities ? municipalities.split(',') : null;
  
  if (munIds) {
    // Skapa set av kommun-ID:n (med leading zeros for 3-siffriga)
    const munIdSet = new Set(munIds.map(id => id.padStart(4, '0')));
    
    filteredData = filteredData.filter(item => {
      // Extrahera kommun-ID fran OU-ID (position 4-8 efter prefix)
      // V15E1880... -> 1880
      const ouId = item.ou;
      if (ouId.length < 8) return false;
      
      // Kommun-ID borjar pa position 4 (efter "V15E" eller liknande)
      const munIdFromOu = ouId.substring(4, 8);
      return munIdSet.has(munIdFromOu);
    });
    
    console.log(`[OUDATA-LOCAL] Filtrerade pa ${munIds.length} kommuner: ${filteredData.length} datapunkter`);
  }

  // Bygg resultat med OU-namn och typ
  const results: Array<{
    ouId: string;
    ouName: string | null;
    municipalityId: string | null;
    ouType: string;
    value: number;
  }> = [];
  
  // Funktion for att bestamma OU-typ fran ID
  function getOuType(ouId: string): string {
    if (ouId.startsWith('V15')) return 'grundskola';
    if (ouId.startsWith('V17')) return 'gymnasium';
    if (ouId.startsWith('V11')) return 'forskola';
    if (ouId.startsWith('V23')) return 'aldreboende';
    if (ouId.startsWith('V21')) return 'hemtjanst';
    return 'okand';
  }

  // Skapa OU-namn lookup
  const ouNameLookup: { [ouId: string]: { name: string; munId: string } } = {};
  
  if (ouCache) {
    for (const [munId, ous] of Object.entries(ouCache.byMunicipality)) {
      for (const ou of ous) {
        ouNameLookup[ou.id] = { name: ou.title, munId };
      }
    }
  }

  for (const item of filteredData) {
    const ouInfo = ouNameLookup[item.ou];
    // Extrahera kommun-ID fran OU-ID om inte tillgangligt fran lookup
    const munIdFromOu = item.ou.length >= 8 ? item.ou.substring(4, 8).replace(/^0+/, '') : null;
    // Anvand ouNameCache som fallback for namn
    const ouName = ouInfo?.name || ouNameCache[item.ou] || null;
    
    results.push({
      ouId: item.ou,
      ouName: ouName,
      municipalityId: ouInfo?.munId || munIdFromOu,
      ouType: getOuType(item.ou),
      value: item.value,
    });
  }

  // Sortera pa varde (hogst forst)
  results.sort((a, b) => b.value - a.value);

  return NextResponse.json({
    count: results.length,
    kpi,
    year: parseInt(year),
    type: type || 'all',
    source: 'local-cache',
    syncedAt: oudataCache.syncedAt,
    data: results,
  });
}
