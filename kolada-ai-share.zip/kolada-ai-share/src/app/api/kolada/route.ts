import { NextRequest, NextResponse } from "next/server";
import { koladaFetch, getApiStatusForFrontend } from "@/lib/kolada-client";

/**
 * Proxy-endpoint för Kolada API med rate limiting
 * Använder den centraliserade API-klienten för att undvika överbelastning
 */
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const endpoint = searchParams.get("endpoint");

  if (!endpoint) {
    return NextResponse.json({ error: "Endpoint required" }, { status: 400 });
  }

  // Build query string from remaining params
  const params = new URLSearchParams();
  searchParams.forEach((value, key) => {
    if (key !== "endpoint") {
      params.append(key, value);
    }
  });
  
  const queryString = params.toString() ? `?${params.toString()}` : '';
  const fullEndpoint = `/${endpoint}${queryString}`;
  
  console.log(`[KOLADA PROXY] ${fullEndpoint}`);
  
  const result = await koladaFetch<Record<string, unknown>>(fullEndpoint, {
    timeout: 45000, // 45 sekunder för komplexa anrop
    retries: 2,
  });
  
  if (result.blocked) {
    const status = getApiStatusForFrontend();
    return NextResponse.json({
      error: result.error,
      blocked: true,
      blockMessage: status.message,
      waitSeconds: status.waitSeconds,
      values: [] // Tom array för bakåtkompatibilitet
    });
  }
  
  if (result.error) {
    console.error("[KOLADA PROXY] Error:", result.error);
    return NextResponse.json(
      { error: result.error, values: [] },
      { status: 500 }
    );
  }
  
  return NextResponse.json(result.data);
}
