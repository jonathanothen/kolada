/**
 * Smart OU-data endpoint som dynamiskt hämtar enhetsdata för VILKEN KPI SOM HELST.
 * 
 * Strategi:
 * 1. Kolla om data finns i lokal cache
 * 2. Om inte, hämta direkt från Kolada API
 * 3. Spara i cache för framtida anrop
 * 4. Returnera tydlig feedback om vad som händer
 */

import { NextRequest, NextResponse } from 'next/server';
import * as fs from 'fs';
import * as path from 'path';

const KOLADA_BASE = 'https://api.kolada.se/v3';

// OU-typ prefix
const OU_TYPE_PREFIX: { [type: string]: string } = {
  'grundskola': 'V15',
  'gymnasium': 'V17',
  'förskola': 'V11',
  'forskola': 'V11',
  'äldreboende': 'V23',
  'aldreboende': 'V23',
  'hemtjänst': 'V21',
  'hemtjanst': 'V21',
  'lss_boende': 'V25',
  'lss_daglig': 'V26',
  'gruppbostad': 'V29',
  'servicebostad': 'V30',
  'sol_boendestod': 'V31',
  'sol_boende': 'V32',
  'sol_sysselsattning': 'V34',
};

// Cache för oudata och ou-namn
interface OUDataCache {
  syncedAt: string;
  kpis: {
    [kpiId: string]: {
      years: {
        [year: string]: Array<{ ou: string; value: number }>;
      };
    };
  };
}

interface OUCache {
  byMunicipality: {
    [munId: string]: Array<{ id: string; title: string; type: string }>;
  };
}

let oudataCache: OUDataCache | null = null;
let ouCache: OUCache | null = null;
let ouNameCache: { [ouId: string]: string } = {};
let ouToMunLookup: { [ouId: string]: string } = {};

function loadCaches() {
  const dataDir = path.join(process.cwd(), 'src', 'data');
  
  // Ladda oudata-cache
  try {
    const oudataPath = path.join(dataDir, 'oudata-cache.json');
    if (fs.existsSync(oudataPath)) {
      oudataCache = JSON.parse(fs.readFileSync(oudataPath, 'utf-8'));
      console.log(`[OUDATA-SMART] Laddade oudata-cache med ${Object.keys(oudataCache?.kpis || {}).length} KPIs`);
    }
  } catch (e) {
    console.log('[OUDATA-SMART] Ingen oudata-cache');
  }

  // Ladda ou-cache (namn) och bygg lookup
  try {
    const ouPath = path.join(dataDir, 'ous.json');
    if (fs.existsSync(ouPath)) {
      ouCache = JSON.parse(fs.readFileSync(ouPath, 'utf-8'));
      
      // Bygg snabb lookup: ouId -> munId
      if (ouCache?.byMunicipality) {
        for (const [munId, ous] of Object.entries(ouCache.byMunicipality)) {
          for (const ou of ous) {
            ouToMunLookup[ou.id] = munId;
          }
        }
      }
      
      console.log(`[OUDATA-SMART] Laddade ou-cache med ${Object.keys(ouToMunLookup).length} enheter`);
    }
  } catch (e) {
    console.log('[OUDATA-SMART] Ingen ou-cache');
  }

  // Ladda extra OU-namn
  try {
    const ouNamesPath = path.join(dataDir, 'ou-names-orebro.json');
    if (fs.existsSync(ouNamesPath)) {
      ouNameCache = JSON.parse(fs.readFileSync(ouNamesPath, 'utf-8'));
    }
  } catch (e) {}
}

loadCaches();

function getOuName(ouId: string): string | null {
  // Kolla extra namn-cache först
  if (ouNameCache[ouId]) return ouNameCache[ouId];
  
  // Kolla ou-cache
  if (ouCache) {
    for (const ous of Object.values(ouCache.byMunicipality)) {
      const ou = ous.find(o => o.id === ouId);
      if (ou) return ou.title;
    }
  }
  return null;
}

function getOuType(ouId: string): string {
  if (ouId.startsWith('V15')) return 'grundskola';
  if (ouId.startsWith('V17')) return 'gymnasium';
  if (ouId.startsWith('V11')) return 'förskola';
  if (ouId.startsWith('V23')) return 'äldreboende';
  if (ouId.startsWith('V21')) return 'hemtjänst';
  if (ouId.startsWith('V25')) return 'lss_boende';
  if (ouId.startsWith('V26')) return 'lss_daglig';
  if (ouId.startsWith('V29')) return 'gruppbostad';
  if (ouId.startsWith('V30')) return 'servicebostad';
  return 'okänd';
}

function getMunIdFromOu(ouId: string): string | null {
  // Använd snabb lookup
  if (ouToMunLookup[ouId]) {
    return ouToMunLookup[ouId];
  }
  
  // Fallback för V15 (grundskolor) där kommun-ID är kodat i OU-ID
  if (ouId.length >= 8 && ouId.startsWith('V15')) {
    return ouId.substring(4, 8).replace(/^0+/, '');
  }
  
  return null;
}

// Funktion för att hämta från Kolada API
async function fetchFromKoladaAPI(
  kpi: string, 
  year: number,
  signal?: AbortSignal
): Promise<{ data: Array<{ ou: string; value: number }>, fromApi: true } | null> {
  
  const url = `${KOLADA_BASE}/oudata/kpi/${kpi}/year/${year}?per_page=5000`;
  console.log(`[OUDATA-SMART] Hämtar från API: ${url}`);
  
  try {
    const response = await fetch(url, { 
      signal,
      headers: { 'Accept': 'application/json' }
    });
    
    if (!response.ok) {
      console.log(`[OUDATA-SMART] API svarade med ${response.status}`);
      return null;
    }
    
    const json = await response.json();
    const values = json.values || [];
    
    // Processa
    const processed: Array<{ ou: string; value: number }> = [];
    for (const item of values) {
      const ouId = item.ou || '';
      let totalValue = null;
      
      for (const v of (item.values || [])) {
        if (v.gender === 'T' && v.value !== null) {
          totalValue = v.value;
          break;
        }
      }
      
      if (totalValue !== null) {
        processed.push({ ou: ouId, value: totalValue });
      }
    }
    
    console.log(`[OUDATA-SMART] API returnerade ${processed.length} datapunkter`);
    
    // Spara i cache för framtida anrop
    if (processed.length > 0) {
      saveToCache(kpi, year, processed);
    }
    
    return { data: processed, fromApi: true };
  } catch (e) {
    console.log(`[OUDATA-SMART] API-fel: ${e}`);
    return null;
  }
}

// Spara till lokal cache
function saveToCache(kpi: string, year: number, data: Array<{ ou: string; value: number }>) {
  try {
    if (!oudataCache) {
      oudataCache = { syncedAt: new Date().toISOString(), kpis: {} };
    }
    
    if (!oudataCache.kpis[kpi]) {
      oudataCache.kpis[kpi] = { years: {} };
    }
    
    oudataCache.kpis[kpi].years[String(year)] = data;
    oudataCache.syncedAt = new Date().toISOString();
    
    const cachePath = path.join(process.cwd(), 'src', 'data', 'oudata-cache.json');
    fs.writeFileSync(cachePath, JSON.stringify(oudataCache, null, 2));
    console.log(`[OUDATA-SMART] Sparade ${data.length} poster till cache för ${kpi}/${year}`);
  } catch (e) {
    console.log(`[OUDATA-SMART] Kunde inte spara cache: ${e}`);
  }
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const kpi = searchParams.get('kpi');
  const year = searchParams.get('year');
  const type = searchParams.get('type');
  const municipalities = searchParams.get('municipalities');
  
  if (!kpi) {
    return NextResponse.json({ error: 'KPI parameter krävs' }, { status: 400 });
  }
  
  const yearNum = year ? parseInt(year) : 2023;
  const typePrefix = type ? OU_TYPE_PREFIX[type.toLowerCase()] : null;
  const munIds = municipalities ? municipalities.split(',') : null;
  
  // Steg 1: Kolla lokal cache
  let data: Array<{ ou: string; value: number }> = [];
  let source: 'local-cache' | 'api' | 'not-found' = 'not-found';
  let message = '';
  
  const cachedData = oudataCache?.kpis?.[kpi]?.years?.[String(yearNum)];
  
  if (cachedData && cachedData.length > 0) {
    data = cachedData;
    source = 'local-cache';
    message = `Hittade ${data.length} datapunkter i lokal cache`;
    console.log(`[OUDATA-SMART] ${message}`);
  } else {
    // Steg 2: Hämta från API
    message = `KPI ${kpi} år ${yearNum} saknas i cache, hämtar från API...`;
    console.log(`[OUDATA-SMART] ${message}`);
    
    try {
      // Timeout efter 30 sekunder
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);
      
      const apiResult = await fetchFromKoladaAPI(kpi, yearNum, controller.signal);
      clearTimeout(timeoutId);
      
      if (apiResult) {
        data = apiResult.data;
        source = 'api';
        message = `Hämtade ${data.length} datapunkter från Kolada API`;
      } else {
        message = `Kunde inte hämta data för ${kpi} år ${yearNum}`;
        source = 'not-found';
      }
    } catch (e) {
      const errMsg = e instanceof Error ? e.message : String(e);
      if (errMsg.includes('abort')) {
        message = `Timeout vid hämtning av ${kpi} - API:t svarar för långsamt`;
      } else {
        message = `Fel vid hämtning: ${errMsg}`;
      }
      console.log(`[OUDATA-SMART] ${message}`);
    }
  }
  
  // Steg 3: Filtrera på typ och kommuner
  let filteredData = data;
  
  if (typePrefix) {
    filteredData = filteredData.filter(item => item.ou.startsWith(typePrefix));
  }
  
  if (munIds && munIds.length > 0) {
    const munIdSet = new Set(munIds);
    
    filteredData = filteredData.filter(item => {
      const ouId = item.ou;
      
      // Använd snabb lookup
      if (ouToMunLookup[ouId]) {
        return munIdSet.has(ouToMunLookup[ouId]);
      }
      
      // Fallback för V15 (grundskolor) där kommun-ID är kodat i OU-ID
      if (ouId.length >= 8 && ouId.startsWith('V15')) {
        const possibleMunId = ouId.substring(4, 8).replace(/^0+/, '');
        return munIdSet.has(possibleMunId);
      }
      
      // Om vi inte kan matcha, exkludera (undvik falska positiva)
      return false;
    });
    
    console.log(`[OUDATA-SMART] Filtrerade på ${munIds.length} kommuner: ${filteredData.length} av ${data.length}`);
  }
  
  // Steg 4: Bygg resultat med namn och metadata
  const results = filteredData.map(item => ({
    ouId: item.ou,
    ouName: getOuName(item.ou),
    ouType: getOuType(item.ou),
    municipalityId: getMunIdFromOu(item.ou),
    value: item.value,
  }));
  
  // Sortera högst först
  results.sort((a, b) => b.value - a.value);
  
  return NextResponse.json({
    success: source !== 'not-found',
    source,
    message,
    kpi,
    year: yearNum,
    count: results.length,
    totalBeforeFilter: data.length,
    data: results,
  });
}
