import { NextRequest, NextResponse } from "next/server";
import { GoogleGenerativeAI } from "@google/generative-ai";
import * as fs from 'fs';
import * as path from 'path';

// Ladda KPI-index en gång vid start - BEGRÄNSAD för snabbare AI-svar
let kpiIndex: string | null = null;
let kpiIndexFull: string[] = [];

function getKpiIndex(query?: string): string {
  if (!kpiIndex) {
    try {
      const indexPath = path.join(process.cwd(), 'src/data/kpi-index.txt');
      const fullIndex = fs.readFileSync(indexPath, 'utf-8');
      kpiIndexFull = fullIndex.split('\n');
      console.log(`[ANALYZE] Laddade KPI-index: ${kpiIndexFull.length} rader`);
    } catch (e) {
      console.error('[ANALYZE] Kunde inte ladda kpi-index.txt:', e);
      kpiIndexFull = [];
    }
  }
  
  // Om vi har en fråga, filtrera KPIs baserat på relevanta nyckelord
  if (query && kpiIndexFull.length > 0) {
    const queryLower = query.toLowerCase();
    const keywords: string[] = [];
    
    // Extrahera nyckelord från frågan
    if (queryLower.includes('matte') || queryLower.includes('matematik')) keywords.push('matematik', 'matte');
    if (queryLower.includes('svenska')) keywords.push('svenska');
    if (queryLower.includes('engelska')) keywords.push('engelska');
    if (queryLower.includes('betyg')) keywords.push('betyg', 'meritvärd', 'poäng');
    if (queryLower.includes('skol')) keywords.push('skol', 'elev', 'lärare', 'grundskol', 'gymnasium');
    if (queryLower.includes('förskol')) keywords.push('förskol', 'barn');
    if (queryLower.includes('äldre') || queryLower.includes('boende')) keywords.push('äldre', 'boende', 'omsorg');
    if (queryLower.includes('hemtjänst')) keywords.push('hemtjänst');
    if (queryLower.includes('lss')) keywords.push('lss', 'funktions');
    if (queryLower.includes('skatt')) keywords.push('skatt');
    if (queryLower.includes('kostnad')) keywords.push('kostnad', 'kr/');
    if (queryLower.includes('befolkning') || queryLower.includes('invånare')) keywords.push('befolkning', 'invånare', 'folkmängd');
    
    // Lägg alltid till grundläggande relevanta termer
    keywords.push('N15', 'N17', 'N11', 'N23', 'N21'); // Vanliga OU-prefix
    
    if (keywords.length > 0) {
      const relevantLines = kpiIndexFull.filter(line => {
        const lineLower = line.toLowerCase();
        return keywords.some(kw => lineLower.includes(kw.toLowerCase()));
      });
      
      // Max 1500 rader för att hålla prompten hanterbar
      const limitedLines = relevantLines.slice(0, 1500);
      console.log(`[ANALYZE] Filtrerade till ${limitedLines.length} relevanta KPIs för: "${query.substring(0, 50)}..."`);
      return limitedLines.join('\n');
    }
  }
  
  // Fallback: returnera första 1500 raderna
  return kpiIndexFull.slice(0, 1500).join('\n');
}

// Giltiga modeller (uppdaterat för 2025)
const VALID_MODELS = [
  "gemini-2.5-flash",      // Rekommenderad - snabb och kraftfull
  "gemini-2.5-pro",        // Mest kraftfull
  "gemini-2.5-flash-lite", // Snabbast och billigast
  "gemini-2.0-flash",      // Äldre men stabil
  "gemini-1.5-pro",
  "gemini-1.5-flash",
];
const DEFAULT_MODEL = "gemini-2.5-flash";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { query, conversationHistory, apiKey, model: requestedModel = DEFAULT_MODEL } = body;

    // Validera modellen - fallback till default om ogiltig
    const model = VALID_MODELS.includes(requestedModel) ? requestedModel : DEFAULT_MODEL;

    // Använd server-side API-nyckel som fallback
    const effectiveApiKey = apiKey || process.env.GEMINI_API_KEY;
    const usingServerKey = !apiKey && !!process.env.GEMINI_API_KEY;
    
    console.log(`[ANALYZE] Request - Model: ${model} (requested: ${requestedModel}), Using server key: ${usingServerKey}`);
    
    if (!effectiveApiKey) {
      return NextResponse.json(
        { error: "API-nyckel saknas. Kontakta administratören." },
        { status: 400 }
      );
    }

    if (!query) {
      return NextResponse.json(
        { error: "Fråga krävs" },
        { status: 400 }
      );
    }

    const genAI = new GoogleGenerativeAI(effectiveApiKey);
    const geminiModel = genAI.getGenerativeModel({ 
      model,
      generationConfig: {
        maxOutputTokens: 2048,
      },
    });

    const currentYear = new Date().getFullYear();
    const kpiIndexContent = getKpiIndex(query);
    
    // Bygg konversationskontext om det finns tidigare meddelanden
    let conversationContext = "";
    if (conversationHistory && conversationHistory.length > 0) {
      conversationContext = `
=== TIDIGARE KONVERSATION ===
${conversationHistory.map((m: {role: string, content: string}) => 
  `${m.role === 'user' ? 'Användare' : 'AI'}: ${m.content.substring(0, 300)}${m.content.length > 300 ? '...' : ''}`
).join('\n')}

VIKTIGT: Om den nya frågan är en UPPFÖLJNING (t.ex. "och i Kumla?", "samma för Stockholm?"), 
använd SAMMA söktermer/KPI-typ som i föregående fråga, men byt kommun!
`;
    }

    // Extrahera år direkt från frågan med regex
    const yearMatches = query.match(/\b(19|20)\d{2}\b/g);
    const yearRangeMatch = query.match(/(\d{4})\s*[-–]\s*(\d{4})/);
    
    let detectedYears: number[] = [];
    if (yearRangeMatch) {
      const startYear = parseInt(yearRangeMatch[1]);
      const endYear = parseInt(yearRangeMatch[2]);
      for (let y = startYear; y <= endYear; y++) {
        detectedYears.push(y);
      }
    } else if (yearMatches) {
      detectedYears = yearMatches.map((y: string) => parseInt(y));
    }
    
    const yearsHint = detectedYears.length > 0 
      ? `Detekterade år: [${detectedYears.join(', ')}]`
      : `Inga år nämnda - använd [${currentYear-1}]`;

    // NY PROMPT: AI:n har tillgång till ALLA KPIs och väljer själv rätt KPI-IDs
    const analysisPrompt = `Du är expert på Kolada API och har tillgång till ALLA ${kpiIndexContent.split('\n').length} KPIs.

${conversationContext}
=== ANVÄNDARENS FRÅGA ===
"${query}"
${yearsHint}

═══════════════════════════════════════════════════════════════
KOMPLETT KPI-INDEX (sök igenom detta för att hitta rätt KPIs)
═══════════════════════════════════════════════════════════════
${kpiIndexContent}

═══════════════════════════════════════════════════════════════
DIN UPPGIFT
═══════════════════════════════════════════════════════════════

1. LÄS FRÅGAN och förstå vad användaren vill veta

2. SÖK I KPI-INDEXET ovan och hitta DE EXAKTA KPI-IDs som behövs
   - Välj 1-3 mest relevanta KPIs
   - Om beräkning behövs (t.ex. "antal" från "andel%"), inkludera BÅDE:
     * Huvud-KPI (t.ex. N02926 för andel utrikes födda)
     * Stöd-KPI (t.ex. N01951 för folkmängd)

3. IDENTIFIERA KOMMUNER/REGIONER
   VIKTIGT: Skilj på KOMMUN och REGION!
   - Om användaren säger "Region X" eller "X län" → returnera "Region X län" (t.ex. "Region Örebro län")
   - Om användaren säger bara kommunnamn → returnera kommunnamnet (t.ex. "Örebro")
   
   Exempel:
   - "skattesats för region örebro" → ["Region Örebro län"] (REGION, inte kommun!)
   - "befolkning i Örebro" → ["Örebro"] (kommun)
   - "alla kommuner i Örebro län" → lista kommunerna: ["Askersund", "Degerfors", ...]
   - Alla regioner: ["ALLA_REGIONER"]
   - Riksjämförelse/alla kommuner: ["ALLA_KOMMUNER"]
   - Ingen specifik: []

4. SKOLNIVÅ / ENHETSNIVÅ (OU-DATA)
   VIKTIGT: Många KPIs har data på ENHETSNIVÅ (enskilda skolor, förskolor, äldreboenden osv.)
   
   Enhetstyper och deras V-koder:
   - "grundskola" = V15 (Grundskola F-9)
   - "gymnasium" = V17 (Gymnasieskola)
   - "förskola" = V11 (Förskola)
   - "äldreboende" = V23 (Särskilt boende, äldre)
   - "hemtjänst" = V21 (Hemtjänst, äldre)
   - "lss_boende" = V25 (LSS boende med särskild service)
   - "lss_daglig" = V26 (LSS daglig verksamhet)
   - "gruppbostad" = V29 (Gruppbostad LSS)
   - "servicebostad" = V30 (Servicebostad LSS)
   - "sol_boende" = V32 (SoL Boende med särskild service)
   
   VANLIGA ENHETSFRÅGOR och rätt KPIs:
   - "Vilken skola har bäst betyg i matte?" → N15503 (betygspoäng matte)
   - "Vilken skola har högst meritvärde?" → N15504 (meritvärde åk 9)  
   - "Vilken skola har bäst svenska?" → N15502 (betygspoäng svenska)
   - "Vilken förskola har minst barn per personal?" → N11010/N11011 (barn per årsarbetare)
   - "Vilket äldreboende har nöjdast brukare?" → N23390/N23480 (brukarundersökning)
   - "Vilken hemtjänst är bäst?" → N21495/N21570 (brukarundersökning)
   - "Vilket gymnasium har högst examensgrad?" → N17448 (examen inom 3 år)
   
   Om användaren frågar om ENSKILDA enheter (skolor, förskolor, boenden):
   → ouLevel: true
   → ouType: rätt enhetstyp
   → kpiIds: relevanta KPIs från listan ovan

5. RETURNERA JSON med EXAKTA KPI-IDs (eller tom array för listningsfrågor!)

═══════════════════════════════════════════════════════════════
TIPS FÖR VANLIGA FRÅGOR
═══════════════════════════════════════════════════════════════
REGIONER - Administration/ledning:
- N60063 = Årsarbetare inom ledning, utveckling och stöd (bästa för "admin")
- N63013 = Verksamhetens kostnader region totalt
- Använd N60063/N01951 för admin per capita

KOMMUNER - Skola:
- N15013 = Kostnad måltider grundskola kr/elev
- N15033 = Elever per lärare

BEFOLKNING:
- N01951 = Folkmängd totalt
- N02926 = Andel utrikes födda

ÖREBRO LÄN har 12 kommuner:
Askersund, Degerfors, Hallsberg, Hällefors, Karlskoga, Kumla, Laxå, Lekeberg, Lindesberg, Ljusnarsberg, Nora, Örebro

ÅR: Använd ALLTID 2023 som standardår (2024 har sällan data ännu)

═══════════════════════════════════════════════════════════════
EXEMPEL
═══════════════════════════════════════════════════════════════

Fråga: "Hur många utrikes födda bor i Kumla?"
Svar: {
  "kpiIds": ["N02926", "N01951"],
  "municipalityNames": ["Kumla"],
  "years": [2023],
  "needsCalculation": true,
  "explanation": "N02926 ger andel%, N01951 ger folkmängd. Antal = andel × folkmängd / 100"
}

Fråga: "Vilken region har mest administration?" eller "administration per invånare"
Svar: {
  "kpiIds": ["N60063", "N01951"],
  "municipalityNames": ["ALLA_REGIONER"],
  "years": [2023],
  "needsCalculation": true,
  "explanation": "N60063 = årsarbetare ledning/stöd/admin, N01951 = befolkning. Beräkna per 1000 inv."
}

Fråga: "Kostnad för skolmat i Hallsberg?"
Svar: {
  "kpiIds": ["N15013"],
  "municipalityNames": ["Hallsberg"],
  "years": [2023],
  "needsCalculation": false,
  "explanation": "N15013 = Kostnad måltider grundskola kr/elev"
}

Fråga: "Vilken kommun har lägst skatt?"
Svar: {
  "kpiIds": ["N00900"],
  "municipalityNames": ["ALLA_KOMMUNER"],
  "years": [2024],
  "needsCalculation": false,
  "explanation": "N00900 = Total kommunalskatt. Rankas från lägst till högst."
}

Fråga: "Vilken skola i Örebro har bäst betyg?" (DATA FÖR ENHETER)
Svar: {
  "intent": "get_unit_data",
  "kpiIds": ["N15504"],
  "municipalityNames": ["Örebro"],
  "years": [2023],
  "ouLevel": true,
  "ouType": "grundskola",
  "needsCalculation": false,
  "explanation": "N15504 = meritvärde åk 9. ouLevel=true för att hämta skolnivådata."
}

Fråga: "Vilken skola i Örebro län har bäst matteresultat?"
Svar: {
  "intent": "get_unit_data",
  "kpiIds": ["N15503"],
  "municipalityNames": ["Askersund", "Degerfors", "Hallsberg", "Hällefors", "Karlskoga", "Kumla", "Laxå", "Lekeberg", "Lindesberg", "Ljusnarsberg", "Nora", "Örebro"],
  "years": [2024],
  "ouLevel": true,
  "ouType": "grundskola",
  "needsCalculation": false,
  "explanation": "N15503 = betygspoäng i matematik åk 9. Söker alla kommuner i Örebro län."
}

Fråga: "Vilket äldreboende i Kumla har nöjdast boende?"
Svar: {
  "intent": "get_unit_data",
  "kpiIds": ["N23390", "N23480"],
  "municipalityNames": ["Kumla"],
  "years": [2024],
  "ouLevel": true,
  "ouType": "äldreboende",
  "needsCalculation": false,
  "explanation": "N23390/N23480 = brukarundersökning särskilt boende. ouType=äldreboende för V23-enheter."
}

Fråga: "Vilken hemtjänst i Stockholm är bäst?"
Svar: {
  "intent": "get_unit_data",
  "kpiIds": ["N21495", "N21570"],
  "municipalityNames": ["Stockholm"],
  "years": [2024],
  "ouLevel": true,
  "ouType": "hemtjänst",
  "needsCalculation": false,
  "explanation": "N21495/N21570 = brukarundersökning hemtjänst. ouType=hemtjänst för V21-enheter."
}

Fråga: "Vilken förskola i Malmö har minst barn per personal?"
Svar: {
  "intent": "get_unit_data",
  "kpiIds": ["N11010", "N11102"],
  "municipalityNames": ["Malmö"],
  "years": [2024],
  "ouLevel": true,
  "ouType": "förskola",
  "needsCalculation": false,
  "explanation": "N11010/N11102 = barn per årsarbetare i förskola. Lägst värde = bäst."
}

Fråga: "Vilka kommuner i Sverige har flest lediga bostäder per invånare?"
Svar: {
  "intent": "get_municipality_data",
  "kpiIds": ["N07913", "N01951", "N02938"],
  "municipalityNames": ["ALLA_KOMMUNER"],
  "years": [2023],
  "ouLevel": false,
  "ouType": null,
  "needsCalculation": true,
  "explanation": "Beräkning: Lediga bostäder ≈ (N07913/1000 × N01951) - N02938. Behöver alla kommuner för ranking."
}

Fråga: "Vilken kommun har högst skattesats?"
Svar: {
  "intent": "get_municipality_data",
  "kpiIds": ["N00900"],
  "municipalityNames": ["ALLA_KOMMUNER"],
  "years": [2024],
  "ouLevel": false,
  "ouType": null,
  "needsCalculation": false,
  "explanation": "N00900 = Kommunalskattesats. Hämtar för alla kommuner för att hitta högsta."
}

Fråga: "Ja, hämta den datan" eller "Gör det" eller "Ja"
Svar: {
  "intent": "confirm_fetch",
  "kpiIds": [],
  "municipalityNames": [],
  "years": [],
  "ouLevel": false,
  "ouType": null,
  "needsCalculation": false,
  "explanation": "Användaren bekräftar att systemet ska hämta data enligt tidigare diskussion."
}

Fråga: "Hur många skolor finns i Kumla?"
Svar: {
  "intent": "list_units",
  "kpiIds": [],
  "municipalityNames": ["Kumla"],
  "years": [],
  "ouLevel": true,
  "ouType": "all",
  "needsCalculation": false,
  "explanation": "Listningsfråga - räknar bara enheter, ingen KPI-data behövs."
}

═══════════════════════════════════════════════════════════════
JSON-FORMAT (returnera ENDAST detta)
═══════════════════════════════════════════════════════════════
{
  "intent": "list_units" | "get_unit_data" | "get_municipality_data",
  "kpiIds": ["N12345"] | [],
  "municipalityNames": ["Kommun1"] | ["ALLA_REGIONER"] | ["ALLA_KOMMUNER"] | [],
  "years": [${detectedYears.length > 0 ? detectedYears.join(', ') : '2023'}] | [],
  "needsCalculation": true/false,
  "ouLevel": true/false,
  "ouType": "grundskola" | "gymnasium" | "förskola" | "all" | null,
  "explanation": "Kort förklaring"
}

RETURNERA ENDAST VALID JSON:`;

    console.log(`[ANALYZE] Skickar prompt till Gemini (${analysisPrompt.length} tecken)...`);
    
    // Retry-logik för Gemini API (hanterar tillfälliga 503-fel)
    let text = "";
    let lastError: Error | null = null;
    const MAX_RETRIES = 3;
    
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        const result = await geminiModel.generateContent(analysisPrompt);
        const response = await result.response;
        text = response.text() || "";
        lastError = null;
        break; // Lyckades!
      } catch (retryError) {
        lastError = retryError instanceof Error ? retryError : new Error(String(retryError));
        console.error(`[ANALYZE] Gemini-fel (försök ${attempt}/${MAX_RETRIES}):`, lastError.message);
        
        // Vänta innan retry (exponentiell backoff)
        if (attempt < MAX_RETRIES) {
          const waitMs = 1000 * Math.pow(2, attempt - 1); // 1s, 2s, 4s
          console.log(`[ANALYZE] Väntar ${waitMs}ms innan retry...`);
          await new Promise(resolve => setTimeout(resolve, waitMs));
        }
      }
    }
    
    // Om alla retries misslyckades
    if (lastError) {
      throw lastError;
    }
    
    console.log(`[ANALYZE] Gemini svarade med ${text.length} tecken`);
    
    // Extract JSON from response
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      try {
        const analysis = JSON.parse(jsonMatch[0]);
        console.log(`[ANALYZE] Parsed analysis:`, JSON.stringify(analysis).substring(0, 200));
        return NextResponse.json({ analysis });
      } catch (parseError) {
        console.error('[ANALYZE] JSON parse error:', parseError);
        console.error('[ANALYZE] Raw text:', text.substring(0, 500));
      }
    }

    console.log('[ANALYZE] Kunde inte hitta JSON i svaret');
    return NextResponse.json({
      analysis: {
        intent: "unknown",
        kpiSearchTerms: [],
        municipalityNames: [],
        years: [],
        explanation: "Kunde inte tolka frågan",
        suggestedActions: ["Försök omformulera din fråga"],
      },
    });
  } catch (error: unknown) {
    console.error("[ANALYZE] API error:", error);
    
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    
    if (errorMessage.includes("API_KEY") || errorMessage.includes("401")) {
      return NextResponse.json(
        { error: "Ogiltig API-nyckel" },
        { status: 401 }
      );
    }
    
    // Model not found
    if (errorMessage.includes("not found") || errorMessage.includes("404") || errorMessage.includes("models/")) {
      console.error("[ANALYZE] Model error, trying fallback");
      return NextResponse.json(
        { error: "AI-modellen kunde inte nås. Försök igen om en stund." },
        { status: 503 }
      );
    }
    
    // Network/timeout errors
    if (errorMessage.includes("timeout") || errorMessage.includes("ETIMEDOUT") || 
        errorMessage.includes("fetch") || errorMessage.includes("network") ||
        errorMessage.includes("ECONNRESET") || errorMessage.includes("socket")) {
      return NextResponse.json(
        { error: "Nätverksfel vid AI-analys. Kontrollera din internetanslutning och försök igen." },
        { status: 504 }
      );
    }

    return NextResponse.json(
      { error: `Analysfel: ${errorMessage.substring(0, 100)}` },
      { status: 500 }
    );
  }
}
