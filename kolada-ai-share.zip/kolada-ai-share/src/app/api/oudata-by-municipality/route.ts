import { NextRequest, NextResponse } from "next/server";
import { koladaFetch, fetchOUs, fetchOUData, getApiStatusForFrontend } from "@/lib/kolada-client";

/**
 * API-route för att hämta OU-data (skolnivå) direkt per kommun från Kolada
 * 
 * OPTIMERAD VERSION:
 * - Använder centraliserad API-klient med rate limiting
 * - SEKVENTIELLA anrop (inte parallella) för att undvika rate limiting
 * - In-memory cache för OU-namn (1 timme TTL)
 * 
 * GET /api/oudata-by-municipality?kpi=N15504&municipality=1880&year=2024
 * GET /api/oudata-by-municipality?kpi=N15504&municipalities=1880,1881&year=2024&type=grundskola
 */

// Cache för OU-namn
const ouNameCache: Map<string, { data: { [ouId: string]: string }; timestamp: number }> = new Map();
const CACHE_TTL = 60 * 60 * 1000; // 1 timme

// Hämta OU-namn för en kommun (med cache)
async function getOUNames(munId: string): Promise<{ names: { [ouId: string]: string }; blocked: boolean }> {
  const cached = ouNameCache.get(munId);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return { names: cached.data, blocked: false };
  }
  
  const result = await fetchOUs(munId);
  
  if (result.blocked) {
    return { names: {}, blocked: true };
  }
  
  if (!result.data) return { names: {}, blocked: false };
  
  const lookup: { [ouId: string]: string } = {};
  for (const ou of result.data) {
    lookup[ou.id] = ou.title;
  }
  
  ouNameCache.set(munId, { data: lookup, timestamp: Date.now() });
  return { names: lookup, blocked: false };
}

// Hämta oudata för en kommun
async function fetchOUDataForMunicipality(
  kpi: string, 
  munId: string, 
  year: number,
  idPrefix: string | null
): Promise<{ 
  data: Array<{ ouId: string; municipalityId: string; kpi: string; year: number; value: number }>;
  blocked: boolean;
  error: string | null;
}> {
  const result = await fetchOUData(kpi, year, munId);
  
  if (result.blocked) {
    return { data: [], blocked: true, error: result.error };
  }
  
  if (!result.data) {
    return { data: [], blocked: false, error: result.error };
  }
  
  const results: Array<{ ouId: string; municipalityId: string; kpi: string; year: number; value: number }> = [];
  
  for (const item of result.data) {
    const ouId = item.ou;
    
    // Filtrera på typ (ID-prefix)
    if (idPrefix && !ouId.startsWith(idPrefix)) continue;
    
    // Hitta total-värdet (gender = 'T')
    const totalValue = item.values?.find((v: { gender: string }) => v.gender === 'T');
    
    if (totalValue?.value !== null && totalValue?.value !== undefined) {
      results.push({
        ouId,
        municipalityId: munId,
        kpi: kpi,
        year: item.period,
        value: totalValue.value
      });
    }
  }
  
  return { data: results, blocked: false, error: null };
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const kpi = searchParams.get('kpi');
  const municipality = searchParams.get('municipality');
  const municipalities = searchParams.get('municipalities');
  const year = searchParams.get('year');
  const type = searchParams.get('type');

  if (!kpi) return NextResponse.json({ error: "kpi parameter krävs" }, { status: 400 });
  if (!municipality && !municipalities) return NextResponse.json({ error: "municipality eller municipalities parameter krävs" }, { status: 400 });
  if (!year) return NextResponse.json({ error: "year parameter krävs" }, { status: 400 });

  const typePrefix: { [key: string]: string } = {
    'grundskola': 'V15',
    'gymnasium': 'V17',
    'förskola': 'V11',
    'hemtjänst': 'V21',
    'äldreboende': 'V23',
  };

  const idPrefix = type ? typePrefix[type] : null;
  const munIds = municipalities ? municipalities.split(',') : [municipality!];

  try {
    const yearNum = parseInt(year);
    console.log(`[OUDATA-BY-MUN] Hämtar ${kpi} för ${munIds.length} kommuner SEKVENTIELLT (rate limited)`);
    
    // SEKVENTIELLA ANROP för att respektera rate limiting
    const allResults: Array<{
      ouId: string;
      ouName: string | null;
      municipalityId: string;
      kpi: string;
      year: number;
      value: number | null;
      gender: string;
    }> = [];
    
    const ouNameLookup: { [ouId: string]: string } = {};
    let isBlocked = false;
    let blockError: string | null = null;
    
    for (const munId of munIds) {
      // Kolla om vi är blockerade
      if (isBlocked) break;
      
      // Hämta oudata för denna kommun
      const dataResult = await fetchOUDataForMunicipality(kpi, munId, yearNum, idPrefix);
      
      if (dataResult.blocked) {
        isBlocked = true;
        blockError = dataResult.error;
        break;
      }
      
      // Hämta OU-namn
      const nameResult = await getOUNames(munId);
      
      if (nameResult.blocked) {
        isBlocked = true;
        blockError = 'API blockerat vid hämtning av enhetsnamn';
        break;
      }
      
      Object.assign(ouNameLookup, nameResult.names);
      
      // Lägg till resultat
      for (const item of dataResult.data) {
        allResults.push({
          ...item,
          ouName: ouNameLookup[item.ouId] || null,
          gender: 'T'
        });
      }
      
      console.log(`[OUDATA-BY-MUN] ${munId}: ${dataResult.data.length} datapunkter`);
    }
    
    // Om blockerad, returnera felmeddelande
    if (isBlocked) {
      const status = getApiStatusForFrontend();
      return NextResponse.json({
        count: allResults.length,
        kpi,
        year: yearNum,
        type: type || 'all',
        data: allResults,
        blocked: true,
        blockMessage: blockError || status.message,
        waitSeconds: status.waitSeconds
      });
    }

    // Sortera på värde
    const sortedResults = allResults
      .filter(r => r.value !== null)
      .sort((a, b) => (b.value || 0) - (a.value || 0));

    console.log(`[OUDATA-BY-MUN] Totalt ${sortedResults.length} resultat`);

    return NextResponse.json({
      count: sortedResults.length,
      kpi,
      year: yearNum,
      type: type || 'all',
      data: sortedResults,
      blocked: false
    });

  } catch (error) {
    console.error('[OUDATA-BY-MUN] Fel:', error);
    return NextResponse.json(
      { error: "Kunde inte hämta OU-data", details: String(error) },
      { status: 500 }
    );
  }
}
