import { NextRequest, NextResponse } from "next/server";
import { log, getLogs, clearLogs } from "@/lib/logger";

/**
 * API för loggning från klientsidan
 * POST /api/log - Lägg till logg
 * GET /api/log - Hämta alla loggar
 * DELETE /api/log - Rensa loggar
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { level, category, message, data } = body;
    
    log(level || 'INFO', category || 'CLIENT', message || 'No message', data);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'Invalid log entry' }, { status: 400 });
  }
}

export async function GET() {
  const logs = getLogs();
  return NextResponse.json({
    count: logs.length,
    logs,
  });
}

export async function DELETE() {
  clearLogs();
  return NextResponse.json({ message: "Loggar rensade" });
}
