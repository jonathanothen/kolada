import { NextRequest, NextResponse } from "next/server";
import { getLogs, clearLogs } from "@/lib/logger";

/**
 * API för att visa och rensa loggar
 * GET /api/logs - Hämta alla loggar
 * DELETE /api/logs - Rensa loggar
 */
export async function GET() {
  const logs = getLogs();
  return NextResponse.json({
    count: logs.length,
    logs,
  });
}

export async function DELETE() {
  clearLogs();
  return NextResponse.json({ message: "Loggar rensade" });
}
