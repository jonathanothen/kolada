import { NextRequest, NextResponse } from "next/server";
import { getApiStatusForFrontend, resetApiStatus } from "@/lib/kolada-client";

/**
 * API-endpoint för att kolla Kolada API-status
 * GET - Hämta status
 * POST - Återställ status (efter IP-byte)
 */

export async function GET() {
  const status = getApiStatusForFrontend();
  return NextResponse.json(status);
}

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({}));
  
  if (body.action === 'reset') {
    resetApiStatus();
    return NextResponse.json({ success: true, message: 'API-status återställd' });
  }
  
  return NextResponse.json({ error: 'Ogiltig action' }, { status: 400 });
}
