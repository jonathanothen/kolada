"use client";

import { useState, useEffect } from "react";
import { AnimatePresence } from "framer-motion";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import MobileNav from "@/components/MobileNav";
import ChatInterface from "@/components/ChatInterface";
import SettingsPanel from "@/components/SettingsPanel";
import LogViewer from "@/components/LogViewer";

export default function Home() {
  const [apiKey, setApiKey] = useState("");
  const [model, setModel] = useState("gemini-2.5-flash");
  const [activeTab, setActiveTab] = useState("chat");
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [chatKey, setChatKey] = useState(0); // För att starta ny konversation

  const handleNewChat = () => {
    // Rensa localStorage och tvinga ny ChatInterface
    if (typeof window !== 'undefined') {
      localStorage.removeItem('kolada-ai-chat-history');
    }
    setChatKey(prev => prev + 1);
  };

  // Load settings from localStorage on mount
  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedApiKey = localStorage.getItem("kolada-ai-api-key");
      const savedModel = localStorage.getItem("kolada-ai-model");
      if (savedApiKey) setApiKey(savedApiKey);
      if (savedModel) setModel(savedModel);
    }
  }, []);

  // Mark as visited on first visit (no longer auto-opens settings)
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("kolada-ai-visited", "true");
    }
  }, []);

  return (
    <div className="h-screen flex flex-col bg-slate-950">
      <Header
        onSettingsClick={() => setIsSettingsOpen(true)}
        hasApiKey={!!apiKey}
        onMenuClick={() => setIsMobileMenuOpen(true)}
      />

      {/* Mobile Navigation */}
      <MobileNav
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onNewChat={handleNewChat}
      />

      <div className="flex-1 flex overflow-hidden">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onNewChat={handleNewChat} />

        <main className="flex-1 flex flex-col overflow-hidden">
          {activeTab === "chat" && (
            <ChatInterface key={chatKey} apiKey={apiKey} model={model} />
          )}

          {activeTab === "search" && (
            <div className="flex-1 flex items-center justify-center text-slate-400">
              <div className="text-center">
                <p className="text-lg mb-2">Sök KPIs</p>
                <p className="text-sm">Använd chatten för att söka och utforska data</p>
              </div>
            </div>
          )}

          {activeTab === "municipalities" && (
            <div className="flex-1 flex items-center justify-center text-slate-400">
              <div className="text-center">
                <p className="text-lg mb-2">Kommuner</p>
                <p className="text-sm">290 svenska kommuner tillgängliga</p>
              </div>
            </div>
          )}

          {activeTab === "data" && (
            <div className="flex-1 flex items-center justify-center text-slate-400">
              <div className="text-center">
                <p className="text-lg mb-2">Utforska Data</p>
                <p className="text-sm">Fråga AI:n om specifik statistik</p>
              </div>
            </div>
          )}

          {activeTab === "logs" && (
            <LogViewer />
          )}

          {activeTab === "docs" && (
            <div className="flex-1 overflow-y-auto p-4 sm:p-6">
              <div className="max-w-3xl mx-auto">
                <h2 className="text-xl sm:text-2xl font-bold text-white mb-4">Dokumentation</h2>
                
                <div className="space-y-6 text-slate-300">
                  <section>
                    <h3 className="text-lg font-semibold text-white mb-2">Om Kolada</h3>
                    <p>
                      Kolada är en öppen databas med nyckeltal för svenska kommuner och regioner.
                      Databasen förvaltas av RKA (Rådet för kommunal analys) i samarbete med 
                      Sveriges Kommuner och Regioner (SKR).
                    </p>
                  </section>

                  <section>
                    <h3 className="text-lg font-semibold text-white mb-2">Hur du använder appen</h3>
                    <ol className="list-decimal list-inside space-y-2">
                      <li>Lägg till din Google Gemini API-nyckel i inställningarna</li>
                      <li>Ställ frågor på naturligt språk i chatten</li>
                      <li>AI:n tolkar din fråga och hämtar relevant data från Kolada</li>
                      <li>Resultaten presenteras och analyseras av AI:n</li>
                    </ol>
                  </section>

                  <section>
                    <h3 className="text-lg font-semibold text-white mb-2">Exempelfrågor</h3>
                    <ul className="list-disc list-inside space-y-2">
                      <li>Hur ser skolresultaten ut i Stockholm kommun?</li>
                      <li>Jämför personaltäthet i äldreomsorgen mellan Malmö och Göteborg</li>
                      <li>Vilka kommuner har högst lärartäthet i förskolan?</li>
                      <li>Visa kostnader för hemtjänst per invånare 2023</li>
                    </ul>
                  </section>


                  <section>
                    <h3 className="text-lg font-semibold text-white mb-2">Datakällor</h3>
                    <p>
                      All statistik hämtas direkt från{" "}
                      <a 
                        href="https://kolada.se" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-400 hover:underline"
                      >
                        Kolada.se
                      </a>{" "}
                      via deras öppna API (v3). Data uppdateras kontinuerligt av RKA.
                    </p>
                  </section>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-900/50 py-2 px-4">
        <p className="text-xs text-slate-500 text-center">
          Utvecklad av <span className="text-slate-400">Jonas Millard</span> • Data från <a href="https://kolada.se" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">Kolada</a>
        </p>
      </footer>

      <AnimatePresence>
        {isSettingsOpen && (
          <SettingsPanel
            apiKey={apiKey}
            setApiKey={setApiKey}
            model={model}
            setModel={setModel}
            isOpen={isSettingsOpen}
            onClose={() => setIsSettingsOpen(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
