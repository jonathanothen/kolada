/**
 * Vanliga KPIs kategoriserade för snabb referens.
 * Dessa inkluderas i AI:ns kontext för direkt mappning från användarfrågor.
 */

export interface CommonKPI {
  id: string;
  title: string;
  shortDesc: string;
  keywords: string[]; // Ord som matchar denna KPI
}

export const COMMON_KPIS: { [category: string]: CommonKPI[] } = {
  "Skolmat & Måltider": [
    {
      id: "N15013",
      title: "Kostnad för måltider i kommunal grundskola åk 1-9, kr/elev",
      shortDesc: "Skolmatskostnad per elev i grundskolan",
      keywords: ["skolmat", "skolmaten", "lunch", "mat", "måltid", "portion", "grundskola"]
    },
    {
      id: "N17012", 
      title: "Kostnad för måltider i kommunal gymnasieskola, kr/elev",
      shortDesc: "Skolmatskostnad per elev i gymnasiet",
      keywords: ["skolmat", "lunch", "måltid", "gymnasium", "gymnasiet"]
    },
    {
      id: "N18030",
      title: "Kostnad för måltider i kommunal anpassad grundskola, kr/elev",
      shortDesc: "Skolmatskostnad i anpassad grundskola (särskola)",
      keywords: ["skolmat", "anpassad", "särskola", "måltid"]
    }
  ],
  
  "Skola - Kostnader": [
    {
      id: "N15008",
      title: "Kostnad för kommunal grundskola åk 1-9, kr/elev",
      shortDesc: "Total kostnad per elev i grundskolan",
      keywords: ["kostnad", "grundskola", "elev", "skola"]
    },
    {
      id: "N15060",
      title: "Kostnad kommunal grundskola F-9, kr/elev", 
      shortDesc: "Total kostnad grundskola inkl. förskoleklass",
      keywords: ["kostnad", "grundskola", "förskoleklass"]
    }
  ],
  
  "Skola - Lärare & Personal": [
    {
      id: "N15033",
      title: "Antal elever per lärare i kommunal grundskola åk 1-9",
      shortDesc: "Lärartäthet - antal elever per lärare",
      keywords: ["lärare", "lärartäthet", "elever per lärare", "personal"]
    },
    {
      id: "N10601",
      title: "Barn per årsarbetare i kommunal förskola",
      shortDesc: "Personaltäthet i förskolan",
      keywords: ["förskola", "personal", "barn", "årsarbetare", "täthet"]
    }
  ],
  
  "Skola - Resultat": [
    {
      id: "N15428",
      title: "Meritvärde årskurs 9, kommunala skolor, genomsnitt",
      shortDesc: "Genomsnittligt meritvärde i åk 9",
      keywords: ["meritvärde", "betyg", "resultat", "årskurs 9"]
    },
    {
      id: "N15403",
      title: "Elever i åk 9 som är behöriga till gymnasiet, (%)",
      shortDesc: "Andel behöriga till gymnasiet",
      keywords: ["behörig", "gymnasium", "gymnasiet", "behörighet"]
    }
  ],
  
  "Befolkning": [
    {
      id: "N01951",
      title: "Folkmängd totalt",
      shortDesc: "Antal invånare",
      keywords: ["befolkning", "invånare", "folkmängd", "population"]
    },
    {
      id: "N01963",
      title: "Befolkningsförändring, (%)",
      shortDesc: "Årlig befolkningsförändring",
      keywords: ["befolkning", "förändring", "ökning", "minskning"]
    }
  ],
  
  "Skatt & Ekonomi": [
    {
      id: "N00900",
      title: "Kommunal skattesats totalt",
      shortDesc: "Total kommunalskatt (kommun + region)",
      keywords: ["skatt", "skattesats", "kommunalskatt"]
    },
    {
      id: "N00901",
      title: "Kommunal skattesats, endast kommunen",
      shortDesc: "Kommunens del av skatten",
      keywords: ["skatt", "kommun", "skattesats"]
    }
  ],
  
  "Äldreomsorg": [
    {
      id: "N28013",
      title: "Nettokostnad äldreomsorg, kr/inv 65+ år",
      shortDesc: "Kostnad för äldreomsorg per äldre invånare",
      keywords: ["äldreomsorg", "äldre", "kostnad", "omsorg"]
    },
    {
      id: "U21496",
      title: "Andel brukare som är nöjda med sitt äldreboende",
      shortDesc: "Nöjdhet på äldreboende",
      keywords: ["äldreboende", "nöjd", "nöjdhet", "brukare"]
    }
  ]
};

/**
 * Genererar en kompakt KPI-referens för AI:ns systemkontext
 */
export function generateKPIReference(): string {
  let ref = "=== VANLIGA KPIs (snabbreferens) ===\n";
  ref += "Använd dessa KPI-IDs för vanliga frågor:\n\n";
  
  for (const [category, kpis] of Object.entries(COMMON_KPIS)) {
    ref += `${category}:\n`;
    for (const kpi of kpis) {
      ref += `  • ${kpi.id}: ${kpi.shortDesc}\n`;
      ref += `    Nyckelord: ${kpi.keywords.slice(0, 4).join(", ")}\n`;
    }
    ref += "\n";
  }
  
  return ref;
}

/**
 * Hittar relevanta KPIs baserat på frågan
 */
export function findRelevantKPIs(query: string): CommonKPI[] {
  const lowerQuery = query.toLowerCase();
  const matches: { kpi: CommonKPI; score: number }[] = [];
  
  for (const kpis of Object.values(COMMON_KPIS)) {
    for (const kpi of kpis) {
      let score = 0;
      for (const keyword of kpi.keywords) {
        if (lowerQuery.includes(keyword)) {
          score += 10;
        }
      }
      if (score > 0) {
        matches.push({ kpi, score });
      }
    }
  }
  
  return matches
    .sort((a, b) => b.score - a.score)
    .map(m => m.kpi);
}
