/**
 * Enkel loggningsmodul för att spåra API-anrop och AI-beslut.
 * Loggar sparas i minnet och kan hämtas via /api/logs
 */

interface LogEntry {
  timestamp: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';
  category: string;
  message: string;
  data?: unknown;
}

// Använd globalThis för att överleva Next.js hot reload
const globalForLogs = globalThis as unknown as { logs: LogEntry[] };

if (!globalForLogs.logs) {
  globalForLogs.logs = [];
}

const logs = globalForLogs.logs;
const MAX_LOGS = 500;

export function log(level: LogEntry['level'], category: string, message: string, data?: unknown) {
  const entry: LogEntry = {
    timestamp: new Date().toISOString(),
    level,
    category,
    message,
    data,
  };
  
  logs.push(entry);
  
  // Begränsa storleken
  if (logs.length > MAX_LOGS) {
    logs.shift();
  }
  
  // Logga även till konsolen för utveckling
  const prefix = `[${entry.timestamp.substring(11, 19)}] [${level}] [${category}]`;
  if (level === 'ERROR') {
    console.error(prefix, message, data || '');
  } else if (level === 'WARN') {
    console.warn(prefix, message, data || '');
  } else {
    console.log(prefix, message, data || '');
  }
}

export function info(category: string, message: string, data?: unknown) {
  log('INFO', category, message, data);
}

export function warn(category: string, message: string, data?: unknown) {
  log('WARN', category, message, data);
}

export function error(category: string, message: string, data?: unknown) {
  log('ERROR', category, message, data);
}

export function debug(category: string, message: string, data?: unknown) {
  log('DEBUG', category, message, data);
}

export function getLogs(): LogEntry[] {
  return [...logs];
}

export function clearLogs() {
  logs.length = 0;
  info('LOGGER', 'Loggar rensade');
}

export function getLogsSince(since: string): LogEntry[] {
  return logs.filter(l => l.timestamp > since);
}
