/**
 * Enkel in-memory cache för Kolada-data
 * Cachar data per KPI+kommun+år för att undvika upprepade API-anrop
 */

interface CacheEntry {
  value: number | null;
  timestamp: number;
}

// Cache-struktur: kpiId -> munId -> year -> value
const dataCache: Map<string, Map<string, Map<number, CacheEntry>>> = new Map();

// Cache TTL: 1 timme
const CACHE_TTL = 60 * 60 * 1000;

/**
 * Skapa cache-nyckel
 */
function getCacheKey(kpiId: string, munId: string, year: number): { kpi: string; mun: string; year: number } {
  return { kpi: kpiId, mun: munId, year };
}

/**
 * Hämta värde från cache
 */
export function getCached(kpiId: string, munId: string, year: number): number | null | undefined {
  const kpiCache = dataCache.get(kpiId);
  if (!kpiCache) return undefined;
  
  const munCache = kpiCache.get(munId);
  if (!munCache) return undefined;
  
  const entry = munCache.get(year);
  if (!entry) return undefined;
  
  // Kolla om cache har gått ut
  if (Date.now() - entry.timestamp > CACHE_TTL) {
    munCache.delete(year);
    return undefined;
  }
  
  return entry.value;
}

/**
 * Spara värde i cache
 */
export function setCache(kpiId: string, munId: string, year: number, value: number | null): void {
  if (!dataCache.has(kpiId)) {
    dataCache.set(kpiId, new Map());
  }
  
  const kpiCache = dataCache.get(kpiId)!;
  if (!kpiCache.has(munId)) {
    kpiCache.set(munId, new Map());
  }
  
  const munCache = kpiCache.get(munId)!;
  munCache.set(year, { value, timestamp: Date.now() });
}

/**
 * Spara flera värden i cache på en gång
 */
export function setCacheBatch(entries: { kpiId: string; munId: string; year: number; value: number | null }[]): void {
  for (const entry of entries) {
    setCache(entry.kpiId, entry.munId, entry.year, entry.value);
  }
}

/**
 * Hämta cache-statistik
 */
export function getCacheStats(): { kpis: number; entries: number } {
  let entries = 0;
  Array.from(dataCache.values()).forEach(kpiCache => {
    Array.from(kpiCache.values()).forEach(munCache => {
      entries += munCache.size;
    });
  });
  return { kpis: dataCache.size, entries };
}

/**
 * Rensa cache
 */
export function clearCache(): void {
  dataCache.clear();
}

/**
 * Rensa gamla cache-poster
 */
export function pruneCache(): number {
  let pruned = 0;
  const now = Date.now();
  
  Array.from(dataCache.entries()).forEach(([kpiId, kpiCache]) => {
    Array.from(kpiCache.entries()).forEach(([munId, munCache]) => {
      Array.from(munCache.entries()).forEach(([year, entry]) => {
        if (now - entry.timestamp > CACHE_TTL) {
          munCache.delete(year);
          pruned++;
        }
      });
      if (munCache.size === 0) {
        kpiCache.delete(munId);
      }
    });
    if (kpiCache.size === 0) {
      dataCache.delete(kpiId);
    }
  });
  
  return pruned;
}

// KPI:er som saknar äldre data (börjar runt 2019-2020)
export const KPIS_WITHOUT_OLD_DATA: { [kpiId: string]: number } = {
  'N02251': 2019, // Egenföretagare bostad
  'N02252': 2019, // Egenföretagare arbetsställe
};

// Alternativa KPI:er när primära saknar data
export const ALTERNATIVE_KPIS: { [kpiId: string]: { altId: string; note: string }[] } = {
  'N02251': [
    { altId: 'N00999', note: 'Nystartade företag per 1000 inv (har data från 2000)' },
  ],
  'N02252': [
    { altId: 'N00999', note: 'Nystartade företag per 1000 inv (har data från 2000)' },
  ],
};
