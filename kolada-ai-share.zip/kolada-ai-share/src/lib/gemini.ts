// Google Gemini AI Types and Constants
// API calls are handled in the API routes

export interface AIQueryResult {
  intent: "search_kpi" | "search_municipality" | "get_data" | "compare" | "help" | "unknown";
  kpiSearchTerms?: string[];
  municipalitySearchTerms?: string[];
  years?: number[];
  explanation: string;
  suggestedActions: string[];
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  data?: unknown;
}

export const AVAILABLE_MODELS = [
  { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash", description: "Snabb och kraftfull - rekommenderad" },
  { id: "gemini-2.5-pro", name: "Gemini 2.5 Pro", description: "Mest kraftfull för komplex analys" },
  { id: "gemini-2.5-flash-lite", name: "Gemini 2.5 Flash Lite", description: "Snabbast och billigast" },
  { id: "gemini-2.0-flash", name: "Gemini 2.0 Flash", description: "Äldre stabil version" },
] as const;

export type ModelId = typeof AVAILABLE_MODELS[number]["id"];
