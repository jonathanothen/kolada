/**
 * Centraliserad Kolada API-klient med rate limiting och felhantering
 * 
 * Funktioner:
 * - Global rate limiting (max 2 anrop/sekund)
 * - Automatisk retry med exponentiell backoff
 * - Detektering av API-blockering (429, timeouts)
 * - Status-tracking för feedback till användaren
 */

const KOLADA_BASE = 'https://api.kolada.se/v3';

// Rate limiting konfiguration
const RATE_LIMIT = {
  maxRequestsPerSecond: 2,
  minDelayMs: 500, // Minst 500ms mellan anrop
  maxRetries: 3,
  baseTimeoutMs: 30000,
  maxTimeoutMs: 60000,
};

// Global status för API:t
interface ApiStatus {
  isBlocked: boolean;
  blockedUntil: number | null;
  lastError: string | null;
  consecutiveErrors: number;
  totalRequests: number;
  failedRequests: number;
}

let apiStatus: ApiStatus = {
  isBlocked: false,
  blockedUntil: null,
  lastError: null,
  consecutiveErrors: 0,
  totalRequests: 0,
  failedRequests: 0,
};

// Request queue för rate limiting
let lastRequestTime = 0;
const requestQueue: Array<() => void> = [];
let isProcessingQueue = false;

// Vänta tills det är okej att göra nästa anrop
async function waitForRateLimit(): Promise<void> {
  const now = Date.now();
  const timeSinceLastRequest = now - lastRequestTime;
  
  if (timeSinceLastRequest < RATE_LIMIT.minDelayMs) {
    const waitTime = RATE_LIMIT.minDelayMs - timeSinceLastRequest;
    await new Promise(resolve => setTimeout(resolve, waitTime));
  }
  
  lastRequestTime = Date.now();
}

// Detektera om felet indikerar rate limiting/blockering
// OBS: Var STRIKT här - bara verkliga rate limit-fel ska trigga blockering
function isRateLimitError(error: unknown, response?: Response): boolean {
  if (response?.status === 429) return true;
  if (response?.status === 503) return true;
  
  const errorStr = String(error).toLowerCase();
  // Endast explicit rate limit-meddelanden
  return errorStr.includes('too many requests') || errorStr.includes('rate limit');
}

// Huvudfunktion för att göra API-anrop
export async function koladaFetch<T>(
  endpoint: string,
  options: {
    timeout?: number;
    retries?: number;
    critical?: boolean; // Om true, kasta fel istället för att returnera null
  } = {}
): Promise<{ data: T | null; error: string | null; blocked: boolean }> {
  const {
    timeout = RATE_LIMIT.baseTimeoutMs,
    retries = RATE_LIMIT.maxRetries,
    critical = false,
  } = options;

  // Kolla om vi är blockerade
  if (apiStatus.isBlocked && apiStatus.blockedUntil) {
    if (Date.now() < apiStatus.blockedUntil) {
      const waitSecs = Math.ceil((apiStatus.blockedUntil - Date.now()) / 1000);
      return {
        data: null,
        error: `API blockerat - vänta ${waitSecs} sekunder eller byt IP`,
        blocked: true,
      };
    } else {
      // Prova igen efter blockeringstiden
      apiStatus.isBlocked = false;
      apiStatus.blockedUntil = null;
    }
  }

  const url = endpoint.startsWith('http') ? endpoint : `${KOLADA_BASE}${endpoint}`;
  
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      // Rate limiting
      await waitForRateLimit();
      
      apiStatus.totalRequests++;
      console.log(`[KOLADA] ${attempt > 0 ? `Retry ${attempt}/${retries} - ` : ''}${url}`);
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);
      
      const response = await fetch(url, {
        signal: controller.signal,
        headers: {
          'Accept': 'application/json',
        },
      });
      
      clearTimeout(timeoutId);
      
      // Hantera rate limiting
      if (response.status === 429) {
        apiStatus.consecutiveErrors++;
        apiStatus.failedRequests++;
        
        // Markera som blockerad
        const retryAfter = response.headers.get('Retry-After');
        const blockDuration = retryAfter ? parseInt(retryAfter) * 1000 : 60000;
        
        apiStatus.isBlocked = true;
        apiStatus.blockedUntil = Date.now() + blockDuration;
        apiStatus.lastError = 'Rate limit - för många anrop';
        
        console.error(`[KOLADA] RATE LIMITED! Blockerad i ${blockDuration/1000}s`);
        
        return {
          data: null,
          error: `API rate limit - vänta ${Math.ceil(blockDuration/1000)} sekunder eller byt IP`,
          blocked: true,
        };
      }
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Framgång - återställ error counter
      apiStatus.consecutiveErrors = 0;
      apiStatus.lastError = null;
      
      return { data: data as T, error: null, blocked: false };
      
    } catch (error) {
      apiStatus.consecutiveErrors++;
      apiStatus.failedRequests++;
      
      const isRateLimit = isRateLimitError(error);
      
      console.error(`[KOLADA] Fel (försök ${attempt + 1}/${retries + 1}):`, error);
      
      // ENDAST markera som blockerad vid explicit 429-svar
      // Timeout-fel ska INTE trigga blockering - de kan ha andra orsaker
      if (isRateLimit) {
        console.error(`[KOLADA] Rate limit detekterad - försöker igen...`);
        // Fortsätt med retry istället för att blockera direkt
      }
      
      // Vänta innan retry (exponentiell backoff)
      if (attempt < retries) {
        const backoffMs = Math.min(1000 * Math.pow(2, attempt), 10000);
        console.log(`[KOLADA] Väntar ${backoffMs}ms innan retry...`);
        await new Promise(resolve => setTimeout(resolve, backoffMs));
      }
    }
  }
  
  // Alla retries misslyckades
  apiStatus.lastError = 'Alla försök misslyckades';
  
  if (critical) {
    throw new Error(`Kolada API-anrop misslyckades: ${url}`);
  }
  
  // Returnera ALDRIG blocked: true bara för att retries misslyckades
  // Endast explicit 429-svar ska trigga blockering
  return {
    data: null,
    error: 'Kunde inte nå Kolada API efter flera försök',
    blocked: false,
  };
}

// Hjälpfunktion för att hämta OUs
export async function fetchOUs(municipalityId: string): Promise<{
  data: Array<{ id: string; title: string; municipality: string }> | null;
  error: string | null;
  blocked: boolean;
}> {
  const result = await koladaFetch<{ values: Array<{ id: string; title: string; municipality: string }> }>(
    `/ou?municipality=${municipalityId}&per_page=1000`
  );
  
  if (result.data) {
    return { data: result.data.values || [], error: null, blocked: false };
  }
  
  return { data: null, error: result.error, blocked: result.blocked };
}

// Hjälpfunktion för att hämta oudata
export async function fetchOUData(
  kpi: string,
  year: number,
  municipalityId: string
): Promise<{
  data: Array<{ ou: string; period: number; values: Array<{ value: number | null; gender: string }> }> | null;
  error: string | null;
  blocked: boolean;
}> {
  const result = await koladaFetch<{ values: Array<{ ou: string; period: number; values: Array<{ value: number | null; gender: string }> }> }>(
    `/oudata/kpi/${kpi}/year/${year}?municipality_id=${municipalityId}&per_page=5000`,
    { timeout: 45000 } // Längre timeout för oudata
  );
  
  if (result.data) {
    return { data: result.data.values || [], error: null, blocked: false };
  }
  
  return { data: null, error: result.error, blocked: result.blocked };
}

// Hjälpfunktion för att hämta kommundata
export async function fetchMunicipalityData(
  kpi: string,
  municipalityIds: string[],
  year: number
): Promise<{
  data: Array<{ kpi: string; municipality: string; period: number; values: Array<{ value: number | null; gender: string }> }> | null;
  error: string | null;
  blocked: boolean;
}> {
  const munParam = municipalityIds.join(',');
  const result = await koladaFetch<{ values: Array<{ kpi: string; municipality: string; period: number; values: Array<{ value: number | null; gender: string }> }> }>(
    `/data/kpi/${kpi}/municipality/${munParam}/year/${year}`,
    { timeout: 45000 }
  );
  
  if (result.data) {
    return { data: result.data.values || [], error: null, blocked: false };
  }
  
  return { data: null, error: result.error, blocked: result.blocked };
}

// Hämta aktuell API-status
export function getApiStatus(): ApiStatus {
  return { ...apiStatus };
}

// Återställ API-status (t.ex. efter IP-byte)
export function resetApiStatus(): void {
  apiStatus = {
    isBlocked: false,
    blockedUntil: null,
    lastError: null,
    consecutiveErrors: 0,
    totalRequests: apiStatus.totalRequests, // Behåll statistik
    failedRequests: apiStatus.failedRequests,
  };
  console.log('[KOLADA] API-status återställd');
}

// Exportera status för frontend
export function getApiStatusForFrontend(): {
  blocked: boolean;
  message: string | null;
  waitSeconds: number | null;
} {
  if (!apiStatus.isBlocked) {
    return { blocked: false, message: null, waitSeconds: null };
  }
  
  const waitSeconds = apiStatus.blockedUntil 
    ? Math.max(0, Math.ceil((apiStatus.blockedUntil - Date.now()) / 1000))
    : null;
  
  return {
    blocked: true,
    message: apiStatus.lastError || 'API överbelastat',
    waitSeconds,
  };
}
