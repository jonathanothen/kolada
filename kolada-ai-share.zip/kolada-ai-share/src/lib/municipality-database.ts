import municipalityData from '../data/municipalities.json';

interface Municipality {
  id: string;
  name: string;
  type: string; // K = kommun, L = län/region
}

interface MunicipalityDatabase {
  count: number;
  lastUpdated: string;
  municipalities: Municipality[];
  lookup: { [name: string]: Municipality };
}

// Ladda kommun-databasen
const db: MunicipalityDatabase = municipalityData as MunicipalityDatabase;

// Skapa en map för snabb ID-till-namn lookup
const idToName: { [id: string]: string } = {};
for (const mun of db.municipalities) {
  idToName[mun.id] = mun.name;
}

/**
 * Söker efter en kommun baserat på namn.
 * Returnerar null om ingen matchning hittas.
 */
export function findMunicipality(name: string): Municipality | null {
  if (!name) return null;
  
  const lowerName = name.toLowerCase().trim();
  
  // Direkt lookup (snabbast)
  if (db.lookup[lowerName]) {
    return db.lookup[lowerName];
  }
  
  // Sök med fuzzy matching om direkt lookup misslyckas
  for (const mun of db.municipalities) {
    const munLower = mun.name.toLowerCase();
    
    // Exakt match
    if (munLower === lowerName) return mun;
    
    // Börjar med söksträngen
    if (munLower.startsWith(lowerName)) return mun;
    
    // Innehåller söksträngen (bara för korta söksträngar)
    if (lowerName.length >= 3 && munLower.includes(lowerName)) return mun;
  }
  
  return null;
}

/**
 * Söker efter flera kommuner baserat på en lista med namn.
 * Returnerar en lista med hittade kommuner.
 */
export function findMunicipalities(names: string[]): Municipality[] {
  const found: Municipality[] = [];
  const foundIds = new Set<string>();
  
  for (const name of names) {
    const mun = findMunicipality(name);
    if (mun && !foundIds.has(mun.id)) {
      found.push(mun);
      foundIds.add(mun.id);
    }
  }
  
  return found;
}

/**
 * Hämtar alla kommuner (typ K).
 */
export function getAllKommuner(): Municipality[] {
  return db.municipalities.filter(m => m.type === 'K');
}

/**
 * Hämtar alla regioner/län (typ L).
 */
export function getAllRegioner(): Municipality[] {
  return db.municipalities.filter(m => m.type === 'L');
}

/**
 * Hämtar kommun-namn baserat på ID.
 */
export function getMunicipalityName(id: string): string | null {
  return idToName[id] || null;
}

/**
 * Skapar en lookup-map från ID till namn för alla kommuner.
 */
export function getMunicipalityNameLookup(): { [id: string]: string } {
  return { ...idToName };
}

/**
 * Returnerar antal kommuner i databasen.
 */
export function getMunicipalityCount(): number {
  return db.count;
}

/**
 * Kontrollerar om databasen är laddad.
 */
export function isDatabaseLoaded(): boolean {
  return db.count > 0;
}

// Log vid laddning
console.log(`[MUNICIPALITY-DB] Laddade ${db.count} kommuner/regioner`);
