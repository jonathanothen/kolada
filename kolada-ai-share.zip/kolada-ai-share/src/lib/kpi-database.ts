/**
 * Lokal KPI-databas för snabb sökning utan API-anrop.
 * Databasen synkas från Kolada API med scripts/sync-kpis.ts
 */

import kpiData from '../data/kpis.json';

export interface KPI {
  id: string;
  title: string;
  description: string;
  has_ou_data: boolean;
  municipality_type: string;
  operating_area: string;
  is_divided_by_gender: number;
}

export interface KPIDatabase {
  lastUpdated: string | null;
  count: number;
  kpis: KPI[];
}

// Ladda databasen från JSON-fil
const cachedDatabase: KPIDatabase = kpiData as KPIDatabase;

export function getKPIDatabase(): KPIDatabase {
  return cachedDatabase;
}

export function isDatabasePopulated(): boolean {
  return cachedDatabase.count > 0;
}

// Prioriterade KPIs för vanliga sökningar - dessa boostar när relevanta söktermer används
const PRIORITY_KPIS: { [kpiId: string]: string[] } = {
  // Befolkning - N01951 ska ALLTID komma först vid befolkningsfrågor
  'N01951': ['befolkning', 'invånare', 'folkmängd', 'population', 'antal personer', 'hur många bor'],
  'N01963': ['befolkningsförändring', 'befolkning förändring', 'ökat', 'minskat'],
  
  // Utrikes födda
  'N02926': ['utrikes födda', 'född utomlands', 'invandrare', 'annat land', 'utländsk'],
  
  // Sjukfrånvaro
  'N00090': ['sjukfrånvaro', 'sjuk', 'frånvaro', 'sjukskrivning'],
  'N00092': ['sjukfrånvaro unga', 'sjuk under 30'],
  'N00093': ['sjukfrånvaro medelålder', 'sjuk 30-49'],
  'N00094': ['sjukfrånvaro äldre', 'sjuk över 49'],
  
  // Skolmat
  'N15013': ['skolmat', 'måltid', 'lunch', 'portion', 'mat i skolan'],
  'N17012': ['skolmat gymnasium', 'måltid gymnasie'],
  
  // Lärartäthet  
  'N15033': ['lärartäthet', 'elever per lärare', 'antal lärare'],
  'N10601': ['personaltäthet förskola', 'barn per personal'],
  
  // Skolresultat
  'N15428': ['meritvärde', 'betyg', 'resultat åk 9'],
  'N15403': ['behörig gymnasium', 'gymnasiebehörighet'],
  
  // Skatt
  'N00900': ['skatt', 'skattesats', 'kommunalskatt'],
  'N00901': ['kommunskatt', 'skatt kommun'],
  
  // Äldreomsorg
  'N28013': ['äldreomsorg kostnad', 'omsorg äldre'],
  
  // Arbetslöshet
  'N00925': ['arbetslöshet', 'arbetslösa', 'utan arbete'],
  'N00916': ['öppet arbetslösa'],
  
  // Företagande
  'N02251': ['egenföretagare', 'företagare', 'egen företag', 'självständig'],
  'N02252': ['egenföretagare arbetsställe', 'företagare arbetsplats'],
  'N00999': ['nystartade företag', 'nya företag', 'startups'],
  'N01003': ['nystartade företag antal'],
  
  // Region/Administration
  'N60063': ['ledning', 'administration', 'stöd', 'utveckling', 'årsarbetare region'],
  'N63012': ['nettokostnad region', 'kostnad region'],
  'N63013': ['kostnad region totalt'],
};

/**
 * Söker efter KPIs som matchar söktermerna.
 * Prioriterar: 1) Priority KPIs 2) Kort, specifik titel 3) Titel-matchningar 4) Beskrivning
 */
export function searchKPIs(searchTerms: string[]): KPI[] {
  const db = getKPIDatabase();
  
  if (db.count === 0) {
    return [];
  }
  
  const queryLower = searchTerms.join(' ').toLowerCase();
  
  // Skapa söksträngar med stammar för böjningsformer
  const termPatterns = searchTerms.map(term => ({
    term: term.toLowerCase(),
    stem: term.toLowerCase().replace(/er$|ar$|or$|na$|en$|et$|erna$|arna$/, '')
  }));
  
  // Poängsätt ALLA KPIs
  const scored: { kpi: KPI; score: number; matchedTerms: string[]; titleMatches: number; isPriority: boolean }[] = [];
  
  for (const kpi of db.kpis) {
    const lowerTitle = kpi.title.toLowerCase();
    const lowerDesc = kpi.description.toLowerCase();
    
    let score = 0;
    const matchedTerms: string[] = [];
    let titleMatches = 0;
    let isPriority = false;
    
    // FÖRST: Kolla om detta är en prioriterad KPI för dessa söktermer
    const priorityKeywords = PRIORITY_KPIS[kpi.id];
    if (priorityKeywords) {
      for (const keyword of priorityKeywords) {
        if (queryLower.includes(keyword) || termPatterns.some(p => keyword.includes(p.term) || keyword.includes(p.stem))) {
          score += 2000; // Mycket stor bonus för priority KPIs
          isPriority = true;
          matchedTerms.push(`PRIORITY:${keyword}`);
          break;
        }
      }
    }
    
    // Räkna matchningar per term
    for (const { term, stem } of termPatterns) {
      let matched = false;
      let termScore = 0;
      
      // Titel-matchningar (högst prioritet)
      if (lowerTitle.includes(term)) {
        matched = true;
        termScore = 100;
        titleMatches++;
      } else if (stem.length >= 3 && lowerTitle.includes(stem)) {
        matched = true;
        termScore = 80;
        titleMatches++;
      }
      // Beskrivnings-matchningar
      else if (lowerDesc.includes(term)) {
        matched = true;
        termScore = 30;
      } else if (stem.length >= 3 && lowerDesc.includes(stem)) {
        matched = true;
        termScore = 20;
      }
      
      if (matched) {
        if (!matchedTerms.includes(term)) matchedTerms.push(term);
        score += termScore;
      }
    }
    
    if (matchedTerms.length > 0 || isPriority) {
      // Bonus för fler matchade termer
      const realMatches = matchedTerms.filter(t => !t.startsWith('PRIORITY:')).length;
      if (realMatches > 1) {
        score *= realMatches;
      }
      
      // STOR bonus för korta, specifika titlar (de är ofta bas-KPIs, inte avledda)
      // "Folkmängd totalt" (16 tecken) vs "Äldre äldre av invånare 65+, andel (%)" (42 tecken)
      if (lowerTitle.length < 30) {
        score += 300;
      } else if (lowerTitle.length < 50) {
        score += 100;
      }
      
      // Negativ bonus för KPIs som är andelar (%) när vi söker absoluta tal
      if (queryLower.includes('antal') || queryLower.includes('hur många')) {
        if (lowerTitle.includes('andel') || lowerTitle.includes('%')) {
          score -= 200;
        }
      }
      
      // Negativ bonus för mycket långa titlar (ofta nischade KPIs)
      if (lowerTitle.length > 80) {
        score -= 50;
      }
      
      scored.push({ kpi, score, matchedTerms, titleMatches, isPriority });
    }
  }
  
  // Sortera: Priority först, sedan poäng
  scored.sort((a, b) => {
    // Priority KPIs först
    if (a.isPriority && !b.isPriority) return -1;
    if (b.isPriority && !a.isPriority) return 1;
    // Sen efter total poäng
    return b.score - a.score;
  });
  
  return scored.map(s => s.kpi);
}

/**
 * Hämta en specifik KPI med ID
 */
export function getKPIById(id: string): KPI | null {
  const db = getKPIDatabase();
  return db.kpis.find((k: KPI) => k.id === id) || null;
}

/**
 * Hämta alla KPIs med enhetsdata (för skolor, förskolor etc.)
 */
export function getKPIsWithOUData(): KPI[] {
  const db = getKPIDatabase();
  return db.kpis.filter((k: KPI) => k.has_ou_data);
}

/**
 * Kontrollera om databasen är tillgänglig och hur gammal den är
 */
export function getDatabaseStatus(): {
  available: boolean;
  lastUpdated: string | null;
  count: number;
  ageInDays: number | null;
} {
  const db = getKPIDatabase();
  
  if (db.count === 0 || !db.lastUpdated) {
    return {
      available: false,
      lastUpdated: null,
      count: 0,
      ageInDays: null,
    };
  }
  
  const lastUpdated = new Date(db.lastUpdated);
  const now = new Date();
  const ageInDays = Math.floor((now.getTime() - lastUpdated.getTime()) / (1000 * 60 * 60 * 24));
  
  return {
    available: true,
    lastUpdated: db.lastUpdated,
    count: db.count,
    ageInDays,
  };
}
