// Kolada API v3 Client - Komplett implementation
// https://api.kolada.se/v3
// Stödjer ALL data inklusive enhetsdata (OU)

const KOLADA_BASE_URL = "https://api.kolada.se/v3";

// ==================== TYPER ====================

export interface KPI {
  id: string;
  title: string;
  description: string | null;
  is_divided_by_gender: boolean;
  municipality_type: "K" | "L" | "A"; // K=Kommun, L=Region, A=Alla
  auspice: "X" | "T" | "P" | "O" | "E" | "A" | null; // X=Ej relevant, T=Total, P=Privat, O=Offentlig, E=Egen, A=Annan
  operating_area: string | null; // Verksamhetsområde
  perspective: "Kvalitet och resultat" | "Resurser" | "Volymer" | "Övrigt" | null;
  prel_publication_date: string | null;
  publication_date: string | null;
  publ_period: string | null;
  has_ou_data: boolean; // Har enhetsdata
}

export interface Municipality {
  id: string;
  title: string;
  type: "K" | "L" | "R"; // K=Kommun, L=Län/Region, R=Riket
}

// Organizational Unit (Enhet) - t.ex. specifik skola, förskola, äldreboende
export interface OU {
  id: string; // Börjar med V + 2 siffror
  title: string;
  municipality: string;
}

// OU-typer (enhetskoder)
export const OU_TYPES = {
  V11: "Förskola",
  V15: "Grundskola F-9",
  V17: "Gymnasieskola",
  V21: "Hemtjänst, äldre",
  V23: "Särskilt boende, äldre",
  V25: "LSS boende med särskild service",
  V26: "LSS daglig verksamhet",
  V29: "Gruppbostad LSS",
  V30: "Servicebostad LSS",
  V31: "SoL Boendestöd",
  V32: "SoL Boende med särskild service",
  V34: "SoL Sysselsättning",
  V45: "Våld i nära relationer",
  V60: "Fastigheter - region",
} as const;

export interface DataValue {
  gender: "K" | "M" | "T" | null; // K=Kvinnor, M=Män, T=Totalt
  count: number;
  status: string | null;
  value: number | null;
  isdeleted: boolean;
}

export interface MunicipalityData {
  values: DataValue[];
  kpi: string;
  period: number;
  municipality: string;
}

// Enhetsdata
export interface OUData {
  values: DataValue[];
  kpi: string;
  period: number;
  ou: string;
}

export interface PaginatedResponse<T> {
  values: T[];
  next_url: string | null;
  previous_url: string | null;
  count: number;
}

export interface KoladaGroup {
  id: string;
  title: string;
  members: { member_id: string; member_title: string }[];
}

// API Functions

export async function searchKPIs(
  title?: string,
  page: number = 1,
  perPage: number = 100
): Promise<PaginatedResponse<KPI>> {
  const params = new URLSearchParams();
  if (title) params.append("title", title);
  params.append("page", page.toString());
  params.append("per_page", perPage.toString());

  const response = await fetch(`${KOLADA_BASE_URL}/kpi?${params}`);
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

export async function getKPIById(kpiId: string): Promise<PaginatedResponse<KPI>> {
  const response = await fetch(`${KOLADA_BASE_URL}/kpi/${kpiId}`);
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

export async function searchMunicipalities(
  title?: string,
  regionType?: "municipality" | "region",
  page: number = 1,
  perPage: number = 100
): Promise<PaginatedResponse<Municipality>> {
  const params = new URLSearchParams();
  if (title) params.append("title", title);
  if (regionType) params.append("region_type", regionType);
  params.append("page", page.toString());
  params.append("per_page", perPage.toString());

  const response = await fetch(`${KOLADA_BASE_URL}/municipality?${params}`);
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

export async function getMunicipalityById(
  municipalityId: string
): Promise<PaginatedResponse<Municipality>> {
  const response = await fetch(
    `${KOLADA_BASE_URL}/municipality/${municipalityId}`
  );
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

export async function getData(
  kpiId?: string[],
  municipalityId?: string[],
  year?: number[],
  regionType?: "municipality" | "region",
  page: number = 1,
  perPage: number = 1000
): Promise<PaginatedResponse<MunicipalityData>> {
  const params = new URLSearchParams();
  if (kpiId) kpiId.forEach((id) => params.append("kpi_id", id));
  if (municipalityId)
    municipalityId.forEach((id) => params.append("municipality_id", id));
  if (year) year.forEach((y) => params.append("year", y.toString()));
  if (regionType) params.append("region_type", regionType);
  params.append("page", page.toString());
  params.append("per_page", perPage.toString());

  const response = await fetch(`${KOLADA_BASE_URL}/data/?${params}`);
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

export async function getDataByKPIAndYear(
  kpiId: string,
  year: string,
  regionType?: "municipality" | "region"
): Promise<PaginatedResponse<MunicipalityData>> {
  const params = new URLSearchParams();
  if (regionType) params.append("region_type", regionType);

  const response = await fetch(
    `${KOLADA_BASE_URL}/data/kpi/${kpiId}/year/${year}?${params}`
  );
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

export async function getDataByKPIAndMunicipality(
  kpiId: string,
  municipalityId: string
): Promise<PaginatedResponse<MunicipalityData>> {
  const response = await fetch(
    `${KOLADA_BASE_URL}/data/kpi/${kpiId}/municipality/${municipalityId}`
  );
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

export async function getDataByMunicipalityAndYear(
  municipalityId: string,
  year: string
): Promise<PaginatedResponse<MunicipalityData>> {
  const response = await fetch(
    `${KOLADA_BASE_URL}/data/municipality/${municipalityId}/year/${year}`
  );
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

export async function getKPIGroups(
  title?: string
): Promise<PaginatedResponse<KoladaGroup>> {
  const params = new URLSearchParams();
  if (title) params.append("title", title);

  const response = await fetch(`${KOLADA_BASE_URL}/kpi_groups?${params}`);
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

export async function getMunicipalityGroups(
  title?: string
): Promise<PaginatedResponse<KoladaGroup>> {
  const params = new URLSearchParams();
  if (title) params.append("title", title);

  const response = await fetch(
    `${KOLADA_BASE_URL}/municipality_groups?${params}`
  );
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

// Helper functions

export function formatValue(value: number | null, decimals: number = 1): string {
  if (value === null) return "N/A";
  return value.toLocaleString("sv-SE", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function getGenderLabel(gender: string | null): string {
  switch (gender) {
    case "K":
      return "Kvinnor";
    case "M":
      return "Män";
    case "T":
      return "Totalt";
    default:
      return "Totalt";
  }
}

// ==================== ORGANIZATIONAL UNITS (ENHETER) ====================

// Sök efter enheter
export async function searchOUs(
  title?: string,
  municipalityId?: string,
  page: number = 1,
  perPage: number = 100
): Promise<PaginatedResponse<OU>> {
  const params = new URLSearchParams();
  if (title) params.append("title", title);
  if (municipalityId) params.append("municipality_id", municipalityId);
  params.append("page", page.toString());
  params.append("per_page", perPage.toString());

  const response = await fetch(`${KOLADA_BASE_URL}/ou?${params}`);
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

// Hämta specifik enhet
export async function getOUById(ouId: string): Promise<PaginatedResponse<OU>> {
  const response = await fetch(`${KOLADA_BASE_URL}/ou/${ouId}`);
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

// Hämta enhetsdata (generell)
export async function getOUData(
  kpiId?: string[],
  ouId?: string[],
  year?: number[],
  page: number = 1,
  perPage: number = 1000
): Promise<PaginatedResponse<OUData>> {
  const params = new URLSearchParams();
  if (kpiId) kpiId.forEach((id) => params.append("kpi_id", id));
  if (ouId) ouId.forEach((id) => params.append("ou_id", id));
  if (year) year.forEach((y) => params.append("year", y.toString()));
  params.append("page", page.toString());
  params.append("per_page", perPage.toString());

  const response = await fetch(`${KOLADA_BASE_URL}/oudata/?${params}`);
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

// Hämta enhetsdata för specifik KPI, enhet och år
export async function getOUDataExact(
  kpiId: string,
  ouId: string,
  year: number
): Promise<PaginatedResponse<OUData>> {
  const response = await fetch(
    `${KOLADA_BASE_URL}/oudata/kpi/${kpiId}/ou/${ouId}/year/${year}`
  );
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

// Hämta enhetsdata för KPI och år (alla enheter i en kommun)
export async function getOUDataByKPIAndYear(
  kpiId: string,
  year: number,
  municipalityId?: string,
  page: number = 1,
  perPage: number = 1000
): Promise<PaginatedResponse<OUData>> {
  const params = new URLSearchParams();
  if (municipalityId) params.append("municipality_id", municipalityId);
  params.append("page", page.toString());
  params.append("per_page", perPage.toString());

  const response = await fetch(
    `${KOLADA_BASE_URL}/oudata/kpi/${kpiId}/year/${year}?${params}`
  );
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

// Hämta tidserie för en enhet och KPI
export async function getOUDataTimeline(
  kpiId: string,
  ouId: string,
  page: number = 1,
  perPage: number = 100
): Promise<PaginatedResponse<OUData>> {
  const params = new URLSearchParams();
  params.append("page", page.toString());
  params.append("per_page", perPage.toString());

  const response = await fetch(
    `${KOLADA_BASE_URL}/oudata/kpi/${kpiId}/ou/${ouId}?${params}`
  );
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

// Hämta alla KPIs för en enhet ett specifikt år
export async function getOUDataByOUAndYear(
  ouId: string,
  year: number,
  page: number = 1,
  perPage: number = 100
): Promise<PaginatedResponse<OUData>> {
  const params = new URLSearchParams();
  params.append("page", page.toString());
  params.append("per_page", perPage.toString());

  const response = await fetch(
    `${KOLADA_BASE_URL}/oudata/ou/${ouId}/year/${year}?${params}`
  );
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

// ==================== AVANCERAD KPI-SÖKNING ====================

// Sök KPIs med filter
export async function searchKPIsAdvanced(options: {
  title?: string;
  operatingArea?: string;
  hasOuData?: boolean;
  municipalityType?: "K" | "L" | "A";
  page?: number;
  perPage?: number;
}): Promise<PaginatedResponse<KPI>> {
  const params = new URLSearchParams();
  if (options.title) params.append("title", options.title);
  if (options.operatingArea) params.append("operating_area", options.operatingArea);
  if (options.hasOuData !== undefined) params.append("has_ou_data", options.hasOuData.toString());
  if (options.municipalityType) params.append("municipality_type", options.municipalityType);
  params.append("page", (options.page || 1).toString());
  params.append("per_page", (options.perPage || 100).toString());

  const response = await fetch(`${KOLADA_BASE_URL}/kpi?${params}`);
  if (!response.ok) throw new Error(`Kolada API error: ${response.status}`);
  return response.json();
}

// Hämta KPIs med enhetsdata för en viss verksamhet
export async function getKPIsWithOUData(
  operatingArea?: string
): Promise<KPI[]> {
  const result = await searchKPIsAdvanced({
    operatingArea,
    hasOuData: true,
    perPage: 1000,
  });
  return result.values;
}

// ==================== HJÄLPFUNKTIONER ====================

// Identifiera enhetstyp från ID
export function getOUType(ouId: string): string | undefined {
  const prefix = ouId.substring(0, 3);
  return OU_TYPES[prefix as keyof typeof OU_TYPES];
}

// Lista verksamhetsområden
export const OPERATING_AREAS = [
  "Förskoleverksamhet",
  "Grundskola",
  "Gymnasieskola",
  "Äldreomsorg",
  "Hemtjänst",
  "Särskilt boende",
  "LSS",
  "Ekonomiskt bistånd",
  "Folkhälsa",
  "Arbetsmarknad",
  "Befolkning",
  "Skatter och utjämning",
  "Infrastruktur, miljö- och hälsoskydd mm",
] as const;

// Vanliga KPIs för snabbåtkomst
export const COMMON_KPIS = {
  // Befolkning
  POPULATION_TOTAL: "N01951",
  POPULATION_CHANGE: "N01963",
  POPULATION_65_PLUS: "N01960",
  
  // Skatt
  TAX_RATE_TOTAL: "N00900",
  TAX_RATE_MUNICIPALITY: "N00901",
  
  // Förskola
  PRESCHOOL_CHILDREN_PER_STAFF: "N10601",
  PRESCHOOL_COST_PER_CHILD: "U21477",
  
  // Skola
  SCHOOL_MERIT_VALUE: "N15428",
  SCHOOL_ELIGIBLE_GYMNASIUM: "N15403",
  SCHOOL_PUPILS_PER_TEACHER: "N15033",
  
  // Äldreomsorg
  ELDERLY_CARE_COST: "N28013",
  HOME_CARE_COST: "N28014",
  ELDERLY_SATISFIED: "U21496",
  
  // Arbetsmarknad
  UNEMPLOYMENT: "N00909",
  EMPLOYMENT_RATE: "N03100",
} as const;
