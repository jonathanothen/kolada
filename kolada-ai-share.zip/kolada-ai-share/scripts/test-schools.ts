/**
 * Testscript för att verifiera skolhämtning från Kolada API
 * Kör: npx ts-node scripts/test-schools.ts
 */

async function testSchoolFetch() {
  console.log('=== TEST: Kolada Skolhämtning ===\n');
  
  // Test 1: Hämta skolor för Örebro (1880)
  console.log('Test 1: Hämtar grundskolor i Örebro kommun...');
  try {
    const url = 'https://api.kolada.se/v3/ou?municipality=1880&title=skola&per_page=50';
    console.log(`URL: ${url}`);
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000);
    
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${await response.text()}`);
    }
    
    const data = await response.json();
    console.log(`✓ Totalt hittade: ${data.count} enheter`);
    
    // Filtrera för grundskolor (V15*)
    const grundskolor = (data.values || []).filter((ou: {id: string}) => ou.id.startsWith('V15'));
    console.log(`✓ Varav grundskolor (V15*): ${grundskolor.length}`);
    
    if (grundskolor.length > 0) {
      console.log('\nGrundskolor:');
      grundskolor.slice(0, 10).forEach((s: {id: string; title: string}) => {
        console.log(`  - ${s.title} (${s.id})`);
      });
    }
  } catch (error) {
    console.log(`✗ Fel: ${error}`);
  }
  
  // Test 2: Hämta skoldata (meritvärde)
  console.log('\n---\nTest 2: Hämtar meritvärde för en skola...');
  try {
    // Först hitta en skola
    const ouUrl = 'https://api.kolada.se/v3/ou?municipality=1880&title=skola&per_page=10';
    const ouResponse = await fetch(ouUrl, { signal: AbortSignal.timeout(20000) });
    const ouData = await ouResponse.json();
    
    const grundskola = (ouData.values || []).find((ou: {id: string}) => ou.id.startsWith('V15'));
    
    if (grundskola) {
      console.log(`Testar skola: ${grundskola.title} (${grundskola.id})`);
      
      const dataUrl = `https://api.kolada.se/v3/oudata/kpi/N15504/ou/${grundskola.id}/year/2023`;
      console.log(`URL: ${dataUrl}`);
      
      const dataResponse = await fetch(dataUrl, { signal: AbortSignal.timeout(20000) });
      const meritData = await dataResponse.json();
      
      if (meritData.values?.length > 0) {
        const value = meritData.values[0]?.values?.find((v: {gender: string}) => v.gender === 'T');
        console.log(`✓ Meritvärde 2023: ${value?.value || 'N/A'}`);
      } else {
        console.log('✗ Ingen data hittades');
      }
    } else {
      console.log('✗ Ingen grundskola hittades att testa med');
    }
  } catch (error) {
    console.log(`✗ Fel: ${error}`);
  }
  
  // Test 3: Testa flera kommuner
  console.log('\n---\nTest 3: Testar flera kommuner i Örebro län...');
  const kommuner = [
    { id: '1880', name: 'Örebro' },
    { id: '1881', name: 'Kumla' },
    { id: '1883', name: 'Karlskoga' }
  ];
  
  for (const kommun of kommuner) {
    try {
      const url = `https://api.kolada.se/v3/ou?municipality=${kommun.id}&title=skola&per_page=50`;
      const response = await fetch(url, { signal: AbortSignal.timeout(15000) });
      const data = await response.json();
      
      const grundskolor = (data.values || []).filter((ou: {id: string}) => ou.id.startsWith('V15'));
      console.log(`${kommun.name}: ${grundskolor.length} grundskolor`);
    } catch (error) {
      console.log(`${kommun.name}: Timeout eller fel`);
    }
  }
  
  console.log('\n=== TEST KLART ===');
}

testSchoolFetch().catch(console.error);
