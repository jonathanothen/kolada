#!/usr/bin/env npx ts-node
/**
 * Synkroniserings-script för att ladda ner ALLA organisatoriska enheter (OUs) från Kolada
 * och spara dem lokalt. Detta eliminerar behovet av upprepade API-anrop.
 * 
 * Kör: npx ts-node scripts/sync-ous.ts
 * eller: npm run sync-ous
 * 
 * OPTIMERAD VERSION: Hämtar ALLA OUs i ett enda API-anrop!
 */

import * as fs from 'fs';
import * as path from 'path';

interface OU {
  id: string;
  title: string;
  municipality: string;
  type: 'grundskola' | 'gymnasium' | 'förskola' | 'äldreboende' | 'hemtjänst' | 'okänd';
}

const KOLADA_BASE = 'https://api.kolada.se/v3';
const OUTPUT_FILE = path.join(__dirname, '..', 'src', 'data', 'ous.json');

async function fetchWithRetry(url: string, retries = 3): Promise<any> {
  for (let i = 0; i < retries; i++) {
    try {
      console.log(`Hämtar: ${url}`);
      const response = await fetch(url, {
        signal: AbortSignal.timeout(120000) // 2 min timeout för stora anrop
      });
      
      if (!response.ok) {
        console.error(`⚠ HTTP ${response.status}`);
        if (i < retries - 1) {
          console.log(`  Försöker igen om ${2 * (i + 1)} sekunder...`);
          await new Promise(r => setTimeout(r, 2000 * (i + 1)));
          continue;
        }
        return null;
      }
      
      return await response.json();
    } catch (e) {
      console.error(`⚠ Fel (försök ${i + 1}/${retries}):`, e);
      if (i < retries - 1) {
        await new Promise(r => setTimeout(r, 2000 * (i + 1)));
      }
    }
  }
  return null;
}

function getOUType(id: string): OU['type'] {
  if (id.startsWith('V15')) return 'grundskola';
  if (id.startsWith('V17')) return 'gymnasium';
  if (id.startsWith('V11')) return 'förskola';
  if (id.startsWith('V23')) return 'äldreboende';
  if (id.startsWith('V21')) return 'hemtjänst';
  return 'okänd';
}

async function syncOUs() {
  console.log('='.repeat(60));
  console.log('KOLADA OU SYNC - OPTIMERAD');
  console.log('='.repeat(60));
  
  // Steg 1: Hämta ALLA OUs i ett enda anrop (Kolada stödjer detta!)
  console.log('\n🏫 Hämtar ALLA enheter från Kolada (ett anrop)...');
  
  // Kolada returnerar max 5000 per sida, så vi paginerar
  const allOUs: OU[] = [];
  let page = 1;
  let hasMore = true;
  
  while (hasMore) {
    const url = `${KOLADA_BASE}/ou?per_page=5000&page=${page}`;
    const data = await fetchWithRetry(url);
    
    if (!data) {
      console.error('❌ Kunde inte hämta OUs!');
      process.exit(1);
    }
    
    const values = data.values || [];
    console.log(`  Sida ${page}: ${values.length} enheter`);
    
    for (const ou of values) {
      const type = getOUType(ou.id);
      
      // Vi sparar bara relevanta typer (skolor, förskolor, äldreomsorg)
      if (type === 'okänd') continue;
      
      allOUs.push({
        id: ou.id,
        title: ou.title,
        municipality: ou.municipality,
        type
      });
    }
    
    // Kolla om det finns fler sidor
    hasMore = values.length === 5000;
    page++;
  }
  
  console.log(`\n✓ Totalt ${allOUs.length} relevanta enheter hämtade`);
  
  // Steg 2: Gruppera per kommun
  console.log('\n📊 Grupperar per kommun...');
  
  const byMunicipality: { [munId: string]: OU[] } = {};
  const stats = {
    grundskola: 0,
    gymnasium: 0,
    förskola: 0,
    äldreboende: 0,
    hemtjänst: 0
  };
  
  for (const ou of allOUs) {
    if (!byMunicipality[ou.municipality]) {
      byMunicipality[ou.municipality] = [];
    }
    byMunicipality[ou.municipality].push(ou);
    stats[ou.type]++;
  }
  
  // Steg 3: Hämta kommunnamn
  console.log('\n📋 Hämtar kommunnamn...');
  const munData = await fetchWithRetry(`${KOLADA_BASE}/municipality?per_page=500`);
  
  const municipalities: { [id: string]: string } = {};
  if (munData) {
    for (const m of munData.values || []) {
      municipalities[m.id] = m.title;
    }
  }
  
  // Steg 4: Spara till fil
  console.log('\n💾 Sparar till fil...');
  
  const output = {
    syncedAt: new Date().toISOString(),
    totalCount: allOUs.length,
    municipalityCount: Object.keys(byMunicipality).length,
    stats,
    municipalities,
    byMunicipality
  };
  
  fs.writeFileSync(OUTPUT_FILE, JSON.stringify(output, null, 2));
  
  console.log('\n' + '='.repeat(60));
  console.log('✅ SYNC KLAR!');
  console.log('='.repeat(60));
  console.log(`Totalt: ${allOUs.length} enheter i ${Object.keys(byMunicipality).length} kommuner`);
  console.log(`  - Grundskolor: ${stats.grundskola}`);
  console.log(`  - Gymnasium: ${stats.gymnasium}`);
  console.log(`  - Förskolor: ${stats.förskola}`);
  console.log(`  - Äldreboenden: ${stats.äldreboende}`);
  console.log(`  - Hemtjänst: ${stats.hemtjänst}`);
  console.log(`\nSparad till: ${OUTPUT_FILE}`);
  console.log(`\nStarta om dev-servern för att använda den lokala databasen.`);
}

syncOUs().catch(console.error);
