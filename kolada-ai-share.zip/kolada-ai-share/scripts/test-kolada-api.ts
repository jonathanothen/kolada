// Testar Kolada API för att se om data finns och hur snabbt det går

async function testKoladaApi() {
  const kpiId = 'N02251'; // Egenföretagare
  const munIds = ['1880', '1881', '1882']; // Örebro, Kumla, Askersund
  const years = [2010, 2015, 2020, 2024];
  
  console.log('=== TESTAR KOLADA API ===\n');
  
  // Test 1: Enskild kommun, enskilt år
  console.log('TEST 1: Enskild kommun, enskilt år');
  const start1 = Date.now();
  try {
    const url1 = `https://api.kolada.se/v3/data/kpi/${kpiId}/municipality/1880/year/2010`;
    console.log(`  URL: ${url1}`);
    const res1 = await fetch(url1);
    const data1 = await res1.json();
    console.log(`  Status: ${res1.status}`);
    console.log(`  Tid: ${Date.now() - start1}ms`);
    console.log(`  Antal värden: ${data1.values?.length || 0}`);
    if (data1.values?.[0]) {
      console.log(`  Data:`, JSON.stringify(data1.values[0], null, 2));
    }
  } catch (e) {
    console.log(`  FEL: ${e}`);
  }
  
  console.log('\n---\n');
  
  // Test 2: Flera kommuner, enskilt år (batch)
  console.log('TEST 2: Batch - 3 kommuner, 1 år');
  const start2 = Date.now();
  try {
    const url2 = `https://api.kolada.se/v3/data/kpi/${kpiId}/municipality/${munIds.join(',')}/year/2010`;
    console.log(`  URL: ${url2}`);
    const res2 = await fetch(url2);
    const data2 = await res2.json();
    console.log(`  Status: ${res2.status}`);
    console.log(`  Tid: ${Date.now() - start2}ms`);
    console.log(`  Antal värden: ${data2.values?.length || 0}`);
  } catch (e) {
    console.log(`  FEL: ${e}`);
  }
  
  console.log('\n---\n');
  
  // Test 3: Kolla vilka år som har data för N02251
  console.log('TEST 3: Kolla tillgängliga år för N02251');
  for (const year of years) {
    const start = Date.now();
    try {
      const url = `https://api.kolada.se/v3/data/kpi/${kpiId}/municipality/1880/year/${year}`;
      const res = await fetch(url);
      const data = await res.json();
      const hasData = data.values?.[0]?.values?.some((v: {value: number | null}) => v.value !== null);
      console.log(`  År ${year}: ${hasData ? '✓ DATA FINNS' : '✗ Ingen data'} (${Date.now() - start}ms)`);
    } catch (e) {
      console.log(`  År ${year}: FEL - ${e}`);
    }
  }
  
  console.log('\n---\n');
  
  // Test 4: KPI metadata
  console.log('TEST 4: KPI metadata för N02251');
  try {
    const url4 = `https://api.kolada.se/v3/kpi/${kpiId}`;
    const res4 = await fetch(url4);
    const data4 = await res4.json();
    if (data4.values?.[0]) {
      console.log(`  Titel: ${data4.values[0].title}`);
      console.log(`  Beskrivning: ${data4.values[0].description?.substring(0, 200)}...`);
      console.log(`  Publiceringsperiod: ${data4.values[0].publ_period || 'Okänd'}`);
    }
  } catch (e) {
    console.log(`  FEL: ${e}`);
  }
  
  console.log('\n=== KLAR ===');
}

testKoladaApi().catch(console.error);
