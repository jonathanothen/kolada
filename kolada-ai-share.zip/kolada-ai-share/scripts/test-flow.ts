/**
 * Testskript för att verifiera hela flödet från fråga till svar.
 * Kör: npx tsx scripts/test-flow.ts
 */

const fs = require('fs');
const path = require('path');

interface KPI {
  id: string;
  title: string;
  description: string;
  has_ou_data: boolean;
  municipality_type: string;
  operating_area: string;
}

interface KPIDatabase {
  lastUpdated: string;
  count: number;
  kpis: KPI[];
}

const kpiPath = path.join(__dirname, '../src/data/kpis.json');
const db: KPIDatabase = JSON.parse(fs.readFileSync(kpiPath, 'utf-8'));

// Test 1: Verifiera att KPI-databasen laddas korrekt
console.log('\n=== TEST 1: KPI-databas ===');
console.log(`Antal KPIs i lokal fil: ${db.count}`);
console.log(`Senast uppdaterad: ${db.lastUpdated}`);

// Test 2: Sök efter relevanta KPIs för "skolmat"
console.log('\n=== TEST 2: Sökning efter "skolmat/måltider/kostnad/grundskola" ===');

// Test olika sökningar
const testCases = [
  { name: 'Skolmat', terms: ['måltider', 'kostnad', 'grundskola'], expectedFirst: 'N15013' },
  { name: 'Befolkning', terms: ['invånare', 'folkmängd'], expectedFirst: 'N01951' },
  { name: 'Utrikes födda', terms: ['utrikes', 'födda'], expectedFirst: 'N02926' },
  { name: 'Sjukfrånvaro', terms: ['sjukfrånvaro'], expectedFirst: 'N00090' },
  { name: 'Arbetslöshet', terms: ['arbetslöshet'], expectedFirst: 'N00925' },
  { name: 'Egenföretagare', terms: ['egenföretagare', 'andel'], expectedFirst: 'N02251' },
];

const searchTerms = testCases[0].terms; // Default för resten av testerna
const termPatterns = searchTerms.map(term => ({
  term: term.toLowerCase(),
  stem: term.toLowerCase().replace(/er$|ar$|or$|na$|en$|et$|erna$|arna$/, '')
}));

// Sök och poängsätt
const scored: { kpi: KPI; score: number; titleMatches: number }[] = [];

for (const kpi of db.kpis) {
  const lowerTitle = kpi.title.toLowerCase();
  const lowerDesc = kpi.description.toLowerCase();
  
  let score = 0;
  let titleMatches = 0;
  
  for (const { term, stem } of termPatterns) {
    if (lowerTitle.includes(term) || (stem.length >= 3 && lowerTitle.includes(stem))) {
      score += 100;
      titleMatches++;
    } else if (lowerDesc.includes(term) || (stem.length >= 3 && lowerDesc.includes(stem))) {
      score += 20;
    }
  }
  
  if (score > 0) {
    scored.push({ kpi, score, titleMatches });
  }
}

// Sortera
scored.sort((a, b) => {
  if (b.titleMatches !== a.titleMatches) return b.titleMatches - a.titleMatches;
  return b.score - a.score;
});

console.log(`\nHittade ${scored.length} matchande KPIs`);
console.log('\nTopp 10 resultat:');
scored.slice(0, 10).forEach((item, i) => {
  console.log(`\n${i + 1}. ${item.kpi.id}: ${item.kpi.title}`);
  console.log(`   Score: ${item.score}, Titel-matchningar: ${item.titleMatches}`);
  console.log(`   Beskrivning: ${item.kpi.description.substring(0, 150)}...`);
});

// Test 3: Verifiera att N15013 är högst rankad
console.log('\n=== TEST 3: Verifiera att N15013 hittas först ===');
const n15013 = scored.find(s => s.kpi.id === 'N15013');
if (n15013) {
  const rank = scored.indexOf(n15013) + 1;
  console.log(`✅ N15013 hittad på plats ${rank}`);
  console.log(`   Titel: ${n15013.kpi.title}`);
  console.log(`   Full beskrivning:\n   ${n15013.kpi.description}`);
} else {
  console.log('❌ N15013 HITTADES INTE!');
}

// Test 4: Visa hur kontexten borde se ut
console.log('\n=== TEST 4: Simulerad kontext för AI ===');
const topKpis = scored.slice(0, 5);
let mockContext = '=== KPI-SÖKNING ===\n';
mockContext += `Sökord: ${searchTerms.join(', ')}\n\n`;
mockContext += `Hittade ${scored.length} KPIs - de 5 mest relevanta:\n\n`;

topKpis.forEach((item, i) => {
  mockContext += `${i + 1}. ${item.kpi.id}: ${item.kpi.title}\n`;
  mockContext += `   Beskrivning: ${item.kpi.description.substring(0, 200)}...\n\n`;
});

// Simulera data
mockContext += '\n=== FAKTISK DATA FRÅN KOLADA ===\n';
mockContext += 'OBS: Använd denna data för att svara på frågan!\n\n';
mockContext += '📊 N15013: Kostnad för måltider i kommunal grundskola åk 1-9, kr/elev\n\n';
mockContext += '  År 2024:\n';
mockContext += '    1. Ljusnarsberg: 11 293\n';
mockContext += '    2. Lekeberg: 11 264\n';
mockContext += '    3. Lindesberg: 10 282\n';
mockContext += '    4. Hällefors: 9 470\n';
mockContext += '    5. Degerfors: 9 022\n';
mockContext += '    6. Askersund: 8 920\n';
mockContext += '    7. Laxå: 8 608\n';
mockContext += '    8. Nora: 8 365\n';
mockContext += '    9. Örebro: 7 830\n';
mockContext += '    10. Kumla: 7 689\n';
mockContext += '    11. Karlskoga: 7 427\n';
mockContext += '    12. Hallsberg: 7 316\n';
mockContext += '    → Högst: Ljusnarsberg (11 293)\n';
mockContext += '    → Lägst: Hallsberg (7 316)\n';
mockContext += '    → Genomsnitt: 8 874\n';

console.log(mockContext);

// Test 5: Förslag på förbättrad AI-prompt
console.log('\n=== TEST 5: Föreslagen systemkontext ===');
console.log(`
Med denna kontext borde AI:n svara ungefär:

"Skolmaten i Kumla kostar 7 689 kr/elev (2024), vilket är lägre än Örebro 
som ligger på 7 830 kr/elev.

Ranking för Region Örebro län 2024:
1. Ljusnarsberg: 11 293 kr/elev (högst)
2. Lekeberg: 11 264 kr/elev
...
12. Hallsberg: 7 316 kr/elev (lägst)

Källa: N15013 - Kostnad för måltider i kommunal grundskola åk 1-9, kr/elev"
`);

// Test 6: Verifiera att description finns för alla topp-KPIs
console.log('\n=== TEST 6: Kontrollera beskrivningar ===');
let missingDescriptions = 0;
topKpis.forEach(item => {
  if (!item.kpi.description || item.kpi.description.length < 10) {
    console.log(`❌ ${item.kpi.id} saknar beskrivning!`);
    missingDescriptions++;
  } else {
    console.log(`✅ ${item.kpi.id} har beskrivning (${item.kpi.description.length} tecken)`);
  }
});

// Test 7: Testa PRIORITY_KPIS för alla testfall
console.log('\n=== TEST 7: Priority KPIs ===');

const PRIORITY_KPIS: { [kpiId: string]: string[] } = {
  'N01951': ['befolkning', 'invånare', 'folkmängd', 'population', 'antal personer'],
  'N01963': ['befolkningsförändring'],
  'N15013': ['skolmat', 'måltid', 'lunch', 'portion'],
  'N02926': ['utrikes födda', 'född utomlands', 'invandrare'],
  'N00090': ['sjukfrånvaro', 'sjuk', 'frånvaro'],
  'N00925': ['arbetslöshet', 'arbetslösa'],
  'N02251': ['egenföretagare', 'företagare'],
};

for (const testCase of testCases) {
  console.log(`\n📋 Test: ${testCase.name}`);
  console.log(`   Söktermer: ${testCase.terms.join(', ')}`);
  
  const queryLower = testCase.terms.join(' ').toLowerCase();
  const patterns = testCase.terms.map(t => ({
    term: t.toLowerCase(),
    stem: t.toLowerCase().replace(/er$|ar$|or$|na$|en$|et$|erna$|arna$/, '')
  }));
  
  const testScored: { kpi: KPI; score: number; isPriority: boolean }[] = [];
  
  for (const kpi of db.kpis) {
    const lowerTitle = kpi.title.toLowerCase();
    const lowerDesc = kpi.description.toLowerCase();
    let score = 0;
    let isPriority = false;
    let hasMatch = false;
    
    // Priority check
    const priorityKeywords = PRIORITY_KPIS[kpi.id];
    if (priorityKeywords) {
      for (const keyword of priorityKeywords) {
        if (queryLower.includes(keyword) || patterns.some(p => keyword.includes(p.term))) {
          score += 2000;
          isPriority = true;
          hasMatch = true;
          break;
        }
      }
    }
    
    // Normal matching
    for (const { term, stem } of patterns) {
      if (lowerTitle.includes(term) || (stem.length >= 3 && lowerTitle.includes(stem))) {
        score += 100;
        hasMatch = true;
      } else if (lowerDesc.includes(term) || (stem.length >= 3 && lowerDesc.includes(stem))) {
        score += 20;
        hasMatch = true;
      }
    }
    
    // Short title bonus
    if (hasMatch && lowerTitle.length < 30) score += 300;
    
    if (hasMatch) {
      testScored.push({ kpi, score, isPriority });
    }
  }
  
  testScored.sort((a, b) => {
    if (a.isPriority && !b.isPriority) return -1;
    if (b.isPriority && !a.isPriority) return 1;
    return b.score - a.score;
  });
  
  const firstKpi = testScored[0]?.kpi;
  const isCorrect = firstKpi?.id === testCase.expectedFirst;
  
  console.log(`   Förväntat först: ${testCase.expectedFirst}`);
  console.log(`   Faktiskt först: ${firstKpi?.id || 'INGEN'} (${firstKpi?.title?.substring(0, 40) || ''}...)`);
  console.log(`   ${isCorrect ? '✅ KORREKT' : '❌ FEL'}`);
  
  if (!isCorrect) {
    console.log(`   Topp 5 resultat:`);
    testScored.slice(0, 5).forEach((s, i) => {
      console.log(`     ${i+1}. ${s.kpi.id}: ${s.kpi.title.substring(0, 50)}... (score: ${s.score}, priority: ${s.isPriority})`);
    });
  }
}

console.log('\n=== SAMMANFATTNING ===');
console.log(`KPI-databas: ${db.count} KPIs`);
console.log(`Sökresultat för skolmat: ${scored.length} träffar`);
console.log(`N15013 (rätt KPI) på plats: ${scored.findIndex(s => s.kpi.id === 'N15013') + 1}`);
console.log(`Beskrivningar OK: ${topKpis.length - missingDescriptions}/${topKpis.length}`);
