import * as fs from 'fs';
import * as path from 'path';

// Hämta alla kommuner från Kolada API och spara lokalt
async function fetchMunicipalities() {
  console.log('Hämtar alla kommuner från Kolada API...');
  
  const response = await fetch('https://api.kolada.se/v3/municipality?per_page=500');
  const data = await response.json();
  
  if (!data.values || data.values.length === 0) {
    console.error('Inga kommuner hittades!');
    return;
  }
  
  console.log(`Hittade ${data.values.length} kommuner/regioner`);
  
  // Filtrera till bara kommuner (type K) och regioner (type L)
  const municipalities = data.values
    .filter((m: { type: string }) => m.type === 'K' || m.type === 'L')
    .map((m: { id: string; title: string; type: string }) => ({
      id: m.id,
      name: m.title,
      type: m.type
    }));
  
  console.log(`Filtrerade till ${municipalities.length} kommuner och regioner`);
  
  // Skapa en lookup-map för snabb sökning
  const municipalityLookup: { [name: string]: { id: string; name: string; type: string } } = {};
  
  for (const mun of municipalities) {
    // Lägg till med exakt namn (lower case)
    const lowerName = mun.name.toLowerCase();
    municipalityLookup[lowerName] = mun;
    
    // Lägg också till utan "s län" för regioner
    if (mun.name.endsWith('s län')) {
      const shortName = mun.name.replace(/s län$/, '').toLowerCase();
      municipalityLookup[shortName] = mun;
    }
  }
  
  const output = {
    count: municipalities.length,
    lastUpdated: new Date().toISOString(),
    municipalities: municipalities,
    lookup: municipalityLookup
  };
  
  const outputPath = path.join(__dirname, '../src/data/municipalities.json');
  fs.writeFileSync(outputPath, JSON.stringify(output, null, 2));
  
  console.log(`\nSparade ${municipalities.length} kommuner till: ${outputPath}`);
  console.log(`Filstorlek: ${(fs.statSync(outputPath).size / 1024).toFixed(1)} KB`);
  
  // Visa några exempel
  console.log('\nExempel på kommuner:');
  municipalities.slice(0, 5).forEach((m: { id: string; name: string; type: string }) => {
    console.log(`  ${m.id}: ${m.name} (${m.type})`);
  });
}

fetchMunicipalities().catch(console.error);
