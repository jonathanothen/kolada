import * as fs from 'fs';
import * as path from 'path';

// Läs den stora KPI-filen
const kpisPath = path.join(__dirname, '../src/data/kpis.json');
const outputPath = path.join(__dirname, '../src/data/kpi-index.json');
const outputTxtPath = path.join(__dirname, '../src/data/kpi-index.txt');

interface KPI {
  id: string;
  title: string;
  description?: string;
  has_ou_data?: boolean;
  municipality_type?: string;
  operating_area?: string;
  is_divided_by_gender?: boolean;
}

interface KPIDatabase {
  count: number;
  lastUpdated: string;
  kpis: KPI[];
}

console.log('Läser KPI-databas...');
const data: KPIDatabase = JSON.parse(fs.readFileSync(kpisPath, 'utf-8'));

console.log(`Hittade ${data.count} KPIs`);

// Skapa kompakt lista med bara id och titel
const kpiIndex = data.kpis.map(kpi => ({
  id: kpi.id,
  t: kpi.title // Kort nyckel för att spara utrymme
}));

// Spara som JSON
const jsonOutput = {
  count: data.count,
  updated: data.lastUpdated,
  kpis: kpiIndex
};

fs.writeFileSync(outputPath, JSON.stringify(jsonOutput, null, 0)); // Ingen indrag för minimal storlek
console.log(`\nSparade JSON: ${outputPath}`);

// Beräkna storlek
const jsonSize = fs.statSync(outputPath).size;
console.log(`JSON-storlek: ${(jsonSize / 1024).toFixed(1)} KB`);

// Spara som ren text (ännu kompaktare)
let txtOutput = `# KOLADA KPI-INDEX (${data.count} KPIs)\n`;
txtOutput += `# Uppdaterad: ${data.lastUpdated}\n`;
txtOutput += `# Format: KPI-ID | Titel\n\n`;

for (const kpi of data.kpis) {
  txtOutput += `${kpi.id} | ${kpi.title}\n`;
}

fs.writeFileSync(outputTxtPath, txtOutput, 'utf-8');
console.log(`\nSparade TXT: ${outputTxtPath}`);

const txtSize = fs.statSync(outputTxtPath).size;
console.log(`TXT-storlek: ${(txtSize / 1024).toFixed(1)} KB`);

// Jämför med original
const originalSize = fs.statSync(kpisPath).size;
console.log(`\n=== JÄMFÖRELSE ===`);
console.log(`Original (kpis.json): ${(originalSize / 1024 / 1024).toFixed(2)} MB`);
console.log(`Kompakt JSON:         ${(jsonSize / 1024).toFixed(1)} KB (${(jsonSize / originalSize * 100).toFixed(1)}%)`);
console.log(`Kompakt TXT:          ${(txtSize / 1024).toFixed(1)} KB (${(txtSize / originalSize * 100).toFixed(1)}%)`);

// Uppskatta tokens (ca 4 tecken per token)
const estimatedTokensJson = Math.round(jsonSize / 4);
const estimatedTokensTxt = Math.round(txtSize / 4);
console.log(`\n=== UPPSKATTADE TOKENS ===`);
console.log(`JSON: ~${estimatedTokensJson.toLocaleString('sv-SE')} tokens`);
console.log(`TXT:  ~${estimatedTokensTxt.toLocaleString('sv-SE')} tokens`);
console.log(`\nGemini 1.5 Pro har 1M tokens context - detta är ${(estimatedTokensTxt / 1000000 * 100).toFixed(2)}% av det.`);
