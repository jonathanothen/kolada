#!/usr/bin/env python3
"""
Synkroniserings-script for att ladda ner oudata (skolnivaadata) fran Kolada.
Sparar lokalt for snabb access utan API-anrop.

Kor: python scripts/sync-oudata.py
"""

import json
import os
import sys
import time
from datetime import datetime

try:
    import requests
except ImportError:
    print("Installerar requests...")
    os.system(f"{sys.executable} -m pip install requests")
    import requests

KOLADA_BASE = "https://api.kolada.se/v3"
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "..", "src", "data")
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "oudata-cache.json")

# KPIs som har oudata och ar relevanta for skolor
SCHOOL_KPIS = [
    "N15504",  # Meritvarde ak 9, genomsnitt (17 amnen)
    "N15420",  # Behorighet till gymnasiet
    "N15403",  # Elever som uppnatt kunskapskraven
    "N15030",  # Andel elever med gymnasiebehorighet
]

# Ar att hamta (nyaste forst)
YEARS = [2024, 2023, 2022, 2021]

def fetch_with_retry(url, retries=3, timeout=120):
    """Hamta med retry och exponentiell backoff"""
    for attempt in range(retries):
        try:
            print(f"  Forsok {attempt + 1}/{retries}...", end=" ", flush=True)
            r = requests.get(url, timeout=timeout)
            if r.ok:
                print("OK")
                return r.json()
            print(f"HTTP {r.status_code}")
            if r.status_code == 429:
                wait = 60 * (attempt + 1)
                print(f"  Rate limited! Vantar {wait}s...")
                time.sleep(wait)
        except requests.exceptions.Timeout:
            print("TIMEOUT")
            if attempt < retries - 1:
                wait = 10 * (attempt + 1)
                print(f"  Vantar {wait}s innan retry...")
                time.sleep(wait)
        except Exception as e:
            print(f"FEL: {e}")
            if attempt < retries - 1:
                time.sleep(5)
    return None

def sync_oudata():
    print("=" * 60)
    print("KOLADA OUDATA SYNC")
    print("Synkroniserar skolnivaadata lokalt")
    print("=" * 60)
    
    # Ladda existerande data om den finns
    cache = {
        "syncedAt": None,
        "kpis": {},
    }
    
    if os.path.exists(OUTPUT_FILE):
        try:
            with open(OUTPUT_FILE, "r", encoding="utf-8") as f:
                cache = json.load(f)
            print(f"\nLaddade existerande cache (synkad {cache.get('syncedAt', 'okant')})")
        except:
            pass
    
    # Hamta oudata for varje KPI och ar
    for kpi in SCHOOL_KPIS:
        print(f"\n{'='*40}")
        print(f"KPI: {kpi}")
        print("="*40)
        
        if kpi not in cache["kpis"]:
            cache["kpis"][kpi] = {"years": {}}
        
        for year in YEARS:
            # Kolla om vi redan har data for detta ar
            if str(year) in cache["kpis"][kpi]["years"]:
                existing = cache["kpis"][kpi]["years"][str(year)]
                print(f"\n  {year}: Redan synkad ({len(existing)} datapunkter)")
                continue
            
            print(f"\n  {year}: Hamtar fran API...")
            
            # Kolada API: /oudata/kpi/{kpi}/year/{year}
            # OBS: per_page max ar 5000, vi paginerar om det behovs
            all_values = []
            page = 1
            
            while True:
                url = f"{KOLADA_BASE}/oudata/kpi/{kpi}/year/{year}?per_page=5000&page={page}"
                print(f"  URL: {url}")
                
                data = fetch_with_retry(url, retries=3, timeout=180)
                
                if not data or "values" not in data:
                    break
                
                values = data["values"]
                all_values.extend(values)
                print(f"    Sida {page}: {len(values)} poster (totalt {len(all_values)})")
                
                # Kolla om det finns fler sidor
                if len(values) < 5000:
                    break
                page += 1
                time.sleep(1)  # Rate limiting mellan sidor
            
            if all_values:
                data = {"values": all_values}
            
            if data and "values" in data:
                values = data["values"]
                
                # Filtrera och formatera
                processed = []
                for item in values:
                    ou_id = item.get("ou", "")
                    
                    # Extrahera total-varde
                    total_value = None
                    for v in item.get("values", []):
                        if v.get("gender") == "T":
                            total_value = v.get("value")
                            break
                    
                    if total_value is not None:
                        processed.append({
                            "ou": ou_id,
                            "value": total_value,
                        })
                
                cache["kpis"][kpi]["years"][str(year)] = processed
                print(f"  -> {len(processed)} datapunkter sparade")
                
                # Spara efter varje framgangsrik hamtning
                cache["syncedAt"] = datetime.now().isoformat()
                os.makedirs(OUTPUT_DIR, exist_ok=True)
                with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
                    json.dump(cache, f, ensure_ascii=False)
                print("  -> Cache uppdaterad")
            else:
                print(f"  -> MISSLYCKADES")
            
            # Rate limiting
            time.sleep(2)
    
    # Slutlig sparning
    cache["syncedAt"] = datetime.now().isoformat()
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False)
    
    # Sammanfattning
    print("\n" + "=" * 60)
    print("SYNC KLAR!")
    print("=" * 60)
    
    total_points = 0
    for kpi, kpi_data in cache["kpis"].items():
        kpi_total = sum(len(year_data) for year_data in kpi_data["years"].values())
        print(f"  {kpi}: {kpi_total} datapunkter")
        total_points += kpi_total
    
    print(f"\nTotalt: {total_points} datapunkter")
    print(f"Sparad till: {OUTPUT_FILE}")
    print(f"\nAnvand i appen: Ladda {OUTPUT_FILE} vid startup")

if __name__ == "__main__":
    sync_oudata()
