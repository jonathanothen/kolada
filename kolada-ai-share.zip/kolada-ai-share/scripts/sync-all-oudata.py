"""
Dynamisk sync av ALL oudata for KPIs som har has_ou_data=true.
Prioriterar de vanligaste fragetyperna forst.
Sparar progressivt for att inte forlora data vid avbrott.
"""
import os
import json
import time
import requests
from datetime import datetime

# Konfig
KOLADA_BASE = "https://api.kolada.se/v3"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(SCRIPT_DIR, "..", "src", "data")
CACHE_FILE = os.path.join(OUTPUT_DIR, "oudata-cache.json")
KPI_FILE = os.path.join(OUTPUT_DIR, "kpis.json")

# Rate limiting
MIN_DELAY = 0.5  # sekunder mellan anrop
MAX_RETRIES = 3

# Ar att synka
YEARS = [2024, 2023, 2022, 2021]

# Prioriterade verksamhetsomraden (viktigast forst)
PRIORITY_AREAS = [
    "Grundskola",
    "Gymnasieskola", 
    "Forskole",
    "Sarskilt boende",
    "Hemtjanst",
    "LSS",
    "SoL",
    "Aldreomsorg",
]

def load_cache():
    """Ladda existerande cache"""
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"syncedAt": None, "kpis": {}}

def save_cache(cache):
    """Spara cache till fil"""
    cache["syncedAt"] = datetime.now().isoformat()
    with open(CACHE_FILE, 'w', encoding='utf-8') as f:
        json.dump(cache, f, ensure_ascii=False)

def fetch_with_retry(url, retries=MAX_RETRIES, timeout=120):
    """Hamta med retry och exponentiell backoff"""
    for attempt in range(retries):
        try:
            print(f"    Forsok {attempt + 1}/{retries}...", end=" ", flush=True)
            r = requests.get(url, timeout=timeout)
            if r.ok:
                print("OK")
                return r.json()
            else:
                print(f"HTTP {r.status_code}")
                if r.status_code == 429:  # Rate limited
                    wait = 30 * (attempt + 1)
                    print(f"    Rate limited, vantar {wait}s...")
                    time.sleep(wait)
        except requests.exceptions.Timeout:
            print("TIMEOUT")
            time.sleep(5 * (attempt + 1))
        except Exception as e:
            print(f"FEL: {e}")
            time.sleep(2)
    return None

def get_ou_kpis():
    """Hamta alla KPIs med has_ou_data=true, sorterade efter prioritet"""
    with open(KPI_FILE, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    kpis = data.get('kpis', [])
    ou_kpis = [k for k in kpis if k.get('has_ou_data')]
    
    # Sortera efter prioritet
    def priority_score(kpi):
        area = kpi.get('operating_area', '')
        for i, prio_area in enumerate(PRIORITY_AREAS):
            if prio_area.lower() in area.lower():
                return i
        return 100  # Lag prioritet for okanda
    
    ou_kpis.sort(key=priority_score)
    return ou_kpis

def sync_kpi(kpi_id, cache, years=YEARS):
    """Synka en specifik KPI for alla ar"""
    if kpi_id not in cache["kpis"]:
        cache["kpis"][kpi_id] = {"years": {}}
    
    synced_any = False
    
    for year in years:
        year_str = str(year)
        
        # Hoppa over om redan synkad
        if year_str in cache["kpis"][kpi_id]["years"]:
            existing = cache["kpis"][kpi_id]["years"][year_str]
            if len(existing) > 0:
                print(f"    {year}: Redan synkad ({len(existing)} poster)")
                continue
        
        print(f"    {year}: Hamtar fran API...")
        
        # Paginering
        all_values = []
        page = 1
        
        while True:
            url = f"{KOLADA_BASE}/oudata/kpi/{kpi_id}/year/{year}?per_page=5000&page={page}"
            data = fetch_with_retry(url, timeout=180)
            
            if not data or "values" not in data:
                break
            
            values = data["values"]
            all_values.extend(values)
            print(f"      Sida {page}: {len(values)} poster (totalt {len(all_values)})")
            
            if len(values) < 5000:
                break
            page += 1
            time.sleep(MIN_DELAY)
        
        # Processa och spara
        if all_values:
            processed = []
            for item in all_values:
                ou_id = item.get("ou", "")
                
                # Extrahera total-varde (gender='T')
                total_value = None
                for v in item.get("values", []):
                    if v.get("gender") == "T" and v.get("value") is not None:
                        total_value = v["value"]
                        break
                
                if total_value is not None:
                    processed.append({
                        "ou": ou_id,
                        "value": total_value
                    })
            
            cache["kpis"][kpi_id]["years"][year_str] = processed
            print(f"    -> {len(processed)} poster sparade")
            synced_any = True
        else:
            cache["kpis"][kpi_id]["years"][year_str] = []
            print(f"    -> 0 poster (ingen data)")
        
        time.sleep(MIN_DELAY)
    
    return synced_any

def main():
    print("="*60)
    print("KOLADA OUDATA SYNC - DYNAMISK")
    print("Synkroniserar ALL enhetsdata lokalt")
    print("="*60)
    
    # Ladda cache
    cache = load_cache()
    if cache["syncedAt"]:
        print(f"\nLaddade existerande cache (synkad {cache['syncedAt']})")
    
    # Hamta alla OU-KPIs
    ou_kpis = get_ou_kpis()
    print(f"\nHittade {len(ou_kpis)} KPIs med enhetsdata")
    
    # Visa prioritering
    print("\nPrioriterade verksamhetsomraden:")
    for i, area in enumerate(PRIORITY_AREAS, 1):
        count = len([k for k in ou_kpis if area.lower() in k.get('operating_area', '').lower()])
        print(f"  {i}. {area}: {count} KPIs")
    
    # Synka
    total_synced = 0
    total_points = 0
    
    try:
        for i, kpi in enumerate(ou_kpis, 1):
            kpi_id = kpi['id']
            title = kpi.get('title', '')[:40]
            area = kpi.get('operating_area', 'Okand')[:30]
            
            print(f"\n[{i}/{len(ou_kpis)}] {kpi_id}: {title}")
            print(f"         Omrade: {area}")
            
            synced = sync_kpi(kpi_id, cache)
            
            if synced:
                total_synced += 1
                # Spara efter varje KPI for att inte forlora data
                save_cache(cache)
            
            # Rakna totalt
            kpi_points = sum(len(y) for y in cache["kpis"].get(kpi_id, {}).get("years", {}).values())
            total_points += kpi_points
            
            # Status var 10:e KPI
            if i % 10 == 0:
                print(f"\n--- STATUS: {i}/{len(ou_kpis)} KPIs, {total_points} datapunkter totalt ---\n")
    
    except KeyboardInterrupt:
        print("\n\nAvbrutet av anvandare. Sparar cache...")
        save_cache(cache)
    
    # Slutrapport
    print("\n" + "="*60)
    print("SYNC KLAR!")
    print("="*60)
    
    # Statistik
    kpi_stats = {}
    for kpi_id, kpi_data in cache["kpis"].items():
        total = sum(len(y) for y in kpi_data.get("years", {}).values())
        kpi_stats[kpi_id] = total
    
    # Visa topp 20
    top_kpis = sorted(kpi_stats.items(), key=lambda x: -x[1])[:20]
    print("\nTopp 20 KPIs med mest data:")
    for kpi_id, count in top_kpis:
        print(f"  {kpi_id}: {count} datapunkter")
    
    total_all = sum(kpi_stats.values())
    print(f"\nTotalt: {len(kpi_stats)} KPIs med {total_all} datapunkter")
    print(f"Sparad till: {CACHE_FILE}")

if __name__ == "__main__":
    main()
