#!/usr/bin/env python3
"""
Synkroniserings-script för att ladda ner ALLA organisatoriska enheter (OUs) från Kolada
och spara dem lokalt. Detta eliminerar behovet av upprepade API-anrop.

Kör: python scripts/sync-ous.py
"""

import json
import os
import sys
from datetime import datetime

try:
    import requests
except ImportError:
    print("Installerar requests...")
    os.system(f"{sys.executable} -m pip install requests")
    import requests

KOLADA_BASE = "https://api.kolada.se/v3"
OUTPUT_FILE = os.path.join(os.path.dirname(__file__), "..", "src", "data", "ous.json")

def get_ou_type(ou_id):
    if ou_id.startswith("V15"): return "grundskola"
    if ou_id.startswith("V17"): return "gymnasium"
    if ou_id.startswith("V11"): return "förskola"
    if ou_id.startswith("V23"): return "äldreboende"
    if ou_id.startswith("V21"): return "hemtjänst"
    return None

def sync_ous():
    print("=" * 60)
    print("KOLADA OU SYNC")
    print("=" * 60)
    
    # Steg 1: Hamta ALLA OUs med paginering
    print("\n[1/4] Hamtar ALLA enheter fran Kolada...")
    
    all_ous = []
    page = 1
    
    while True:
        url = f"{KOLADA_BASE}/ou?per_page=5000&page={page}"
        print(f"  Hamtar sida {page}... ", end="", flush=True)
        
        try:
            r = requests.get(url, timeout=120)
            r.raise_for_status()
            data = r.json()
        except Exception as e:
            print(f"FEL: {e}")
            if page == 1:
                sys.exit(1)
            break
        
        values = data.get("values", [])
        print(f"{len(values)} enheter")
        
        for ou in values:
            ou_type = get_ou_type(ou["id"])
            if ou_type is None:
                continue
            
            all_ous.append({
                "id": ou["id"],
                "title": ou["title"],
                "municipality": ou["municipality"],
                "type": ou_type
            })
        
        if len(values) < 5000:
            break
        page += 1
    
    print(f"\n-> Totalt {len(all_ous)} relevanta enheter hamtade")
    
    # Steg 2: Gruppera per kommun
    print("\n[2/4] Grupperar per kommun...")
    
    by_municipality = {}
    stats = {
        "grundskola": 0,
        "gymnasium": 0,
        "förskola": 0,
        "äldreboende": 0,
        "hemtjänst": 0
    }
    
    for ou in all_ous:
        mun_id = ou["municipality"]
        if mun_id not in by_municipality:
            by_municipality[mun_id] = []
        by_municipality[mun_id].append(ou)
        stats[ou["type"]] += 1
    
    # Steg 3: Hamta kommunnamn
    print("\n[3/4] Hamtar kommunnamn...")
    municipalities = {}
    try:
        r = requests.get(f"{KOLADA_BASE}/municipality?per_page=500", timeout=60)
        if r.ok:
            for m in r.json().get("values", []):
                municipalities[m["id"]] = m["title"]
    except:
        pass
    
    # Steg 4: Spara till fil
    print("\n[4/4] Sparar till fil...")
    
    output = {
        "syncedAt": datetime.now().isoformat(),
        "totalCount": len(all_ous),
        "municipalityCount": len(by_municipality),
        "stats": stats,
        "municipalities": municipalities,
        "byMunicipality": by_municipality
    }
    
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    
    print("\n" + "=" * 60)
    print("SYNC KLAR!")
    print("=" * 60)
    print(f"Totalt: {len(all_ous)} enheter i {len(by_municipality)} kommuner")
    print(f"  - Grundskolor: {stats['grundskola']}")
    print(f"  - Gymnasium: {stats['gymnasium']}")
    print(f"  - Förskolor: {stats['förskola']}")
    print(f"  - Äldreboenden: {stats['äldreboende']}")
    print(f"  - Hemtjänst: {stats['hemtjänst']}")
    print(f"\nSparad till: {OUTPUT_FILE}")
    print("\nStarta om dev-servern för att använda den lokala databasen.")

if __name__ == "__main__":
    sync_ous()
