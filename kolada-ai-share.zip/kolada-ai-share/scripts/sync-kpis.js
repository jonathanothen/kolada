/**
 * Synkroniserar ALLA KPIs från Kolada API till lokal JSON-fil.
 * Kör: node scripts/sync-kpis.js
 */

const fs = require('fs');
const path = require('path');

const KOLADA_API = 'https://api.kolada.se/v3';
const OUTPUT_FILE = path.join(__dirname, '../src/data/kpis.json');

async function fetchAllKPIs() {
  const allKPIs = [];
  let page = 1;
  const perPage = 1000;
  
  console.log('Hämtar ALLA KPIs från Kolada API...\n');
  
  while (true) {
    const url = `${KOLADA_API}/kpi?per_page=${perPage}&page=${page}`;
    console.log(`Hämtar sida ${page}...`);
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`API-fel: ${response.status}`);
    }
    
    const data = await response.json();
    const kpis = data.values || [];
    
    if (kpis.length === 0) {
      break;
    }
    
    allKPIs.push(...kpis.map(k => ({
      id: k.id,
      title: k.title,
      description: k.description || '',
      has_ou_data: k.has_ou_data || false,
      municipality_type: k.municipality_type || '',
      operating_area: k.operating_area || '',
      is_divided_by_gender: k.is_divided_by_gender || 0,
    })));
    
    console.log(`  Hämtade ${kpis.length} KPIs (totalt: ${allKPIs.length})`);
    
    if (kpis.length < perPage) {
      break;
    }
    
    page++;
  }
  
  return allKPIs;
}

async function main() {
  try {
    console.log('=' .repeat(60));
    console.log('KOLADA KPI SYNKRONISERING');
    console.log('=' .repeat(60));
    
    const kpis = await fetchAllKPIs();
    
    const database = {
      lastUpdated: new Date().toISOString(),
      count: kpis.length,
      kpis,
    };
    
    // Skapa data-mappen om den inte finns
    const dataDir = path.dirname(OUTPUT_FILE);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Spara till fil
    fs.writeFileSync(OUTPUT_FILE, JSON.stringify(database, null, 2), 'utf-8');
    
    console.log(`\n${'='.repeat(60)}`);
    console.log(`✓ Sparade ${kpis.length} KPIs till:`);
    console.log(`  ${OUTPUT_FILE}`);
    console.log(`  Senast uppdaterad: ${database.lastUpdated}`);
    
    // Visa statistik
    const withOuData = kpis.filter(k => k.has_ou_data).length;
    console.log(`\nStatistik:`);
    console.log(`  - Totalt antal KPIs: ${kpis.length}`);
    console.log(`  - Med enhetsdata: ${withOuData}`);
    console.log(`  - Utan enhetsdata: ${kpis.length - withOuData}`);
    console.log('=' .repeat(60));
    
  } catch (error) {
    console.error('Fel:', error);
    process.exit(1);
  }
}

main();
