/**
 * Synkroniserar alla KPIs från Kolada API till lokal JSON-fil.
 * Kör: npx ts-node scripts/sync-kpis.ts
 * Eller: npm run sync-kpis
 */

import fs from 'fs';
import path from 'path';

const KOLADA_API = 'https://api.kolada.se/v3';
const OUTPUT_FILE = path.join(__dirname, '../src/data/kpis.json');

interface KPI {
  id: string;
  title: string;
  description: string;
  has_ou_data: boolean;
  municipality_type: string;
  operating_area: string;
  is_divided_by_gender: number;
}

interface KPIDatabase {
  lastUpdated: string;
  count: number;
  kpis: KPI[];
}

async function fetchAllKPIs(): Promise<KPI[]> {
  const allKPIs: KPI[] = [];
  let page = 1;
  const perPage = 1000;
  
  console.log('Hämtar alla KPIs från Kolada API...\n');
  
  while (true) {
    const url = `${KOLADA_API}/kpi?per_page=${perPage}&page=${page}`;
    console.log(`Hämtar sida ${page}...`);
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`API-fel: ${response.status}`);
    }
    
    const data = await response.json();
    const kpis = data.values || [];
    
    if (kpis.length === 0) {
      break;
    }
    
    allKPIs.push(...kpis.map((k: any) => ({
      id: k.id,
      title: k.title,
      description: k.description || '',
      has_ou_data: k.has_ou_data || false,
      municipality_type: k.municipality_type || '',
      operating_area: k.operating_area || '',
      is_divided_by_gender: k.is_divided_by_gender || 0,
    })));
    
    console.log(`  Hämtade ${kpis.length} KPIs (totalt: ${allKPIs.length})`);
    
    if (kpis.length < perPage) {
      break;
    }
    
    page++;
  }
  
  return allKPIs;
}

async function main() {
  try {
    const kpis = await fetchAllKPIs();
    
    const database: KPIDatabase = {
      lastUpdated: new Date().toISOString(),
      count: kpis.length,
      kpis,
    };
    
    // Skapa data-mappen om den inte finns
    const dataDir = path.dirname(OUTPUT_FILE);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Spara till fil
    fs.writeFileSync(OUTPUT_FILE, JSON.stringify(database, null, 2), 'utf-8');
    
    console.log(`\n✓ Sparade ${kpis.length} KPIs till ${OUTPUT_FILE}`);
    console.log(`  Senast uppdaterad: ${database.lastUpdated}`);
    
    // Visa statistik
    const withOuData = kpis.filter(k => k.has_ou_data).length;
    console.log(`\nStatistik:`);
    console.log(`  - Totalt antal KPIs: ${kpis.length}`);
    console.log(`  - Med enhetsdata: ${withOuData}`);
    console.log(`  - Utan enhetsdata: ${kpis.length - withOuData}`);
    
  } catch (error) {
    console.error('Fel:', error);
    process.exit(1);
  }
}

main();
