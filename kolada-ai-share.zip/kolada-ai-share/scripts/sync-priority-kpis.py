"""
Snabb-sync av de VIKTIGASTE KPIs for enhetsdata.
Fokuserar pa de vanligaste fragetyperna: skolor, aldreboenden, hemtjanst, LSS.
"""
import os
import json
import time
import requests
from datetime import datetime

KOLADA_BASE = "https://api.kolada.se/v3"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(SCRIPT_DIR, "..", "src", "data")
CACHE_FILE = os.path.join(OUTPUT_DIR, "oudata-cache.json")

YEARS = [2024, 2023, 2022, 2021]
MIN_DELAY = 0.5

# PRIORITERADE KPIs - de vanligaste fragorna
PRIORITY_KPIS = [
    # GRUNDSKOLA - betyg och resultat
    "N15504",  # Meritvarde ak 9, genomsnitt (17 amnen)
    "N15503",  # Betygspoang matematik ak 9
    "N15502",  # Betygspoang svenska ak 9
    "N15501",  # Betygspoang engelska ak 9
    "N15420",  # Behorighet till gymnasiet
    "N15030",  # Andel med gymnasiebehorighet
    "N15419",  # Uppnatt betygskriterier alla amnen
    "N15436",  # Behoriga till yrkesprogram
    "N15506",  # Meritvarde flickor
    "N15507",  # Meritvarde pojkar
    
    # GRUNDSKOLA - resurser och personal
    "N15031",  # Larare med ped hogskoleexamen
    "N15034",  # Elever per larare
    "N15807",  # Larare behoriga i svenska
    "N15808",  # Larare behoriga i matte
    "N15809",  # Larare behoriga i engelska
    
    # GYMNASIUM
    "N17448",  # Examen inom 3 ar
    "N17449",  # Hogskolebehorighet
    "N17450",  # Examen hogskoleforb program
    "N17400",  # Elever med examen
    
    # FORSKOLA
    "N11010",  # Barn per arsarbetare kommunal
    "N11011",  # Barn per arsarbetare enskild
    "N11041",  # Forskollarare med examen
    "N11701",  # Barn per barngrupp
    "N11102",  # Barn per arsarbetare total
    
    # SARSKILT BOENDE (aldreomsorg)
    "N23390",  # Brukarbed - personalen ar tillrackligt manga
    "N23391",  # Brukarbed - personalen har tid
    "N23440",  # Brukarbed - bra bemotande
    "N23480",  # Brukarbed - helhetsomdome
    "N23588",  # Omsorgspersonal utbildning
    
    # HEMTJANST
    "N21495",  # Brukarbed - personal ar tillrackligt manga
    "N21496",  # Brukarbed - personal har tid
    "N21530",  # Brukarbed - bra bemotande
    "N21570",  # Brukarbed - helhetsomdome
    "N21485",  # Andel nojda brukare
    
    # LSS BOENDE
    "U28576",  # Brukarbed gruppbostad - ibland bestamma
    "U28580",  # Brukarbed gruppbostad - personalen lyssnar
    "U28590",  # Brukarbed gruppbostad - trivsel
    "U28532",  # Brukarbed servicebostad - sjalv bestamma
    "N28150",  # Personal med adekvat utbildning
    
    # LSS DAGLIG VERKSAMHET
    "U28096",  # Brukarbed - trivsel
    "U28100",  # Brukarbed - personal lyssnar
    "U28112",  # Aktuella genomforandeplaner
    
    # SOL BOENDE
    "U26413",  # Brukarbed SoL boende
    "U31001",  # Ekonomiskt bistand
]

def load_cache():
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"syncedAt": None, "kpis": {}}

def save_cache(cache):
    cache["syncedAt"] = datetime.now().isoformat()
    with open(CACHE_FILE, 'w', encoding='utf-8') as f:
        json.dump(cache, f, ensure_ascii=False)

def fetch_with_retry(url, retries=3, timeout=180):
    for attempt in range(retries):
        try:
            print(f"    Forsok {attempt + 1}/{retries}...", end=" ", flush=True)
            r = requests.get(url, timeout=timeout)
            if r.ok:
                print("OK")
                return r.json()
            else:
                print(f"HTTP {r.status_code}")
                if r.status_code == 429:
                    time.sleep(30 * (attempt + 1))
        except requests.exceptions.Timeout:
            print("TIMEOUT")
            time.sleep(10)
        except Exception as e:
            print(f"FEL: {e}")
            time.sleep(2)
    return None

def sync_kpi(kpi_id, cache):
    if kpi_id not in cache["kpis"]:
        cache["kpis"][kpi_id] = {"years": {}}
    
    for year in YEARS:
        year_str = str(year)
        
        if year_str in cache["kpis"][kpi_id]["years"]:
            existing = cache["kpis"][kpi_id]["years"][year_str]
            if len(existing) > 0:
                print(f"    {year}: Redan synkad ({len(existing)} poster)")
                continue
        
        print(f"    {year}: Hamtar...")
        
        all_values = []
        page = 1
        
        while True:
            url = f"{KOLADA_BASE}/oudata/kpi/{kpi_id}/year/{year}?per_page=5000&page={page}"
            data = fetch_with_retry(url)
            
            if not data or "values" not in data:
                break
            
            values = data["values"]
            all_values.extend(values)
            
            if len(values) < 5000:
                break
            page += 1
            time.sleep(MIN_DELAY)
        
        # Processa
        processed = []
        for item in all_values:
            ou_id = item.get("ou", "")
            total_value = None
            for v in item.get("values", []):
                if v.get("gender") == "T" and v.get("value") is not None:
                    total_value = v["value"]
                    break
            
            if total_value is not None:
                processed.append({"ou": ou_id, "value": total_value})
        
        cache["kpis"][kpi_id]["years"][year_str] = processed
        print(f"    -> {len(processed)} poster")
        
        time.sleep(MIN_DELAY)

def main():
    print("="*60)
    print("PRIORITERAD OUDATA SYNC")
    print(f"Synkar {len(PRIORITY_KPIS)} viktiga KPIs")
    print("="*60)
    
    cache = load_cache()
    if cache["syncedAt"]:
        print(f"\nExisterande cache: {cache['syncedAt']}")
    
    try:
        for i, kpi_id in enumerate(PRIORITY_KPIS, 1):
            print(f"\n[{i}/{len(PRIORITY_KPIS)}] {kpi_id}")
            sync_kpi(kpi_id, cache)
            save_cache(cache)
            
    except KeyboardInterrupt:
        print("\n\nAvbrutet. Sparar...")
        save_cache(cache)
    
    # Rapport
    print("\n" + "="*60)
    print("KLAR!")
    print("="*60)
    
    total = 0
    for kpi_id in PRIORITY_KPIS:
        if kpi_id in cache["kpis"]:
            kpi_total = sum(len(y) for y in cache["kpis"][kpi_id].get("years", {}).values())
            total += kpi_total
            if kpi_total > 0:
                print(f"  {kpi_id}: {kpi_total} datapunkter")
    
    print(f"\nTotalt: {total} datapunkter")
    print(f"Sparad: {CACHE_FILE}")

if __name__ == "__main__":
    main()
